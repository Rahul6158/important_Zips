# JobPortal

JobPortal is a React and FastAPI application for browsing job listings,
reviewing recruiter and vendor information, tracking job-market analytics,
managing candidate profile data, uploading resumes, and generating tailored
`.docx` resume drafts for specific job descriptions.

## Repository Layout

| Path | Purpose |
| --- | --- |
| [`api/`](./api/) | FastAPI backend, SQLAlchemy models, Dice scraping, auth validation, resume storage, and resume tailoring. |
| [`ui/`](./ui/) | React single-page application built with Create React App, React Router, OIDC auth, Bootstrap, Material UI, Axios, and Chart.js. |
| [`docs/`](./docs/) | Product, architecture, engineering, operations, and troubleshooting documentation. |
| [`graphify-out/`](./graphify-out/) | Generated repository graph artifacts for codebase exploration. |

## Start Here

| Need | Link |
| --- | --- |
| Documentation hub | [docs/README.md](./docs/README.md) |
| Product overview | [docs/product/overview.md](./docs/product/overview.md) |
| System architecture | [docs/architecture/overview.md](./docs/architecture/overview.md) |
| API documentation | [api/docs/README.md](./api/docs/README.md) |
| UI documentation | [ui/docs/README.md](./ui/docs/README.md) |
| Local development | [docs/engineering/local-development.md](./docs/engineering/local-development.md) |
| Configuration | [docs/operations/configuration.md](./docs/operations/configuration.md) |
| Testing | [docs/engineering/testing-strategy.md](./docs/engineering/testing-strategy.md) |
| Deployment | [docs/operations/deployment.md](./docs/operations/deployment.md) |
| Troubleshooting | [docs/engineering/troubleshooting.md](./docs/engineering/troubleshooting.md) |

## Local Development

Run the backend from `api/`:

```bash
make install
make run
```

Run the frontend from `ui/`:

```bash
npm install
npm start
```

See [local development](./docs/engineering/local-development.md) for database,
OIDC, S3, scraper, and resume-tailoring configuration notes.

## Validation

Backend checks:

```bash
cd api
make test
make lint
make format-check
make type-check
```

Frontend checks:

```bash
cd ui
npm test -- --watchAll=false
npm run build
```

Some checks require local dependencies and environment configuration. Current
known gaps are tracked in [testing strategy](./docs/engineering/testing-strategy.md)
and [troubleshooting](./docs/engineering/troubleshooting.md).
