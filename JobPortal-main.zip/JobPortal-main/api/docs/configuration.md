# API Configuration

Use `api/.env.example` for variable names and safe local placeholders. Do not
commit real `.env` files.

| Name | Required | Purpose |
| --- | --- | --- |
| `APP_NAME` | no | FastAPI title. |
| `APP_VERSION` | no | Health and app version. |
| `APP_DESCRIPTION` | no | FastAPI description. |
| `APP_ENV` | no | Environment label. |
| `PORT` | no | HTTP port. |
| `DATABASE_URL` | yes in deployment | Full database connection string. |
| `DB_USER` / `DB_PASSWORD` / `DB_HOST` / `DB_PORT` / `DB_NAME` | fallback | Used when `DATABASE_URL` is unset. |
| `CORS_ORIGINS` | yes | Comma-separated browser origins. |
| `SCRAPER_ENABLED` | yes | Enables scheduled scraper startup. |
| `SCHEDULER_JOB_HOUR` / `SCHEDULER_JOB_MINUTE` | if scraper enabled | Daily collection schedule. |
| `DEFAULT_POSTED_DATE` | scraper | Dice default. |
| `DEFAULT_WORKPLACE_TYPES` | scraper | Dice default. |
| `DEFAULT_EMPLOYMENT_TYPE` | scraper | Dice default. |
| `DEFAULT_LIMIT` | scraper | Dice default result limit. |
| `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` | if upload enabled | S3 credentials. |
| `AWS_REGION` | if upload enabled | S3 region. |
| `S3_BUCKET_NAME` | if upload enabled | Resume bucket. |
| `OIDC_CLIENT_ID` / `OIDC_ISSUER` / `OIDC_JWKS_URI` | yes | OIDC token handling. |
| `OPENAI_API_KEY` | if tailoring enabled | Resume-tailoring LLM access. |

`CORS_ORIGINS` accepts comma-separated values, for example:

```text
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```
