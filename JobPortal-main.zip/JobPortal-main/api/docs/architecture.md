# API Architecture

```mermaid
flowchart TD
  Main[app/main.py] --> Middleware[AuthMiddleware]
  Main --> Router[api_router]
  Router --> Routes[api/routes/*]
  Routes --> Services[services/*]
  Services --> Models[models/*]
  Models --> DB[(PostgreSQL)]
  Routes --> Scraper[scrapers/*]
  Routes --> Tailor[tailor/*]
  Routes --> S3[S3Service]
```

## Layers

| Layer | Files | Responsibility |
| --- | --- | --- |
| App setup | `app/main.py` | FastAPI creation, CORS, auth middleware, routers, health endpoints, scheduler startup/shutdown. |
| Routing | `app/api/api.py`, `app/api/routes/` | HTTP endpoints and dependency wiring. |
| Middleware | `app/middleware/auth.py` | Public path bypass, bearer-token checks, admin path checks. |
| Configuration | `app/config.py` | Pydantic settings, env parsing, database URL composition. |
| Persistence | `app/database.py`, `app/models/` | SQLAlchemy engine, sessions, and ORM models. |
| Services | `app/services/` | Domain/database operations and S3 upload helper. |
| Scraping | `app/scrapers/` | Dice scraping, browser helpers, scheduler. |
| Tailoring | `app/tailor/` | Prompt formatting, LLM call, `.docx` output. |

## Request Flow

1. FastAPI receives the request.
2. `AuthMiddleware` skips public paths or requires a bearer token.
3. A route handler validates query/path/body inputs through FastAPI/Pydantic.
4. Handlers use service modules and SQLAlchemy sessions.
5. The response is JSON for most routes or a file response for resume tailoring.
