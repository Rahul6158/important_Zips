# API Troubleshooting

## Database Connection Errors

Check `DATABASE_URL` first. If it is unset, verify each `DB_*` fallback value.
Use `/health/ready` to confirm connectivity.

## Scraper Does Not Run

Scheduled scraping is disabled unless:

```text
SCRAPER_ENABLED=true
```

Manual scraper endpoints still require auth, and daily collection endpoints
require an `admin` role.

## Resume Upload Fails

- Confirm bearer auth is present.
- Confirm user has `candidate` role.
- Confirm the file is PDF, `.docx`, or legacy Word.
- Confirm S3 credentials and bucket are valid.

## Resume Tailoring Fails

- Only `.docx` uploads are accepted.
- Confirm `OPENAI_API_KEY` is available to the API process.
- Check API logs for document parsing or LLM errors.

## CORS Errors

Set `CORS_ORIGINS` to the frontend origin list. With credentials enabled, do not
use `*`.

## Swagger Works But Product Routes Return 401

Swagger paths are public, but product routes are protected by middleware. Use a
valid bearer token for non-public paths.
