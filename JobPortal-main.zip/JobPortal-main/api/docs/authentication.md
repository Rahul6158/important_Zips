# Authentication

## Public Paths

`AuthMiddleware` skips auth for:

- `/api/health`
- `/health/live`
- `/health/ready`
- `/api`
- `/docs`
- `/redoc`
- `/openapi.json`
- `/api/auth/validate-token`

All other API paths require an `Authorization: Bearer <token>` header.

## Token Validation

`POST /api/auth/validate-token` decodes the bearer token, extracts user claims,
looks up the user by email, creates a user when needed, and updates last login.

## Role Checks

Admin paths:

- `/api/scrape-jobs/run-daily-collection`
- `/api/run-daily-collection`

Resume upload and skill extraction check for a `candidate` role.

## Production Hardening

Current code decodes JWTs without signature verification. Production should
verify tokens against `OIDC_JWKS_URI` and fail closed on invalid signatures,
issuer, audience, and expiry.
