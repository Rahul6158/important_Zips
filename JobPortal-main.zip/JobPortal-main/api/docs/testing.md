# API Testing

## Commands

```bash
cd api
make test
make test-unit
make test-integration
make lint
make format-check
make type-check
```

## Existing Tests

| File | Coverage |
| --- | --- |
| `tests/unit/test_config.py` | Database URL construction and CORS parsing. |
| `tests/integration/test_health.py` | Public liveness and legacy health endpoints. |

## Recommended Additions

- Route tests for jobs, vendors, recruiters, analytics, auth, profile, scraper,
  and tailoring.
- Auth middleware tests for missing headers, invalid schemes, public paths, and
  admin-only paths.
- Database/service tests for job filter combinations.
- Resume upload tests for content types, candidate role checks, and S3 failure
  behavior.
- Contract tests against `ui/src/services/api.js`.
