# Request And Response Models

## Jobs

`api/app/schemas/job.py` defines `JobBase`, `Job`, `JobCreate`, and
`JobUpdate`.

Important fields include `job_id`, `title`, `description`, `requirements`,
`responsibilities`, `location`, `location_type`, `rate`, `term`,
`employment_details`, application metadata, status, source, external IDs,
recruiter/vendor IDs, timestamps, and `skills`.

`GET /api/jobs/all` returns:

```json
{
  "jobs": [],
  "total": 0
}
```

## Vendors

`api/app/schemas/vendor.py` defines `Vendor`, `VendorCreate`, `VendorUpdate`,
and `VendorWithStats`. `VendorWithStats` adds `recruiters_count`,
`total_jobs`, and `active_jobs`.

## Recruiters

`api/app/schemas/recruiter.py` defines recruiter identity, contact, source, and
aggregate fields including `vendor_name` and `total_jobs`.

## Skills

`api/app/schemas/skill.py` models job skill rows with `id`, `job_id`, and
`skill_name`.

## Users

`api/app/schemas/user.py` includes email, username, name, phone, SMTP metadata,
roles, active status, resume URL/path/status, timestamps, and last login.

SMTP fields are sensitive if used by a feature. Do not log or expose real SMTP
credentials.

## Scraper Requests

`ScrapeJobsRequest` defaults:

| Field | Default |
| --- | --- |
| `query` | empty string |
| `posted_date` | `ONE` |
| `workplace_types` | `Remote` |
| `employment_type` | `THIRD_PARTY` |
| `limit` | `1000` |

`ScrapeJobUrlRequest` requires `job_url`, which must start with
`https://www.dice.com/job-detail/`.

## Health

```json
{
  "status": "healthy",
  "api_version": "1.0.0",
  "checks": {}
}
```
