# API Build And Deployment

## Local Image

```bash
cd api
make docker-build
```

Equivalent:

```bash
docker build -t jobportal-api:local .
```

## Container Runtime

`api/Dockerfile`:

- uses `python:3.11-slim`,
- installs Chromium and ChromeDriver dependencies,
- installs `requirements.txt`,
- exposes port `8000`,
- health-checks `/health/live`,
- starts Uvicorn.

## Runtime Checks

```bash
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
curl http://localhost:8000/docs
```

## CI/CD

`api/Jenkinsfile` defines checkout, Docker build, release-branch image publish,
and release/Helm-values update stages through a shared library.

Production deployment target details are not yet documented in this repository.
