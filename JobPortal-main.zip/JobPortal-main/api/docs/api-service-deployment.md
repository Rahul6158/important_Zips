# Job Portal API Service Deployment Notes

This document captures the service inputs needed to deploy `api/` consistently.
It is aligned with the NAINAxAI backend API guidelines and Jira ticket NAI-31.

## Runtime Boundary

- Service root: `api/`
- ASGI app: `app.main:app`
- Local command: `make run`
- Container command: `uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}`
- Public health: `GET /health/live`
- Readiness health: `GET /health/ready`
- Legacy health retained: `GET /api/health`

## Required Configuration

Use runtime secrets/config maps for deployed environments. Do not rely on source
defaults for production.

| Name | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | yes | PostgreSQL connection string for the API database. |
| `CORS_ORIGINS` | yes | Comma-separated browser origins allowed by the API. |
| `PORT` | no | HTTP listen port. Defaults to `8000`. |
| `SCRAPER_ENABLED` | yes | Must be explicitly set; defaults to `false`. |
| `SCHEDULER_JOB_HOUR` | if scraper enabled | Hour for scheduled Dice collection. |
| `SCHEDULER_JOB_MINUTE` | if scraper enabled | Minute for scheduled Dice collection. |
| `AWS_ACCESS_KEY_ID` | if resume upload enabled | S3 access key from secret store. |
| `AWS_SECRET_ACCESS_KEY` | if resume upload enabled | S3 secret key from secret store. |
| `AWS_REGION` | if resume upload enabled | S3 region. |
| `S3_BUCKET_NAME` | if resume upload enabled | Resume storage bucket. |
| `OIDC_CLIENT_ID` | yes | Keycloak client ID. |
| `OIDC_ISSUER` | yes | OIDC issuer URL. |
| `OIDC_JWKS_URI` | yes | JWKS URL for token verification. |

## Helm Values Inputs

Expected chart inputs for CI/CD or GitOps:

- `image.repository`
- `image.tag`
- `service.port`
- `env.PORT`
- `env.CORS_ORIGINS`
- `env.SCRAPER_ENABLED`
- `env.SCHEDULER_JOB_HOUR`
- `env.SCHEDULER_JOB_MINUTE`
- `secretEnv.DATABASE_URL`
- `secretEnv.AWS_ACCESS_KEY_ID`
- `secretEnv.AWS_SECRET_ACCESS_KEY`
- `secretEnv.OIDC_CLIENT_ID`
- `secretEnv.OIDC_ISSUER`
- `secretEnv.OIDC_JWKS_URI`

## Database Expectations

The app creates a SQLAlchemy engine from `DATABASE_URL`. Schema changes are
currently script-based under `api/scripts/`; a follow-up migration ticket should
standardize this with Alembic before production rollout.

Readiness checks run `SELECT 1` against the configured database. If the database
is unreachable, `/health/ready` returns HTTP 503 and reports the database check
as unavailable.

## Scraper Runtime

`SCRAPER_ENABLED=false` is the default. This prevents browser scraping from
starting unexpectedly in containerized environments. Environments that need the
scheduled scraper must explicitly set:

```text
SCRAPER_ENABLED=true
SCHEDULER_JOB_HOUR=<0-23>
SCHEDULER_JOB_MINUTE=<0-59>
```

The image includes Chromium and ChromeDriver dependencies required by the Dice
scraper.

## Validation

Run from `api/`:

```bash
make install
make test
make docker-build
```

Runtime smoke checks:

```bash
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
curl http://localhost:8000/docs
```

## Rollback

Rollback is a standard image rollback:

1. Restore the previously deployed image tag.
2. Keep existing `DATABASE_URL` and OIDC secrets unchanged.
3. Set `SCRAPER_ENABLED=false` if scraper behavior is suspected in an incident.
4. Verify `/health/live` and `/health/ready`.
