# API Overview

The API owns backend state and operations for JobPortal:

- jobs, recruiters, vendors, skills, and analytics,
- OIDC token validation and user profile persistence,
- resume upload metadata and S3 storage,
- `.docx` resume tailoring,
- Dice scraping and scheduled collection,
- liveness/readiness endpoints for deployments.

## Framework And Runtime

| Item | Value |
| --- | --- |
| Framework | FastAPI |
| Server | Uvicorn |
| Python target | Python 3.11 |
| Package file | `requirements.txt` |
| Tool config | `pyproject.toml` |
| Local runner | `make run` |
| Container runner | `uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}` |

## API Boundary

The API is mounted under `/api` for product routes and also exposes deployment
health endpoints under `/health/*`.

The frontend expects the API base URL to include `/api`, for example:

```text
REACT_APP_API_URL=http://localhost:8000/api
```
