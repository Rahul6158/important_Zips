# API Local Development

## Setup

```bash
cd api
python3 -m venv .venv
source .venv/bin/activate
make install
cp .env.example .env
```

Edit `api/.env` for local database, CORS, OIDC, S3, scraper, and LLM settings.

## Run

```bash
make run
```

Equivalent command:

```bash
uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000} --reload
```

## Initialize Local Tables

```bash
python scripts/create_tables.py
```

Other maintenance scripts exist under `api/scripts/`.

## Smoke Checks

```bash
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
curl http://localhost:8000/api/health
```

## Validation

```bash
make test
make lint
make format-check
make type-check
```
