# API Folder Structure

```text
api/
├── app/
│   ├── api/
│   │   ├── api.py
│   │   └── routes/
│   ├── middleware/
│   ├── models/
│   ├── schemas/
│   ├── scrapers/
│   ├── services/
│   └── tailor/
├── docs/
├── scripts/
├── tests/
│   ├── integration/
│   └── unit/
├── Dockerfile
├── Jenkinsfile
├── Makefile
├── pyproject.toml
└── requirements.txt
```

## Important Entry Points

| File | Purpose |
| --- | --- |
| `app/main.py` | FastAPI app factory and runtime entry point. |
| `app/api/api.py` | Route assembly and direct daily collection endpoint. |
| `app/config.py` | Environment-backed settings. |
| `app/database.py` | SQLAlchemy engine/session configuration. |
| `app/middleware/auth.py` | Bearer-token middleware. |
| `app/scrapers/scheduler.py` | APScheduler lifecycle. |
| `app/tailor/resume_tailor.py` | Resume-tailoring orchestration. |
