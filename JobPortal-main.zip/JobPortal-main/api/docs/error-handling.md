# Error Handling

## Common HTTP Errors

| Status | Source | Meaning |
| --- | --- | --- |
| `400` | Resume tailoring, scraper URL, resume upload | Invalid file type or invalid Dice URL. |
| `401` | Auth middleware and auth/profile routes | Missing, malformed, or invalid bearer token. |
| `403` | Auth middleware, profile routes | Missing required role such as `admin` or `candidate`. |
| `404` | Job/vendor/recruiter/profile routes | Requested entity was not found. |
| `500` | Scraper, profile, tailoring routes | Unexpected service, storage, scraper, or LLM failure. |
| `503` | `/health/ready` | Database readiness check failed. |

## Logging

The API logs through `job_portal_api` and module-specific loggers. Avoid logging
tokens, credentials, resume contents, or webhook URLs.

## Gaps

- Error response schema is not standardized across all route families.
- Some route handlers catch broad exceptions and return generic HTTP errors.
- Structured error codes are not yet documented in repository.
