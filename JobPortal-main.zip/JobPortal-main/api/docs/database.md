# Database

The API uses SQLAlchemy with a PostgreSQL-compatible database.

## Connection

`api/app/database.py` creates the engine from `settings.DATABASE_URL`.

`settings.DATABASE_URL` is either explicit `DATABASE_URL` or composed from
`DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`, and `DB_NAME`.

## Models

| Table | Model | Notes |
| --- | --- | --- |
| `jobs` | `app/models/job.py` | Job listing metadata and relationships to recruiter, vendor, and skills. |
| `vendors` | `app/models/vendor.py` | Vendor profile and relationships to jobs/recruiters. |
| `recruiters` | `app/models/recruiter.py` | Recruiter contact data and vendor relation. |
| `job_skills` | `app/models/job_skill.py` | Skill rows tied to jobs. |
| `skills` | `app/models/skill.py` | Skills used by profile/analytics flows. |
| `users` | `app/models/user.py` | Auth, role, profile, resume, and optional SMTP metadata. |

## Scripts

Database utility scripts are in `api/scripts/`, including table creation,
database reset, and data backfill/update scripts.

## Migrations

Alembic is referenced in dependencies and legacy docs, but an Alembic migration
directory is not currently visible in the repository. Migration process is
`TBD`.

## Readiness

`GET /health/ready` runs `SELECT 1`. It returns HTTP 503 when the database is
unavailable.
