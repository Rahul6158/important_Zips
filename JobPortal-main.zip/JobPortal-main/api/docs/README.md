# API Documentation

## Start Here

| Area | Description | Link |
| --- | --- | --- |
| Overview | Backend purpose and runtime boundary. | [overview.md](./overview.md) |
| Architecture | FastAPI layers and request flow. | [architecture.md](./architecture.md) |
| Local Development | Setup, run, and local checks. | [local-development.md](./local-development.md) |
| Folder Structure | Backend directory map. | [folder-structure.md](./folder-structure.md) |
| Endpoints | Route inventory from source. | [api-endpoints.md](./api-endpoints.md) |
| Models | Request/response schemas and database entities. | [request-response-models.md](./request-response-models.md) |
| Authentication | Public paths, bearer tokens, and role checks. | [authentication.md](./authentication.md) |
| Database | SQLAlchemy engine, models, scripts, and readiness. | [database.md](./database.md) |
| Integrations | OIDC, S3, Dice, LLM, and CI. | [integrations.md](./integrations.md) |
| Configuration | Environment variables and safe examples. | [configuration.md](./configuration.md) |
| Testing | Pytest, Ruff, Mypy, and coverage gaps. | [testing.md](./testing.md) |
| Build And Deployment | Docker, health checks, and Jenkins notes. | [build-and-deployment.md](./build-and-deployment.md) |
| Error Handling | Current HTTP error patterns. | [error-handling.md](./error-handling.md) |
| Troubleshooting | Common backend failures. | [troubleshooting.md](./troubleshooting.md) |
| Service Deployment Notes | Existing service deployment page. | [api-service-deployment.md](./api-service-deployment.md) |

## Runtime Summary

- ASGI app: `app.main:app`
- App factory: `api/app/main.py:create_app`
- Router assembly: `api/app/api/api.py`
- Config: `api/app/config.py`
- Database: SQLAlchemy engine from `settings.DATABASE_URL`
- Default port: `8000`
- Liveness: `GET /health/live`
- Readiness: `GET /health/ready`
