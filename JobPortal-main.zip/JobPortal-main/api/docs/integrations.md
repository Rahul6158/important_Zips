# Integrations

| Integration | Source Evidence | Configuration |
| --- | --- | --- |
| PostgreSQL-compatible database | `app/database.py`, `app/config.py` | `DATABASE_URL` or `DB_*` variables |
| OIDC provider | `app/middleware/auth.py`, `app/api/routes/auth.py` | `OIDC_CLIENT_ID`, `OIDC_ISSUER`, `OIDC_JWKS_URI` |
| S3-compatible storage | `app/services/s3_service.py` | `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION`, `S3_BUCKET_NAME` |
| Dice scraping | `app/scrapers/dice/`, `app/scrapers/scheduler.py` | `SCRAPER_ENABLED`, scheduler and default scraper variables |
| OpenAI-compatible LLM | `app/tailor/resume_tailor.py` | `OPENAI_API_KEY` |
| Jenkins/shared library | `Jenkinsfile` | CI environment and credentials outside this repo |

Do not copy webhook URLs, secret IDs, AWS keys, database passwords, OIDC client
secrets, or OpenAI keys into docs or committed config.
