# API Endpoints

Routes are mounted from `api/app/api/api.py`.

## System

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `GET` | `/api` | Welcome/version payload. | Public |
| `GET` | `/api/health` | Legacy health endpoint. | Public |
| `GET` | `/health/live` | Liveness endpoint. | Public |
| `GET` | `/health/ready` | Readiness endpoint with database check. | Public |

## Auth

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `POST` | `/api/auth/validate-token` | Validate bearer token and create/update user. | Public route, token expected |
| `GET` | `/api/auth/profile` | Return current user profile. | Bearer |
| `PUT` | `/api/auth/profile` | Update current user profile. | Bearer |

## Jobs

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `GET` | `/api/jobs/all` | List jobs with filters, pagination, and total. | Bearer |
| `GET` | `/api/jobs/{job_id}` | Fetch a job by external ID or numeric internal ID. | Bearer |

Supported list query parameters include `skip`, `limit`, `q`, `location`,
`employment_type`, `location_type`, `skill`, `skills`, `rate`, `term`,
`recruiter_id`, `vendor_id`, `status`, `sort`, `order`, and `date_filter`.

## Vendors

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `GET` | `/api/vendors/all` | List vendors with aggregate stats. | Bearer |
| `GET` | `/api/vendors/{vendor_id}` | Fetch vendor by external or internal ID. | Bearer |
| `GET` | `/api/vendors/internal/{internal_id}` | Fetch vendor by explicit internal ID. | Bearer |

## Recruiters

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `GET` | `/api/recruiters/all` | List recruiters with job counts. | Bearer |
| `GET` | `/api/recruiters/{recruiter_id}` | Fetch recruiter by external or internal ID. | Bearer |
| `GET` | `/api/recruiters/internal/{internal_id}` | Fetch recruiter by explicit internal ID. | Bearer |

## Analytics

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `GET` | `/api/analytics/test` | Analytics smoke response. | Bearer |
| `GET` | `/api/analytics/skills` | Job counts by skill. | Bearer |
| `GET` | `/api/analytics/locations` | Job counts by location. | Bearer |
| `GET` | `/api/analytics/skills/all` | Unique skill names. | Bearer |
| `GET` | `/api/analytics/locations/all` | Unique location names. | Bearer |

## Profile

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `POST` | `/api/profile/upload-resume` | Upload resume for current user. | Bearer + `candidate` role |
| `POST` | `/api/profile/update-skills` | Update current user's selected skills. | Bearer |
| `POST` | `/api/profile/extract-skills` | Extract skills from resume URL. | Bearer + `candidate` role |
| `GET` | `/api/profile/resume-status` | Return resume metadata for current user. | Bearer |

## Resume Tailoring

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `POST` | `/api/tailor/tailor-resume` | Upload `.docx` resume plus job description and return tailored `.docx`. | Bearer |

## Scraper

| Method | Path | Purpose | Auth |
| --- | --- | --- | --- |
| `POST` | `/api/scrape-jobs/scrape-jobs` | Start background Dice scraping. | Bearer |
| `GET` | `/api/scrape-jobs/run-daily-collection` | Start daily collection in background. | Bearer + `admin` role |
| `POST` | `/api/scrape-jobs/scrape-job-url` | Scrape one Dice job detail URL. | Bearer |
| `GET` | `/api/run-daily-collection` | Direct daily collection trigger. | Bearer + `admin` role |

## Known Contract Gap

The frontend has a helper for `/api/jobs/internal/{id}`, but the backend does
not expose that exact route.
