from app.config import Settings


def test_database_url_uses_explicit_database_url() -> None:
    settings = Settings(DATABASE_URL="postgresql://user:pass@example.com:5432/jobportal")

    assert settings.DATABASE_URL == "postgresql://user:pass@example.com:5432/jobportal"


def test_database_url_is_composed_from_db_fields() -> None:
    settings = Settings(
        DB_USER="jobportal",
        DB_PASSWORD="p@ss word",
        DB_HOST="postgres",
        DB_PORT="5432",
        DB_NAME="jobs",
    )

    assert settings.DATABASE_URL == "postgresql://jobportal:p%40ss+word@postgres:5432/jobs"


def test_cors_origins_accept_comma_separated_env_style_value() -> None:
    settings = Settings(CORS_ORIGINS="http://localhost:3000, https://jobs.example.com")

    assert settings.CORS_ORIGINS == ["http://localhost:3000", "https://jobs.example.com"]
