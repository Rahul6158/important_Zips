from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app


def test_liveness_endpoint_is_public() -> None:
    client = TestClient(create_app(Settings(APP_VERSION="test", SCRAPER_ENABLED=False)))

    response = client.get("/health/live")

    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "api_version": "test", "checks": {}}


def test_legacy_api_health_endpoint_is_kept() -> None:
    client = TestClient(create_app(Settings(APP_VERSION="test", SCRAPER_ENABLED=False)))

    response = client.get("/api/health")

    assert response.status_code == 200
    assert response.json()["status"] == "healthy"
