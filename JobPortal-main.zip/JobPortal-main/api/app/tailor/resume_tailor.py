import os
import tempfile
import logging
import traceback
from docx import Document
from crewai import Agent, Task, Crew
from langchain_openai import ChatOpenAI
from pathlib import Path
from app.config import settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ResumeTailor:
    def __init__(self):
        self.prompt_template_path = os.path.join(
            os.path.dirname(__file__),
            "resume_tailoring_prompt.txt"
        )
        
    def read_docx(self, docx_path):
        """Read content from a .docx file"""
        doc = Document(docx_path)
        lines = [para.text for para in doc.paragraphs if para.text.strip()]
        return "\n".join(lines)
    
    def save_to_docx(self, text, output_path):
        """Save text content to a .docx file"""
        doc = Document()
        for line in text.split('\n'):
            doc.add_paragraph(line)
        doc.save(output_path)
    
    def load_prompt_template(self):
        """Load the resume tailoring prompt template"""
        with open(self.prompt_template_path, "r", encoding="utf-8") as f:
            return f.read()
    
    def tailor_resume(self, resume_file_content, job_description):
        """
        Tailor a resume to match a job description
        
        Args:
            resume_file_content: Bytes content of the uploaded resume file
            job_description: String containing the job description
            
        Returns:
            Path to the tailored resume file
        """
        logger.info("Starting resume tailoring process")
        
        # Save uploaded file to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp_resume:
            tmp_resume.write(resume_file_content)
            tmp_resume_path = tmp_resume.name
            logger.info(f"Saved uploaded resume to temporary file: {tmp_resume_path}")
        
        try:
            # Read resume content
            resume_text = self.read_docx(tmp_resume_path)
            logger.info(f"Successfully read resume content, length: {len(resume_text)} characters")
            
            # Load and format prompt
            prompt_template = self.load_prompt_template()
            formatted_prompt = (
                prompt_template
                .replace("{{job_description}}", job_description)
                .replace("{{resume_text}}", resume_text)
            )
            logger.info(f"Formatted prompt, length: {len(formatted_prompt)} characters")
            
            # Define Agent
            resume_tailor_agent = Agent(
                role="Resume Tailor",
                goal="Rewrite resumes to align with job descriptions while keeping format and structure unchanged.",
                backstory="You are a professional resume expert.",
                allow_delegation=False,
                verbose=True,
                temperature=0.4
            )
            logger.info("Created resume tailor agent")
            
            # Define Task
            resume_task = Task(
                description=formatted_prompt,
                expected_output="Rewritten resume with tailored content matching the job description.",
                agent=resume_tailor_agent
            )
            logger.info("Created resume tailoring task")
            
            # Define model and Crew
            llm = ChatOpenAI(
                # model_name="gpt-4-turbo",
                model_name="gpt-4o",
                # temperature=0.4,
                api_key=os.getenv("OPENAI_API_KEY")
            )
            logger.info("Initialized ChatOpenAI model")
            
            crew = Crew(
                agents=[resume_tailor_agent],
                tasks=[resume_task],
                llm=llm
            )
            logger.info("Created crew with agent and task")
            
            # Run CrewAI and save result
            logger.info("Starting crew.kickoff() to generate tailored resume")
            result = crew.kickoff()
            logger.info(f"Received result from crew.kickoff(), type: {type(result)}")
            logger.info(f"Result object attributes: {dir(result)}")
            
            # Try different approaches to extract text content
            try:
                # First, try to access the 'raw_output' attribute if it exists
                if hasattr(result, 'raw_output'):
                    result_text = result.raw_output
                    logger.info("Using result.raw_output for text content")
                # Next, try to access the 'output' attribute if it exists
                elif hasattr(result, 'output'):
                    result_text = result.output
                    logger.info("Using result.output for text content")
                # If neither attribute exists, try to convert the entire object to a string
                else:
                    result_text = str(result)
                    logger.info("Using str(result) for text content")
                
                logger.info(f"Extracted text content, length: {len(result_text)} characters")
                logger.info(f"First 100 characters of result: {result_text[:100]}...")
                
                # Check if the result_text can be split
                if not isinstance(result_text, str):
                    logger.error(f"result_text is not a string, it's a {type(result_text)}")
                    result_text = str(result_text)
                
                # Save result to a temporary file
                output_dir = os.path.join(tempfile.gettempdir(), "tailored_resumes")
                os.makedirs(output_dir, exist_ok=True)
                output_path = os.path.join(output_dir, f"tailored_resume_{os.urandom(4).hex()}.docx")
                logger.info(f"Saving tailored resume to: {output_path}")
                
                self.save_to_docx(result_text, output_path)
                logger.info("Successfully saved tailored resume to DOCX file")
                
                return output_path
                
            except Exception as e:
                logger.error(f"Error processing result: {str(e)}")
                logger.error(traceback.format_exc())
                raise Exception(f"Error processing result: {str(e)}")
            
        except Exception as e:
            logger.error(f"Error tailoring resume: {str(e)}")
            logger.error(traceback.format_exc())
            raise Exception(f"Error tailoring resume: {str(e)}")
            
        finally:
            # Clean up the temporary resume file
            if os.path.exists(tmp_resume_path):
                os.unlink(tmp_resume_path)
                logger.info(f"Cleaned up temporary file: {tmp_resume_path}")