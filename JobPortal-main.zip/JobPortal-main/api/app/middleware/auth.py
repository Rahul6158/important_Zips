import json
import logging

import jwt
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import settings

logger = logging.getLogger("job_portal_api")

class AuthMiddleware(BaseHTTPMiddleware):
    def __init__(
        self, 
        app, 
        public_paths: list[str] | None = None,
        admin_paths: list[str] | None = None,
    ):
        super().__init__(app)
        self.public_paths = public_paths or [
            "/api/health",
            "/health/live",
            "/health/ready",
            "/api",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/api/auth/validate-token"
        ]
        self.admin_paths = admin_paths or [
            "/api/scrape-jobs/run-daily-collection",
            "/api/run-daily-collection"
        ]
    
    async def dispatch(self, request: Request, call_next):
        # Skip authentication for public paths
        path = request.url.path
        if any(path.startswith(public_path) for public_path in self.public_paths):
            return await call_next(request)
        
        # Check for Authorization header
        authorization = request.headers.get("Authorization")
        if not authorization:
            return JSONResponse(
                status_code=401,
                content={"detail": "Authorization header is missing"}
            )
        
        try:
            # Extract the token
            scheme, token = authorization.split()
            if scheme.lower() != "bearer":
                return JSONResponse(
                    status_code=401,
                    content={"detail": "Invalid authentication scheme"}
                )
            
            # Decode and verify the token
            # In production, use proper verification with your auth provider's public key
            payload = jwt.decode(token, options={"verify_signature": False})
            
            # Check for admin paths
            if any(path.startswith(admin_path) for admin_path in self.admin_paths):
                # Get roles from the token
                realm_roles = payload.get("realm_access", {}).get("roles", [])
                client_id = settings.OIDC_CLIENT_ID
                client_roles = (
                    payload.get("resource_access", {})
                    .get(client_id, {})
                    .get("roles", [])
                )
                roles = list(set(realm_roles + client_roles))
                
                # Check if user has admin role
                if "admin" not in roles:
                    return JSONResponse(
                        status_code=403,
                        content={"detail": "Insufficient permissions"}
                    )
            
            # Ensure roles are properly formatted as a list
            if "realm_access" in payload and "roles" in payload["realm_access"]:
                if isinstance(payload["realm_access"]["roles"], str):
                    try:
                        # Try to parse as JSON
                        payload["realm_access"]["roles"] = json.loads(
                            payload["realm_access"]["roles"]
                        )
                    except json.JSONDecodeError:
                        # If it's a string but not JSON, convert to list
                        payload["realm_access"]["roles"] = [
                            role.strip()
                            for role in payload["realm_access"]["roles"].strip("[]").split(",")
                        ]
            
            # Add user info to request state
            request.state.user = payload
            
            return await call_next(request)
            
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid token"}
            )
