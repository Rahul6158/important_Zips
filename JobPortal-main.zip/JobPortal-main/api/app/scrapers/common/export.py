"""
Export utilities for scrapers
"""
import os
import csv
import logging
from typing import List, Dict, Any
from datetime import datetime

logger = logging.getLogger(__name__)


def save_to_csv(
    items: List[Dict[str, Any]],
    filename: str = None,
    output_dir: str = None,
    prefix: str = "export",
    suffix: str = "",
) -> str:
    """
    Save items to a CSV file
    
    Args:
        items: List of dictionaries to save
        filename: Optional filename to use
        output_dir: Directory to save the file in
        prefix: Prefix for the filename if not specified
        suffix: Suffix for the filename if not specified
        
    Returns:
        Path to the saved file
    """
    if not items:
        logger.warning("No items to save to CSV")
        return None
    
    # Create output directory if it doesn't exist
    if not output_dir:
        output_dir = os.path.join(os.getcwd(), "output")
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Create filename with timestamp if not provided
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{prefix}_{timestamp}{suffix}.csv"
    
    filepath = os.path.join(output_dir, filename)
    
    # Get all keys from the first item
    fieldnames = list(items[0].keys())
    
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        # Write header row
        writer.writeheader()
        
        # Write data rows
        for item in items:
            # Convert any list values to strings
            row = {}
            for key, value in item.items():
                if isinstance(value, list):
                    row[key] = "; ".join(str(v) for v in value)
                else:
                    row[key] = value
            writer.writerow(row)
    
    logger.info(f"Saved {len(items)} items to {filepath}")
    return filepath