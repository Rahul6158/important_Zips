"""
Common data models for scrapers
"""
from dataclasses import dataclass, field
from typing import List, Optional, Any, Dict


@dataclass
class ScraperConfig:
    """Configuration for job scrapers"""
    query: str = ""
    posted_date: str = "SEVEN"
    workplace_types: List[str] = field(default_factory=lambda: ["Remote"])
    employment_type: str = "THIRD_PARTY"
    limit: int = 100
    batch_size: int = 100
    max_workers: Optional[int] = None
    retry_attempts: int = 3
    retry_delay: int = 2


@dataclass
class JobData:
    """Job data model"""
    job_id: str
    job_title: str = ""
    job_description: str = ""
    yoe: int = 0  # Default to 0 instead of None
    job_requirements: str = ""
    job_responsibilities: str = ""
    job_location: str = ""
    job_location_type: str = ""
    job_rate: str = ""
    job_term: str = ""
    job_company: str = ""
    job_company_url: str = ""
    job_skills: List[str] = field(default_factory=list)
    job_employment_details: List[str] = field(default_factory=list)
    job_recruiter_name: str = ""
    job_recruiter_id: str = ""
    job_recruiter_position: str = ""
    job_recruiter_url: str = ""
    job_vendor_name: str = ""
    job_vendor_url: str = ""
    job_vendor_id: str = ""
    posted_date: str = ""
    updated_date: str = ""
    date_posted: str = ""
    date_updated: str = ""
    date_first_active: str = ""
    date_deactivated: str = ""
    application_email: str = ""
    application_cc_email: str = ""
    application_type: str = ""
    application_url: str = ""
    source: str = ""
    external_id: str = ""
    external_url: str = ""
    status: str = "active"  # Add this field with default value


@dataclass
class VendorData:
    """Vendor data model"""
    vendor_id: str
    name: str
    url: str = ""
    description: str = ""
    source: str = ""
    external_id: str = ""
    external_url: str = ""


@dataclass
class RecruiterData:
    """Recruiter data model"""
    recruiter_id: str
    name: str
    email: str = ""
    phone: str = ""
    profile_url: str = ""
    work_location: str = ""
    vendor_id: Optional[int] = None
    source: str = ""
    external_id: str = ""
    external_url: str = ""
