"""
Optimized driver pool for efficient browser management
"""
import os
import time
import logging
import threading
from contextlib import contextmanager
from queue import Queue, Empty
from typing import Optional
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

logger = logging.getLogger(__name__)

class DriverPool:
    """Thread-safe driver pool for managing Chrome WebDriver instances"""
    
    def __init__(self, pool_size: int = 5, max_idle_time: int = 300):
        """
        Initialize driver pool
        
        Args:
            pool_size: Number of drivers to maintain in pool
            max_idle_time: Maximum idle time before driver cleanup (seconds)
        """
        self.pool_size = pool_size
        self.max_idle_time = max_idle_time
        self._pool = Queue(maxsize=pool_size)
        self._active_drivers = set()
        self._lock = threading.RLock()
        self._initialized = False
        self._cleanup_thread = None
        
    def _create_driver(self) -> webdriver.Chrome:
        """Create a new Chrome driver with optimized settings"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-logging")
        chrome_options.add_argument("--log-level=3")
        chrome_options.add_argument("--silent")
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
        
        # Determine ChromeDriver path
        if os.uname().machine == 'arm64' and os.uname().sysname == 'Darwin':
            chromedriver_path = "/opt/homebrew/bin/chromedriver"
        else:
            chromedriver_path = "/usr/bin/chromedriver"
        
        service = Service(chromedriver_path)
        driver = webdriver.Chrome(service=service, options=chrome_options)
        driver.set_page_load_timeout(30)
        
        return driver
    
    def _initialize_pool(self):
        """Initialize the driver pool with drivers"""
        with self._lock:
            if self._initialized:
                return
                
            logger.info(f"Initializing driver pool with {self.pool_size} drivers")
            
            for i in range(self.pool_size):
                try:
                    driver = self._create_driver()
                    driver._pool_created_time = time.time()
                    self._pool.put(driver, block=False)
                    logger.debug(f"Created driver {i+1}/{self.pool_size}")
                except Exception as e:
                    logger.error(f"Failed to create driver {i+1}: {e}")
            
            self._initialized = True
            self._start_cleanup_thread()
            logger.info(f"Driver pool initialized with {self._pool.qsize()} drivers")
    
    def _start_cleanup_thread(self):
        """Start background thread for driver cleanup"""
        if self._cleanup_thread and self._cleanup_thread.is_alive():
            return
            
        def cleanup_worker():
            while self._initialized:
                try:
                    time.sleep(60)  # Check every minute
                    self._cleanup_idle_drivers()
                except Exception as e:
                    logger.error(f"Error in cleanup thread: {e}")
        
        self._cleanup_thread = threading.Thread(target=cleanup_worker, daemon=True)
        self._cleanup_thread.start()
    
    def _cleanup_idle_drivers(self):
        """Remove and recreate drivers that have been idle too long"""
        current_time = time.time()
        drivers_to_recreate = []
        
        # Check drivers in pool
        temp_drivers = []
        while not self._pool.empty():
            try:
                driver = self._pool.get_nowait()
                if current_time - driver._pool_created_time > self.max_idle_time:
                    drivers_to_recreate.append(driver)
                else:
                    temp_drivers.append(driver)
            except Empty:
                break
        
        # Put back non-expired drivers
        for driver in temp_drivers:
            self._pool.put(driver)
        
        # Recreate expired drivers
        for old_driver in drivers_to_recreate:
            try:
                old_driver.quit()
                new_driver = self._create_driver()
                new_driver._pool_created_time = current_time
                self._pool.put(new_driver)
                logger.debug("Recreated idle driver")
            except Exception as e:
                logger.error(f"Failed to recreate driver: {e}")
    
    @contextmanager
    def get_driver(self, timeout: int = 30):
        """Get a driver from the pool"""
        if not self._initialized:
            self._initialize_pool()
        
        driver = None
        start_time = time.time()
        
        # Try to get driver from pool
        while time.time() - start_time < timeout:
            try:
                driver = self._pool.get_nowait()
                break
            except Empty:
                # If pool is empty, create temporary driver
                if time.time() - start_time > 5:  # Wait 5 seconds before creating temp
                    try:
                        driver = self._create_driver()
                        driver._pool_created_time = time.time()
                        driver._is_temporary = True
                        logger.debug("Created temporary driver")
                        break
                    except Exception as e:
                        logger.error(f"Failed to create temporary driver: {e}")
                time.sleep(0.1)
        
        if not driver:
            raise RuntimeError("Failed to get driver from pool")
        
        with self._lock:
            self._active_drivers.add(driver)
        
        try:
            yield driver
        finally:
            with self._lock:
                self._active_drivers.discard(driver)
            
            # Return driver to pool or cleanup if temporary
            if hasattr(driver, '_is_temporary') and driver._is_temporary:
                try:
                    driver.quit()
                    logger.debug("Cleaned up temporary driver")
                except:
                    pass
            else:
                try:
                    # Reset driver state before returning to pool
                    driver.delete_all_cookies()
                    driver.execute_script("window.localStorage.clear();")
                    driver.execute_script("window.sessionStorage.clear();")
                    self._pool.put(driver, block=False)
                except Exception as e:
                    logger.error(f"Failed to return driver to pool: {e}")
                    try:
                        driver.quit()
                    except:
                        pass
    
    def shutdown(self):
        """Shutdown the driver pool and cleanup all drivers"""
        logger.info("Shutting down driver pool")
        
        with self._lock:
            self._initialized = False
            
            # Cleanup active drivers
            for driver in list(self._active_drivers):
                try:
                    driver.quit()
                except:
                    pass
            self._active_drivers.clear()
            
            # Cleanup pooled drivers
            while not self._pool.empty():
                try:
                    driver = self._pool.get_nowait()
                    driver.quit()
                except:
                    pass
        
        logger.info("Driver pool shutdown complete")

# Global driver pool instance
_driver_pool = None
_pool_lock = threading.Lock()

def get_driver_pool(pool_size: int = 5) -> DriverPool:
    """Get or create the global driver pool instance"""
    global _driver_pool
    
    with _pool_lock:
        if _driver_pool is None:
            _driver_pool = DriverPool(pool_size=pool_size)
        return _driver_pool

def shutdown_driver_pool():
    """Shutdown the global driver pool"""
    global _driver_pool
    
    with _pool_lock:
        if _driver_pool:
            _driver_pool.shutdown()
            _driver_pool = None

@contextmanager
def get_pooled_driver(pool_size: int = 5):
    """Context manager to get a driver from the pool"""
    pool = get_driver_pool(pool_size)
    with pool.get_driver() as driver:
        yield driver