"""
Common browser driver utilities
"""
import os
import time
import random
import logging
import psutil
from contextlib import contextmanager
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

logger = logging.getLogger(__name__)
# import logging
logging.getLogger('WDM').setLevel(logging.WARNING)

# Constants for parallel processing
MAX_WORKERS_RATIO = 0.75  # Use up to 75% of available CPU cores
MAX_MEMORY_PERCENT = 80  # Use up to 80% of available RAM
RETRY_ATTEMPTS = 3  # Number of retry attempts for failed operations
RETRY_DELAY = 2  # Delay between retries in seconds


def create_chrome_driver():
    """Create a Chrome driver with optimized settings"""
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-logging")
    chrome_options.add_argument("--log-level=3")
    chrome_options.add_argument("--silent")
    
    # Add user agent to avoid detection
    chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
    
    # Use system-installed ChromeDriver (from Homebrew) instead of webdriver-manager
    # Check if we're on macOS with Apple Silicon
    if os.uname().machine == 'arm64' and os.uname().sysname == 'Darwin':
        chromedriver_path = "/opt/homebrew/bin/chromedriver"
    else:
        # Fall back to webdriver-manager if not on Apple Silicon Mac
        # chromedriver_path = ChromeDriverManager().install()
        chromedriver_path = "/usr/bin/chromedriver"
    
    service = Service(chromedriver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    
    # Set page load timeout
    driver.set_page_load_timeout(30)
    
    return driver


@contextmanager
def get_driver_with_retry(max_retries=RETRY_ATTEMPTS):
    """Create a Chrome driver with retry logic"""
    attempts = 0
    driver = None
    
    while attempts < max_retries:
        try:
            driver = create_chrome_driver()
            yield driver
            break
        except Exception as e:
            attempts += 1
            logger.warning(f"Driver creation failed (attempt {attempts}/{max_retries}): {e}")
            if driver:
                try:
                    driver.quit()
                except:
                    pass
            
            if attempts >= max_retries:
                logger.error("Max retry attempts reached for driver creation")
                raise
            
            # Add jitter to retry delay to prevent thundering herd
            jitter = random.uniform(0.5, 1.5)
            time.sleep(RETRY_DELAY * jitter)

    if driver:
        try:
            driver.quit()
        except:
            pass


def calculate_optimal_workers():
    """Calculate the optimal number of workers based on system resources"""
    cpu_count = os.cpu_count() or 4
    memory = psutil.virtual_memory()
    
    # Calculate workers based on CPU
    cpu_workers = max(1, int(cpu_count * MAX_WORKERS_RATIO))
    
    # Calculate workers based on memory (assuming each Chrome instance uses ~300MB)
    chrome_memory_usage = 300 * 1024 * 1024  # 300MB in bytes
    available_memory = memory.available * (MAX_MEMORY_PERCENT / 100)
    memory_workers = max(1, int(available_memory / chrome_memory_usage))
    
    # Use the lower of the two calculations
    optimal_workers = min(cpu_workers, memory_workers)
    
    # logger.info(f"System has {cpu_count} CPU cores and {memory.available / (1024**3):.2f}GB available RAM")
    # logger.info(f"Optimal worker count: {optimal_workers} (CPU limit: {cpu_workers}, Memory limit: {memory_workers})")
    
    return optimal_workers

from selenium.webdriver.support.ui import WebDriverWait

def wait_for_load(driver, timeout: int = 10) -> None:
    WebDriverWait(driver, timeout).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )

# Add import at the top
from app.scrapers.common.driver_pool import get_pooled_driver, shutdown_driver_pool

# Keep existing functions for backward compatibility
# Add new optimized function
@contextmanager
def get_driver_optimized(pool_size: int = None):
    """Get an optimized driver from the pool"""
    if pool_size is None:
        pool_size = min(calculate_optimal_workers(), 20)  # Cap at 5 for memory
    
    with get_pooled_driver(pool_size) as driver:
        yield driver