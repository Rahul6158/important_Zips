"""
Concurrent processing utilities for scrapers
"""
import logging
import concurrent.futures
from typing import List, Callable, Any, TypeVar, Generic, Dict

logger = logging.getLogger(__name__)

T = TypeVar('T')
R = TypeVar('R')


def process_parallel(
    items: List[T],
    process_func: Callable[[T], R],
    max_workers: int = 5,
    chunk_size: int = 10,
    timeout: int = 120,
    description: str = "items"
) -> List[R]:
    """
    Process items in parallel using a thread pool
    
    Args:
        items: List of items to process
        process_func: Function to process each item
        max_workers: Maximum number of worker threads
        chunk_size: Number of items to process in each batch
        timeout: Timeout in seconds for each batch
        description: Description of items for logging
        
    Returns:
        List of processed results
    """
    results = []
    total_items = len(items)
    
    logger.info(f"Processing {total_items} {description} in parallel with {max_workers} workers")
    
    # Process in chunks to avoid memory issues with large datasets
    for i in range(0, total_items, chunk_size):
        chunk = items[i:i + chunk_size]
        chunk_results = []
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_item = {executor.submit(process_func, item): item for item in chunk}
            
            for future in concurrent.futures.as_completed(future_to_item, timeout=timeout):
                item = future_to_item[future]
                try:
                    result = future.result()
                    if result:
                        chunk_results.append(result)
                except Exception as e:
                    logger.error(f"Error processing {description} {item}: {e}")
        
        results.extend(chunk_results)
        logger.info(f"Processed {len(results)}/{total_items} {description}")
    
    return results