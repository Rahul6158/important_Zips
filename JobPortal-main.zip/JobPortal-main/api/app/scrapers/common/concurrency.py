"""
Common concurrency utilities
"""
import time
import random
import logging
import concurrent.futures
from typing import List, Callable, Any, TypeVar, Generic

logger = logging.getLogger(__name__)

T = TypeVar('T')
R = TypeVar('R')


def process_in_parallel(
    task_func: Callable[[T], R],
    items: List[T],
    max_workers: int,
    retry_attempts: int = 3,
    retry_delay: int = 2,
    description: str = "Processing items",
    **kwargs  # Add this to accept additional arguments
) -> List[R]:
    """
    Process a list of items in parallel with retry logic
    
    Args:
        task_func: Function to process each item
        items: List of items to process
        max_workers: Maximum number of parallel workers
        retry_attempts: Number of retry attempts for failed tasks
        retry_delay: Delay between retries in seconds
        description: Description of the processing task for logging
        **kwargs: Additional arguments to pass to the task function
        
    Returns:
        List of results
    """
    results = []
    
    logger.info(f"{description}: Processing {len(items)} items with {max_workers} workers")
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Create a dictionary mapping futures to their items
        future_to_item = {
            executor.submit(
                task_with_retry, 
                lambda item: task_func(item, **kwargs),  # Pass kwargs to task_func
                item, 
                retry_attempts, 
                retry_delay
            ): item for item in items
        }
        
        # Process results as they complete
        for i, future in enumerate(concurrent.futures.as_completed(future_to_item)):
            item = future_to_item[future]
            try:
                result = future.result()
                if result is not None:
                    results.append(result)
                
                # Log progress periodically
                if (i + 1) % 10 == 0 or (i + 1) == len(items):
                    logger.info(f"{description}: Completed {i + 1}/{len(items)} items")
            except Exception as e:
                logger.error(f"Error processing item {item}: {e}")
    
    logger.info(f"{description}: Completed processing {len(items)} items, got {len(results)} results")
    return results


def task_with_retry(task_func, item, max_retries, retry_delay):
    """Execute a task with retry logic"""
    attempts = 0
    
    while attempts < max_retries:
        try:
            return task_func(item)
        except Exception as e:
            attempts += 1
            if attempts >= max_retries:
                logger.error(f"Max retry attempts reached for item {item}: {e}")
                raise
            
            # Add jitter to retry delay
            jitter = random.uniform(0.5, 1.5)
            delay = retry_delay * jitter
            logger.warning(f"Task failed for item {item} (attempt {attempts}/{max_retries}), retrying in {delay:.2f}s: {e}")
            time.sleep(delay)
    
    return None