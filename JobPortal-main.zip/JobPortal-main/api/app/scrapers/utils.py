"""
Scraper Utility Functions

This module provides common utility functions for web scraping.
"""
import time
import logging
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

# Assuming this file exists based on directory structure
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

def validate_scraper_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate and set default values for scraper data
    """
    validated_data = data.copy()
    
    # Set default source if not provided
    if "source" not in validated_data:
        validated_data["source"] = "dice"
    
    # Set default external_id if not provided
    if "external_id" not in validated_data and "id" in validated_data:
        validated_data["external_id"] = validated_data["id"]
    
    # Construct external_url if not provided
    if "external_url" not in validated_data or not validated_data["external_url"]:
        if validated_data["source"] == "dice" and "id" in validated_data:
            validated_data["external_url"] = f"https://www.dice.com/job-detail/{validated_data['id']}"
    
    return validated_data

def validate_date_format(date_str: Optional[str]) -> Optional[str]:
    """
    Validate and normalize date string format
    """
    if not date_str:
        return None
        
    try:
        # Add validation logic for date formats
        # This is a placeholder for actual implementation
        return date_str
    except Exception as e:
        logger.warning(f"Invalid date format: {date_str}, error: {e}")
        return None

def create_chrome_driver(headless=True, user_agent=None):
    """
    Create a Chrome WebDriver with optimized settings
    
    Args:
        headless (bool): Whether to run Chrome in headless mode
        user_agent (str): Custom user agent string
        
    Returns:
        webdriver.Chrome: Configured Chrome WebDriver instance
    """
    chrome_options = Options()
    
    if headless:
        chrome_options.add_argument("--headless")
    
    # Performance optimizations
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-infobars")
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--window-size=1920,1080")
    
    # Set custom user agent if provided
    if user_agent:
        chrome_options.add_argument(f"--user-agent={user_agent}")
    else:
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36")
    
    # Create driver with retry mechanism
    max_retries = 3
    retry_count = 0
    driver = None
    
    while retry_count < max_retries and driver is None:
        try:
            driver = webdriver.Chrome(options=chrome_options)
            logger.info("ChromeDriver started successfully")
            return driver
        except Exception as e:
            retry_count += 1
            logger.error(f"Failed to start ChromeDriver (attempt {retry_count}/{max_retries}): {e}")
            if retry_count < max_retries:
                time.sleep(2)  # Wait before retrying
            else:
                logger.error("Max retries reached. Could not start ChromeDriver.")
                raise
    return driver

def retry_function(func, max_retries=3, delay=2, *args, **kwargs):
    """
    Retry a function multiple times if it fails
    
    Args:
        func: The function to retry
        max_retries (int): Maximum number of retry attempts
        delay (int): Delay between retries in seconds
        *args, **kwargs: Arguments to pass to the function
        
    Returns:
        The result of the function call or None if all retries fail
    """
    for attempt in range(max_retries):
        try:
            result = func(*args, **kwargs)
            return result
        except Exception as e:
            logger.error(f"Error in function {func.__name__} (attempt {attempt+1}/{max_retries}): {e}")
            if attempt < max_retries - 1:
                time.sleep(delay)
    
    logger.error(f"Max retries reached for function {func.__name__}")
    return None