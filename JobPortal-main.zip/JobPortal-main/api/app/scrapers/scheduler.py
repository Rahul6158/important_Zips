"""
Job Scraper Scheduler

This module handles scheduling of job scraping tasks.
"""
import logging
from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

from app.config import settings
from app.scrapers.dice.scraper import run_daily_job_collection_optimized

# Set up logging
logger = logging.getLogger("job_scheduler")

# Create scheduler instance
scheduler = BackgroundScheduler()

def initialize_scheduler(dbapi=None):
    """Initialize the APScheduler"""
    global scheduler

    if not settings.SCRAPER_ENABLED:
        logger.info("Job scraper scheduler is disabled by SCRAPER_ENABLED=false")
        return scheduler

    if scheduler.running:
        scheduler.shutdown(wait=False)

    scheduler = BackgroundScheduler()
    
    # Add the daily job collection task
    # Use a wrapper function that doesn't pass any arguments
    def job_wrapper():
        try:
            # Call without any arguments
            run_daily_job_collection_optimized()
        except Exception as e:
            logger.error(f"Error in job_wrapper: {e}")
    
    # Use only one job definition
    scheduler.add_job(
        job_wrapper,  # Use the wrapper function
        trigger='cron',
        hour=settings.SCHEDULER_JOB_HOUR,
        minute=settings.SCHEDULER_JOB_MINUTE,
        id='daily_job_collection',
        replace_existing=True,
    )
    
    logger.info(
        "Scheduled daily job collection at %s:%s",
        settings.SCHEDULER_JOB_HOUR,
        settings.SCHEDULER_JOB_MINUTE,
    )
    return scheduler

def start_scheduler():
    """Start the scheduler if it's not already running"""
    if not settings.SCRAPER_ENABLED:
        logger.info("Job scheduler start skipped because SCRAPER_ENABLED=false")
        return False

    if scheduler.state == 0:  # 0 means the scheduler is not running
        scheduler.start()
        logger.info("Job scheduler started")
        return True
    else:
        logger.info("Job scheduler is already running")
        return False

def shutdown_scheduler():
    """Shutdown the scheduler if it's running"""
    if scheduler.state != 0:  # Not in stopped state
        scheduler.shutdown()
        logger.info("Job scheduler shut down")
        return True
    else:
        logger.info("Job scheduler is not running")
        return False

def add_one_time_job(
    job_func,
    run_date=None,
    args=None,
    kwargs=None,
    job_id=None,
    replace_existing=True,
):
    """
    Add a one-time job to the scheduler
    
    Args:
        job_func: The function to execute
        run_date: When to run the job (datetime or string)
        args: List of positional arguments to pass to the job
        kwargs: Dict of keyword arguments to pass to the job
        job_id: Unique identifier for the job
        replace_existing: Whether to replace an existing job with the same ID
        
    Returns:
        The scheduled job
    """
    if run_date is None:
        run_date = datetime.now()
        
    if job_id is None:
        job_id = f"one_time_job_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
    job = scheduler.add_job(
        job_func,
        'date',
        run_date=run_date,
        args=args or [],
        kwargs=kwargs or {},
        id=job_id,
        replace_existing=replace_existing
    )
    
    logger.info(f"Added one-time job {job_id} to run at {run_date}")
    return job

def add_interval_job(
    job_func,
    seconds=0,
    minutes=0,
    hours=0,
    job_id=None,
    replace_existing=True,
    args=None,
    kwargs=None,
):
    """
    Add a job that runs at regular intervals
    
    Args:
        job_func: The function to execute
        seconds: Number of seconds between executions
        minutes: Number of minutes between executions
        hours: Number of hours between executions
        job_id: Unique identifier for the job
        replace_existing: Whether to replace an existing job with the same ID
        args: List of positional arguments to pass to the job
        kwargs: Dict of keyword arguments to pass to the job
        
    Returns:
        The scheduled job
    """
    if job_id is None:
        job_id = f"interval_job_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
    job = scheduler.add_job(
        job_func,
        trigger=IntervalTrigger(seconds=seconds, minutes=minutes, hours=hours),
        id=job_id,
        replace_existing=replace_existing,
        args=args or [],
        kwargs=kwargs or {}
    )
    
    interval_str = ""
    if hours > 0:
        interval_str += f"{hours} hour(s) "
    if minutes > 0:
        interval_str += f"{minutes} minute(s) "
    if seconds > 0:
        interval_str += f"{seconds} second(s)"
        
    logger.info(f"Added interval job {job_id} to run every {interval_str}")
    return job

def get_job(job_id):
    """Get a job by its ID"""
    return scheduler.get_job(job_id)

def remove_job(job_id):
    """Remove a job by its ID"""
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
        logger.info(f"Removed job {job_id}")
        return True
    else:
        logger.warning(f"Job {job_id} not found")
        return False

def get_jobs():
    """Get all scheduled jobs"""
    return scheduler.get_jobs()

def pause_job(job_id):
    """Pause a job by its ID"""
    if scheduler.get_job(job_id):
        scheduler.pause_job(job_id)
        logger.info(f"Paused job {job_id}")
        return True
    else:
        logger.warning(f"Job {job_id} not found")
        return False

def resume_job(job_id):
    """Resume a paused job by its ID"""
    if scheduler.get_job(job_id):
        scheduler.resume_job(job_id)
        logger.info(f"Resumed job {job_id}")
        return True
    else:
        logger.warning(f"Job {job_id} not found")
        return False
