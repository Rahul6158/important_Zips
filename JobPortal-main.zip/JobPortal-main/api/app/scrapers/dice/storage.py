"""
Dice.com database storage module
"""
import logging
from datetime import datetime
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session

from app.scrapers.common.models import JobData, VendorData, RecruiterData
from app.services.job_service import JobService
from app.services.recruiter_service import RecruiterService
from app.services.vendor_service import VendorService

logger = logging.getLogger(__name__)


def save_job_to_db(db: Session, job_data: JobData) -> Any:
    """
    Save job data to database
    
    Args:
        db: Database session
        job_data: Job data to save
        
    Returns:
        Saved job object
    """
    try:
        logger.info(f"Saving job to database: {job_data.job_title}")
        
        # 1. Process vendor if it exists
        vendor_id = _process_vendor(db, job_data) if job_data.job_vendor_id else None
        
        # 2. Process recruiter if it exists
        recruiter_id = _process_recruiter(db, job_data, vendor_id) if job_data.job_recruiter_id else None
        
        # 3. Save job
        job = _save_job(db, job_data, vendor_id, recruiter_id)
        
        # 4. Process skills
        if job_data.job_skills:
            JobService.update_job_skills(db, job.id, job_data.job_skills)
        
        logger.info(f"Job saved to database: {job.title} (ID: {job.job_id})")
        return job
    
    except Exception as e:
        logger.error(f"Error saving job to database: {e}")
        raise


def _process_vendor(db: Session, job_data: JobData) -> Optional[int]:
    """Process and save vendor data"""
    vendor_data = VendorData(
        vendor_id=job_data.job_vendor_id,
        name=job_data.job_vendor_name,
        url=job_data.job_vendor_url,
        description="",
        source=job_data.source,
        external_id=job_data.job_vendor_id,
        external_url=job_data.job_vendor_url or f"https://www.dice.com/company-profile/{job_data.job_vendor_id}"
    )
    
    vendor_dict = {
        "vendor_id": vendor_data.vendor_id,
        "name": vendor_data.name,
        "url": vendor_data.url,
        "description": vendor_data.description,
        "source": vendor_data.source,
        "external_id": vendor_data.external_id,
        "external_url": vendor_data.external_url
    }
    
    vendor = VendorService.create_or_update_vendor(db, vendor_dict)
    logger.info(f"Vendor processed: {vendor.name} (ID: {vendor.vendor_id})")
    return vendor.id


def _process_recruiter(db: Session, job_data: JobData, vendor_id: Optional[int]) -> Optional[int]:
    """Process and save recruiter data"""
    # Determine email - try to match recruiter name with email
    email = ""
    if job_data.application_cc_email and job_data.job_recruiter_name:
        first_name = job_data.job_recruiter_name.split()[0].lower()
        if first_name in job_data.application_cc_email.lower():
            email = job_data.application_cc_email
        else:
            email = job_data.application_email
    else:
        email = job_data.application_email
    
    recruiter_data = RecruiterData(
        recruiter_id=job_data.job_recruiter_id,
        name=job_data.job_recruiter_name,
        email=email,
        phone="",
        profile_url="",
        work_location="",
        vendor_id=vendor_id,
        source=job_data.source,
        external_id=job_data.job_recruiter_id,
        external_url=job_data.job_recruiter_url or f"https://www.dice.com/recruiter-profile?id={job_data.job_recruiter_id}"
    )
    
    recruiter_dict = {
        "recruiter_id": recruiter_data.recruiter_id,
        "name": recruiter_data.name,
        "email": recruiter_data.email,
        "phone": recruiter_data.phone,
        "profile_url": recruiter_data.profile_url,
        "work_location": recruiter_data.work_location,
        "vendor_id": recruiter_data.vendor_id,
        "source": recruiter_data.source,
        "external_id": recruiter_data.external_id,
        "external_url": recruiter_data.external_url
    }
    
    recruiter = RecruiterService.create_or_update_recruiter(db, recruiter_dict)
    logger.info(f"Recruiter processed: {recruiter.name} (ID: {recruiter.recruiter_id})")
    return recruiter.id


def _save_job(db: Session, job_data: JobData, vendor_id: Optional[int], recruiter_id: Optional[int]) -> Any:
    """Save job data to database"""
    # Parse dates if they exist
    date_posted = _parse_iso_date(job_data.date_posted)
    date_updated = _parse_iso_date(job_data.date_updated)
    date_first_active = _parse_iso_date(job_data.date_first_active)
    date_deactivated = _parse_iso_date(job_data.date_deactivated)
    
    # Create job data dictionary
    job_db_data = {
        "job_id": job_data.job_id,
        "title": job_data.job_title,
        "description": job_data.job_description,
        "yoe": job_data.yoe,
        "employment_details": job_data.job_employment_details,
        "requirements": job_data.job_requirements,
        "responsibilities": job_data.job_responsibilities,
        "location": job_data.job_location,
        "location_type": job_data.job_location_type,
        "rate": job_data.job_rate,
        "term": job_data.job_term,
        "vendor_id": vendor_id,
        "recruiter_id": recruiter_id,
        "date_posted": date_posted,
        "date_updated": date_updated,
        "date_first_active": date_first_active,
        "date_deactivated": date_deactivated,
        "posted_date_text": job_data.posted_date,
        "updated_date_text": job_data.updated_date,
        "application_email": job_data.application_email,
        "application_cc_email": job_data.application_cc_email,
        "application_type": job_data.application_type,
        "application_url": job_data.application_url,
        "source": job_data.source,
        "external_id": job_data.external_id,
        "external_url": job_data.external_url,
        "status": job_data.status or "active"
    }
    
    # Create or update job in database
    job = JobService.create_or_update_job(db, job_db_data)
    return job


def _parse_iso_date(date_str: Optional[str]) -> Optional[datetime]:
    """
    Parse ISO format date string to datetime object
    
    Args:
        date_str: ISO format date string
        
    Returns:
        Datetime object or None if parsing failed
    """
    if not date_str:
        return None
        
    try:
        return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
    except (ValueError, TypeError) as e:
        logger.warning(f"Failed to parse date: {date_str} - {e}")
        return None