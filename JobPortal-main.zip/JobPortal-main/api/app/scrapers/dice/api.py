"""
Dice.com API interaction module
"""
from urllib.parse import urlencode
from typing import Dict, List, Union, Any

# Constants
BASE_URL = "https://www.dice.com/platform/jobs"


def build_url(params: Dict[str, Any]) -> str:
    """
    Build a URL with the given parameters
    
    Args:
        params: Dictionary of URL parameters
        
    Returns:
        Complete URL string
    """
    return f"{BASE_URL}?{urlencode(params)}"


def get_search_params(
    q: str = "",
    posted_date: str = "SEVEN",  # e.g., "ONE", "TWO", "THREE", "SEVEN"
    workplace_types: Union[str, List[str]] = "Remote",  # "On-Site", "Remote", "Hybrid"
    employment_type: str = "THIRD_PARTY",  # "FULLTIME", "PARTTIME", "CONTRACT", "THIRD_PARTY"
    page: int = 1,
    page_size: int = 100
) -> Dict[str, Any]:
    """
    Generate search parameters for Dice.com job search
    
    Args:
        q: Search query
        posted_date: Filter for jobs posted within this time period
        workplace_types: Filter for workplace types
        employment_type: Filter for employment types
        page: Page number
        page_size: Number of results per page
        
    Returns:
        Dictionary of search parameters
    """
    # Handle multiple workplace types by joining them with pipe character
    if isinstance(workplace_types, list):
        workplace_types = "|".join(workplace_types)
    elif " " in workplace_types:  # If it's a space-separated string
        workplace_types = "|".join(workplace_types.split())
        
    return {
        "q": q,
        "countryCode": "US",
        # "radius": 30,
        # "radiusUnit": "mi",
        "page": page,
        "pageSize": page_size,
        "filters.postedDate": posted_date,
        "filters.workplaceTypes": workplace_types,
        "filters.employmentType": employment_type,
        "language": "en",
        # "eid": "8855"
    }


def get_job_url(job_id: str) -> str:
    """
    Get the URL for a job detail page
    
    Args:
        job_id: Job ID
        
    Returns:
        Job detail URL
    """
    return f"https://www.dice.com/job-detail/{job_id}"


def get_vendor_url(vendor_id: str) -> str:
    """Get the URL for a vendor profile page"""
    return f"https://www.dice.com/company-profile/{vendor_id}"


def get_recruiter_url(recruiter_id: str) -> str:
    """Get the URL for a recruiter profile page"""
    return f"https://www.dice.com/recruiter-profile?id={recruiter_id}"