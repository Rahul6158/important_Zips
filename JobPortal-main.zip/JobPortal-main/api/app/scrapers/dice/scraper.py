"""
Dice.com scraper module - Optimized Version
"""
import time
import math
import logging
import gc
from typing import List, Dict, Any, Optional, Set, Tuple
from bs4 import BeautifulSoup
from sqlalchemy.orm import Session
import concurrent.futures
from functools import partial

from app.database import get_db
from app.scrapers.common.models import JobData, ScraperConfig
from app.scrapers.common.driver import get_driver_with_retry, calculate_optimal_workers, wait_for_load
from app.scrapers.common.concurrency import process_in_parallel
from app.scrapers.dice.api import build_url, get_search_params, get_job_url
from app.scrapers.dice.parser import get_total_jobs, get_job_links, parse_job_details
from app.scrapers.dice.storage import save_job_to_db
from app.scrapers.dice.extractor import extract_job_details
from app.services.job_service import JobService
from app.models.job import Job
from datetime import datetime
from collections import defaultdict
from typing import Sequence, List, Tuple
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)


def extract_job_id_from_url(job_url: str) -> str:
    """Extract job ID from Dice job URL"""
    return job_url.split("/")[-1]


def get_existing_job_ids(db: Session, job_ids: List[str]) -> Set[str]:
    """
    Get set of job IDs that already exist in the database
    
    Args:
        db: Database session
        job_ids: List of job IDs to check
        
    Returns:
        Set of existing job IDs
    """
    existing_jobs = db.query(Job.job_id).filter(Job.job_id.in_(job_ids)).all()
    return {job.job_id for job in existing_jobs}


def update_job_status(db: Session, job_id: str, status: str = "active") -> bool:
    """
    Update the status of an existing job
    
    Args:
        db: Database session
        job_id: External job ID
        status: New status to set
        
    Returns:
        True if update was successful, False otherwise
    """
    try:
        job = db.query(Job).filter(Job.job_id == job_id).first()
        if job:
            job.status = status
            job.date_updated = datetime.utcnow()
            db.commit()
            logger.info(f"Updated status for job {job_id} to {status}")
            return True
        else:
            logger.warning(f"Job {job_id} not found for status update")
            return False
    except Exception as e:
        logger.error(f"Error updating job status for {job_id}: {e}")
        db.rollback()
        return False

def categorize_jobs(
    db: Session,
    job_urls: Sequence[str],
) -> Tuple[List[str], List[str]]:
    """
    Return two URL lists: those whose IDs already exist in the DB, and those that don't.
    """
    # 1️⃣ One pass: build a dict {job_id: [url, url, …]}
    urls_by_id: dict[str, list[str]] = defaultdict(list)
    for url in job_urls:
        urls_by_id[extract_job_id_from_url(url)].append(url)

    # 2️⃣ Set arithmetic on IDs
    provided_ids = set(urls_by_id)                       # all IDs we saw
    existing_ids = set(get_existing_job_ids(db, provided_ids))
    new_ids      = provided_ids - existing_ids           # set subtraction

    # 3️⃣ Flatten back to URLs (duplicates preserved, order within each ID preserved)
    existing_urls = [url for job_id in existing_ids for url in urls_by_id[job_id]]
    new_urls      = [url for job_id in new_ids      for url in urls_by_id[job_id]]

    logger.info(
        "Categorized jobs: %d existing, %d new",
        len(existing_urls),
        len(new_urls),
    )
    return existing_urls, new_urls


def update_existing_jobs_status(db: Session, job_urls: List[str]) -> int:
    """
    Update status for existing jobs
    
    Args:
        db: Database session
        job_urls: List of job URLs for existing jobs
        
    Returns:
        Number of successfully updated jobs
    """
    updated_count = 0
    
    # for job_url in job_urls:
    #     job_id = extract_job_id_from_url(job_url)
    #     if update_job_status(db, job_id, "active"):
    #         updated_count += 1
    
    # logger.info(f"Updated status for {updated_count}/{len(job_urls)} existing jobs")
    return updated_count


def scrape_jobs_optimized(
    db: Optional[Session] = None,
    config: Optional[ScraperConfig] = None
) -> Dict[str, Any]:
    """
    Optimized job scraping with existing job detection and status updates
    
    Args:
        db: Database session (optional)
        config: Scraper configuration (optional)
        
    Returns:
        Dictionary with scraping results
    """
    # Use default config if not provided
    if config is None:
        config = ScraperConfig()
    
    # Get database session if not provided
    if db is None:
        db = next(get_db())
        should_close_db = True
    else:
        should_close_db = False
    
    try:
        # Calculate optimal number of workers if not specified
        max_workers = config.max_workers or calculate_optimal_workers()
        logger.info(f"Using {max_workers} workers for parallel processing")
        
        # Build search parameters
        params = get_search_params(
            q=config.query,
            posted_date=config.posted_date,
            workplace_types=config.workplace_types,
            employment_type=config.employment_type,
            page=1,
            page_size=100
        )
        
        # Get the first page to determine total jobs
        job_links_first_page = []
        with get_driver_with_retry() as driver:
            url = build_url(params)
            logger.info(f"Fetching jobs from: {url}")
            driver.get(url)
            time.sleep(2)
            soup = BeautifulSoup(driver.page_source, "html.parser")
            total_jobs = get_total_jobs(soup)
            job_links_first_page = get_job_links(soup)
        
        logger.info(f"Found {total_jobs} total jobs matching search criteria")
        
        # Calculate number of pages to scrape
        jobs_per_page = 20
        total_pages = math.ceil(min(total_jobs, config.limit) / jobs_per_page)
        
        # Collect all job links
        all_job_links = job_links_first_page
        
        # If we need more pages, scrape them in parallel
        if total_pages > 1:
            remaining_pages = list(range(2, total_pages + 1))
            page_task = partial(get_page_links_task, search_params=params)
            
            page_results = process_in_parallel(
                page_task,
                remaining_pages,
                max_workers=max_workers,
                description="Collecting job links"
            )
            
            for links in page_results:
                if links:
                    all_job_links.extend(links)
        
        # Limit the number of jobs to process
        all_job_links = all_job_links[:config.limit]
        logger.info(f"Collected {len(all_job_links)} job links to process")
        
        # Categorize jobs into existing and new
        existing_job_urls, new_job_urls = categorize_jobs(db, all_job_links)
        
        # Update existing jobs status
        updated_count = update_existing_jobs_status(db, existing_job_urls)
        
        # Scrape only new jobs
        scraped_jobs = []
        if new_job_urls:
            logger.info(f"Scraping {len(new_job_urls)} new jobs")
            
            # Process new jobs in batches
            total_batches = math.ceil(len(new_job_urls) / config.batch_size)
            
            for i in range(0, len(new_job_urls), config.batch_size):
                batch = new_job_urls[i:i+config.batch_size]
                batch_num = i // config.batch_size + 1
                logger.info(f"Processing batch {batch_num}/{total_batches} ({len(batch)} new jobs)")
                
                batch_results = process_in_parallel(
                    get_job_details_task,
                    batch,
                    max_workers=max_workers,
                    description=f"Scraping batch {batch_num}/{total_batches}"
                )
                
                # for job_data in batch_results:
                #     if job_data:
                #         scraped_jobs.append(job_data)
                
                gc.collect()
        
        results = {
            "total_jobs_found": len(all_job_links),
            "existing_jobs": len(existing_job_urls),
            "existing_jobs_updated": updated_count,
            "new_jobs_found": len(new_job_urls),
            "new_jobs_scraped": len(scraped_jobs)
            # "scraped_jobs": scraped_jobs
        }
        
        logger.info(f"Scraping completed: {results}")
        return results
    
    except Exception as e:
        logger.error(f"Error in optimized scrape_jobs: {e}")
        raise
    finally:
        if should_close_db:
            db.close()


def run_daily_job_collection_optimized():
    """Run optimized daily job collection"""
    logger.info("Starting optimized daily job collection")
    
    db = next(get_db())
    
    try:
        # Scrape third-party jobs
        tp_config = ScraperConfig(
            query="",
            posted_date="ONE",
            workplace_types=["Remote", "Hybrid", "On-Site"],
            employment_type="THIRD_PARTY",
            limit=10000
        )
        tp_results = scrape_jobs_optimized(db=db, config=tp_config)
        
        # Scrape contract jobs
        contract_config = ScraperConfig(
            query="",
            posted_date="ONE",
            workplace_types=["Remote", "Hybrid", "On-Site"],
            employment_type="CONTRACTS",
            limit=10000
        )
        contract_results = scrape_jobs_optimized(db=db, config=contract_config)
        
        total_results = {
            "third_party": tp_results,
            "contracts": contract_results,
            "summary": {
                "total_existing_updated": tp_results["existing_jobs_updated"] + contract_results["existing_jobs_updated"],
                "total_new_scraped": tp_results["new_jobs_scraped"] + contract_results["new_jobs_scraped"]
            }
        }
        
        logger.info(f"Optimized daily job collection completed: {total_results['summary']}")
        return total_results
        
    except Exception as e:
        logger.error(f"Error in optimized daily job collection: {e}")
        raise
    finally:
        db.close()


# Update imports
from app.scrapers.common.driver import get_driver_optimized, calculate_optimal_workers, wait_for_load, shutdown_driver_pool

def get_job_details_task(job_url):
    """Extract and save job details for a single job URL"""
    with next(get_db()) as task_db:
        try:
            with get_driver_optimized() as driver:  # Changed from get_driver_with_retry
                job_data = extract_job_details(driver, job_url)
                if job_data:
                    save_job_to_db(task_db,job_data)
                    return job_data
        except Exception as e:
            logger.error(f"Error processing job {job_url}: {e}")
        return None

def get_page_links_task(page, search_params):
    params_copy = search_params.copy()
    params_copy["page"] = page
    url = build_url(params_copy)
    
    with get_driver_optimized() as driver:  # Changed from get_driver_with_retry
        driver.get(url)
        wait_for_load(driver)
        soup = BeautifulSoup(driver.page_source, "html.parser")
        links = get_job_links(soup)
        logger.info(f"Collected links from page {page} - {len(links)} jobs")
        return links

# Add cleanup function to be called when scraping is done
def cleanup_resources():
    """Cleanup driver pool resources"""
    shutdown_driver_pool()


def scrape_job_by_url(job_url: str, db: Optional[Session] = None) -> Optional[JobData]:
    """
    Scrape a single job by its URL and save it to the database
    
    Args:
        job_url: URL of the job to scrape
        db: Database session (optional)
        
    Returns:
        JobData object if successful, None otherwise
    """
    # Validate URL format
    if not job_url.startswith("https://www.dice.com/job-detail/"):
        logger.error(f"Invalid Dice job URL format: {job_url}")
        return None
        
    # Get database session if not provided
    if db is None:
        db = next(get_db())
        should_close_db = True
    else:
        should_close_db = False
        
    try:
        # Use the existing job details task function
        job_data = get_job_details_task(job_url)
        return job_data
    except Exception as e:
        logger.error(f"Error scraping job from URL {job_url}: {e}")
        return None
    finally:
        if should_close_db and db:
            db.close()
