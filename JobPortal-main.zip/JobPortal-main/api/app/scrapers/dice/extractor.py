"""
Dice.com data extraction module
"""
import json
import logging
import time
from typing import Dict, Any, Optional
from bs4 import BeautifulSoup
from selenium import webdriver

from app.scrapers.common.models import JobData
from app.scrapers.common.driver import wait_for_load
from app.scrapers.dice.parser import extract_years_of_experience, parse_location_type, extract_vendor_id

logger = logging.getLogger(__name__)


def extract_job_details(driver: webdriver.Chrome, job_url: str) -> Optional[JobData]:
    """
    Extract detailed information about a job from its page
    
    Args:
        driver: Selenium WebDriver instance
        job_url: URL of the job detail page
        
    Returns:
        JobData object with extracted information
    """
    try:
        driver.get(job_url)
        # time.sleep(2)
        wait_for_load(driver)
        soup = BeautifulSoup(driver.page_source, "html.parser")

        # Create a job data object
        job_id = job_url.split("/")[-1]
        job_data = JobData(
            job_id=job_id,
            source="dice",
            external_id=job_id,
            external_url=job_url
        )

        # Extract basic job information
        _extract_basic_job_info(soup, job_data)
        
        # Extract job details
        _extract_job_details(soup, job_data)
        
        # Extract vendor information
        _extract_vendor_info(soup, job_data)
        
        # Extract recruiter information
        _extract_recruiter_info(soup, job_data)
        
        # Extract dates
        _extract_dates(soup, job_data)
        
        # Extract additional data from JSON
        _extract_json_data(soup, job_data)
        
        # print("returning job_data",job_data)
        # break
        return job_data
        
    except Exception as e:
        logger.error(f"Error extracting job details from {job_url}: {e}")
        return None


def _extract_basic_job_info(soup: BeautifulSoup, job_data: JobData) -> None:
    """Extract basic job information"""
    # Title
    title_elem = soup.find("h1", {"data-cy": "jobTitle"})
    # print("title_elem is ",title_elem)
    job_data.job_title = title_elem.text.strip() if title_elem else ""
    # print("Ttiele is ",job_data.job_title)

    # Employment Details
    job_data.job_employment_details = [
        span.text.strip()
        for span in soup.find_all("span", id=lambda x: x and x.startswith("employmentDetailChip:"))
    ]

    # Job Location
    location_elem = soup.find("li", {"data-cy": "location"})
    job_data.job_location = location_elem.text.strip() if location_elem else ""

    # Job Location Type
    loc_span = soup.find("span", id=lambda x: x and x.startswith("location:"))
    if loc_span:
        job_data.job_location_type = parse_location_type(loc_span.text.strip())

    # Job Rate
    pay_elem = soup.find("div", {"data-cy": "payDetails"})
    if pay_elem:
        pay_span = pay_elem.find("span", id=lambda x: x and x.startswith("payChip:"))
        if pay_span:
            job_data.job_rate = pay_span.text.strip()


def _extract_job_details(soup: BeautifulSoup, job_data: JobData) -> None:
    """Extract detailed job information"""
    # Skills
    skills_container = soup.find("div", {"data-cy": "skillsList"})
    if skills_container:
        # Extract skills from the container
        job_data.job_skills = [
            span.text.strip()
            for span in skills_container.find_all("span", id=lambda x: x and x.startswith("skillChip:"))
        ]
    else:
        # Fallback to the original method if container not found
        job_data.job_skills = [
            span.text.strip()
            for span in soup.find_all("span", id=lambda x: x and x.startswith("skillChip:"))
        ]

    # Description
    desc_elem = soup.find("div", {"data-testid": "jobDescriptionHtml"})
    if desc_elem:
        job_data.job_description = desc_elem.get_text(separator="\n").strip()
        
        # Extract years of experience
        job_data.yoe = extract_years_of_experience(job_data.job_description)


def _extract_vendor_info(soup: BeautifulSoup, job_data: JobData) -> None:
    """Extract vendor information"""
    vendor_elem = soup.find("a", {"data-cy": "companyNameLink"})
    if vendor_elem:
        job_data.job_vendor_name = vendor_elem.text.strip()
        job_data.job_vendor_url = vendor_elem['href'] if vendor_elem.has_attr('href') else ""
    
        if job_data.job_vendor_url:
            job_data.job_vendor_id = extract_vendor_id(job_data.job_vendor_url)


def _extract_recruiter_info(soup: BeautifulSoup, job_data: JobData) -> None:
    """Extract recruiter information"""
    recruiter_elem = soup.find("p", {"data-cy": "recruiterName", "data-testid": "recruiterName"})
    job_data.job_recruiter_name = recruiter_elem.text.strip() if recruiter_elem else ""
    
    recruiter_second_elem = soup.find("p", {"data-cy": "recruiterCompany"})
    if recruiter_second_elem:
        job_data.job_recruiter_position = recruiter_second_elem.text.replace(
            job_data.job_vendor_name, ""
        ).strip()


def _extract_dates(soup: BeautifulSoup, job_data: JobData) -> None:
    """Extract date information"""
    time_elem = soup.find("span", {"id": "timeAgo"})
    if time_elem:
        time_text = time_elem.text
        # Example: "Posted 16 hours ago | Updated 16 hours ago"
        parts = [p.strip() for p in time_text.split('|')]
        for part in parts:
            if part.lower().startswith("posted"):
                job_data.posted_date = part.replace("Posted", "").strip()
            elif part.lower().startswith("updated"):
                job_data.updated_date = part.replace("Updated", "").strip()


def _extract_json_data(soup: BeautifulSoup, job_data: JobData) -> None:
    """Extract additional data from embedded JSON"""
    try:
        next_data_script = soup.find('script', id='__NEXT_DATA__')
        if not next_data_script:
            return
            
        json_data = json.loads(next_data_script.string)
        if not (json_data and 'props' in json_data and 'pageProps' in json_data['props']):
            return
            
        page_props = json_data['props']['pageProps']
        if not ('initialState' in page_props and 'api' in page_props['initialState']):
            return
            
        api_data = page_props['initialState']['api']
        if 'queries' not in api_data:
            return
            
        # Find the job data in queries
        for query_key, query_value in api_data['queries'].items():
            if query_key.startswith('getJobById') and 'data' in query_value:
                job_api_data = query_value['data']
                
                # Extract recruiter ID
                if 'recruiter' in job_api_data and 'recruiterId' in job_api_data['recruiter']:
                    job_data.job_recruiter_id = job_api_data['recruiter']['recruiterId']
                    job_data.job_recruiter_url = f"https://www.dice.com/recruiter-profile?id={job_data.job_recruiter_id}"
                                       
                # Extract application details
                if 'applicationDetail' in job_api_data:
                    app_detail = job_api_data['applicationDetail']
                    job_data.application_email = app_detail.get('email', '')
                    job_data.application_cc_email = app_detail.get('ccEmail', '')
                    job_data.application_type = app_detail.get('type', '')
                    job_data.application_url = app_detail.get('url', '')
                
                # Extract dates
                job_data.date_posted = job_api_data.get('datePosted', '')
                job_data.date_updated = job_api_data.get('dateUpdated', '')
                job_data.date_first_active = job_api_data.get('dateFirstActive', '')
                job_data.date_deactivated = job_api_data.get('dateDeactivated', '')
                job_data.status = job_api_data.get('status', '')
                
                # Extract employment term if available
                if 'employmentDetail' in job_api_data and 'contract' in job_api_data['employmentDetail']:
                    job_data.job_term = job_api_data['employmentDetail']['contract'].get('term', '')
                
                break
    except Exception as e:
        logger.error(f"Error extracting JSON data: {e}")