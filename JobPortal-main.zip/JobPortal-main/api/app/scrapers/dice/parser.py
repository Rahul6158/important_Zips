"""
Dice.com HTML parsing module
"""
import re
import time
import logging
from typing import List, Dict, Any, Optional
from bs4 import BeautifulSoup
from selenium.webdriver.remote.webdriver import WebDriver

from app.scrapers.common.models import JobData

logger = logging.getLogger(__name__)


def get_total_jobs(soup: BeautifulSoup) -> int:
    """
    Extract total number of job results from search results page
    
    Args:
        soup: BeautifulSoup object of the search results page
        
    Returns:
        Total number of jobs
    """
    # Look for the paragraph tag with the results count
    p_tag = soup.find("p", class_=lambda c: c and "text-sm" in c and "text-neutral-900" in c)
    
    if p_tag:
        # Extract the number from text like "1894 results (1894 new)"
        match = re.search(r"(\d+)\s+results", p_tag.text)
        if match:
            return int(match.group(1))
    
    # Fallback to looking for any paragraph with "results" in it
    p_tag = soup.find("p", string=lambda text: text and "results" in text.lower())
    if p_tag:
        match = re.search(r"(\d+)\s+results", p_tag.text)
        if match:
            return int(match.group(1))
            
    return 0  # Default if not found


def get_job_links(soup: BeautifulSoup) -> List[str]:
    """
    Extract job links from the search results page
    
    Args:
        soup: BeautifulSoup object of the search results page
        
    Returns:
        List of job IDs
    """
    links = []
    for a in soup.find_all("a", {"data-testid": "job-search-job-detail-link"}):
        job_id = a.get("href")
        if job_id:
            links.append(job_id)
    return links


def extract_years_of_experience(description: str) -> int:
    """
    Extract years of experience requirement from job description
    
    Args:
        description: Job description text
        
    Returns:
        Years of experience as an integer, or 0 if not found
    """
    # Common patterns for years of experience
    patterns = [
        r'(\d+)\+?\s*(?:to|-)\s*(\d+)\+?\s*years?(?:\s+of)?\s+experience',  # 3-5 years experience
        r'(\d+)\+?\s*years?(?:\s+of)?\s+experience',  # 5+ years experience
        r'experience\s*(?:of|:)?\s*(\d+)\+?\s*(?:to|-)\s*(\d+)\+?\s*years?',  # experience of 3-5 years
        r'experience\s*(?:of|:)?\s*(\d+)\+?\s*years?',  # experience of 5+ years
        r'minimum\s*(?:of)?\s*(\d+)\+?\s*years?(?:\s+of)?\s+experience',  # minimum of 3 years experience
        r'at\s*least\s*(\d+)\+?\s*years?(?:\s+of)?\s+experience',  # at least 3 years experience
    ]
    
    # Check each pattern
    for pattern in patterns:
        match = re.search(pattern, description, re.IGNORECASE)
        if match:
            # If range (e.g., 3-5 years), use the lower bound
            if len(match.groups()) > 1 and match.group(2):
                return int(match.group(1))
            # If single value (e.g., 5+ years)
            else:
                return int(match.group(1))
    
    return 0  # Return 0 if no match found


def parse_location_type(location_text: str) -> str:
    """
    Parse location type from location text
    
    Args:
        location_text: Location text from job listing
        
    Returns:
        Standardized location type: "Remote", "Hybrid", "On-Site", or empty string
    """
    location_text = location_text.lower()
    
    if "remote" in location_text:
        return "Remote"
    elif "hybrid" in location_text:
        return "Hybrid"
    elif "on-site" in location_text or "onsite" in location_text or "on site" in location_text:
        return "On-Site"
    
    return ""  # Return empty string if no match found


def extract_vendor_id(vendor_url: str) -> str:
    """
    Extract vendor ID from vendor URL
    
    Args:
        vendor_url: URL of the vendor profile page
        
    Returns:
        Vendor ID as a string, or empty string if not found
    """
    # Example URL: https://www.dice.com/company-profile/some-company-id
    if not vendor_url:
        return ""
        
    # Extract the last part of the URL path
    parts = vendor_url.rstrip('/').split('/')
    if parts and len(parts) > 0:
        return parts[-1]
    
    return ""


def parse_job_details(driver: WebDriver, job_url: str) -> Optional[JobData]:
    """
    Extract detailed information about a job from its page
    
    Args:
        driver: Selenium WebDriver
        job_url: URL of the job detail page
        
    Returns:
        JobData object or None if parsing failed
    """
    try:
        driver.get(job_url)
        time.sleep(2)
        soup = BeautifulSoup(driver.page_source, "html.parser")
        
        # Extract job ID from URL
        job_id = job_url.split("/")[-1]
        
        # Extract job title first
        title_elem = soup.find("h1", {"data-cy": "jobTitle"})
        job_title = title_elem.text.strip() if title_elem else ""
        
        # Extract job description
        desc_elem = soup.find("div", {"data-testid": "jobDescriptionHtml"})
        job_description = desc_elem.get_text(separator="\n").strip() if desc_elem else ""
        
        # Extract years of experience
        yoe = extract_years_of_experience(job_description)
        
        # Create a JobData object with required parameters
        job_data = JobData(
            job_id=job_id,
            job_title=job_title,  # Required parameter
            job_description=job_description,  # Required parameter
            source="dice",
            external_id=job_id,
            external_url=job_url,
            status="active",
            yoe=yoe
        )
        
        # Extract employment details
        job_data.job_employment_details = [
            span.text.strip()
            for span in soup.find_all("span", id=lambda x: x and x.startswith("employmentDetailChip:"))
        ]
        
        # Extract job location
        location_elem = soup.find("li", {"data-cy": "location"})
        job_data.job_location = location_elem.text.strip() if location_elem else ""
        
        # Extract job location type
        loc_span = soup.find("span", id=lambda x: x and x.startswith("location:"))
        if loc_span:
            job_data.job_location_type = parse_location_type(loc_span.text.strip())
        
        # Extract job rate/pay
        pay_elem = soup.find("div", {"data-cy": "payDetails"})
        if pay_elem:
            pay_span = pay_elem.find("span", id=lambda x: x and x.startswith("payChip:"))
            if pay_span:
                job_data.job_rate = pay_span.text.strip()
        
        # Extract skills
        skills_container = soup.find("div", {"data-cy": "skillsList"})
        if skills_container:
            job_data.job_skills = [
                span.text.strip()
                for span in skills_container.find_all("span", id=lambda x: x and x.startswith("skillChip:"))
            ]
        else:
            job_data.job_skills = [
                span.text.strip()
                for span in soup.find_all("span", id=lambda x: x and x.startswith("skillChip:"))
            ]
        
        # Extract vendor information
        vendor_elem = soup.find("a", {"data-cy": "companyNameLink"})
        if vendor_elem:
            job_data.job_vendor_name = vendor_elem.text.strip()
            job_data.job_vendor_url = vendor_elem['href'] if vendor_elem.has_attr('href') else ""
        
            if job_data.job_vendor_url:
                job_data.job_vendor_id = extract_vendor_id(job_data.job_vendor_url)
        
        # Extract recruiter information
        recruiter_elem = soup.find("p", {"data-cy": "recruiterName", "data-testid": "recruiterName"})
        job_data.job_recruiter_name = recruiter_elem.text.strip() if recruiter_elem else ""
        
        recruiter_second_elem = soup.find("p", {"data-cy": "recruiterCompany"})
        if recruiter_second_elem and job_data.job_vendor_name:
            job_data.job_recruiter_position = recruiter_second_elem.text.replace(
                job_data.job_vendor_name, ""
            ).strip()
        
        # Extract date information
        time_elem = soup.find("span", {"id": "timeAgo"})
        if time_elem:
            time_text = time_elem.text
            # Example: "Posted 16 hours ago | Updated 16 hours ago"
            parts = [p.strip() for p in time_text.split('|')]
            for part in parts:
                if part.lower().startswith("posted"):
                    job_data.posted_date = part.replace("Posted", "").strip()
                elif part.lower().startswith("updated"):
                    job_data.updated_date = part.replace("Updated", "").strip()
        
        # Extract additional data from embedded JSON
        try:
            import json
            next_data_script = soup.find('script', id='__NEXT_DATA__')
            if next_data_script:
                json_data = json.loads(next_data_script.string)
                if json_data and 'props' in json_data and 'pageProps' in json_data['props']:
                    page_props = json_data['props']['pageProps']
                    if 'initialState' in page_props and 'api' in page_props['initialState']:
                        api_data = page_props['initialState']['api']
                        if 'queries' in api_data:
                            # Find the job data in queries
                            for query_key, query_value in api_data['queries'].items():
                                if query_key.startswith('getJobById') and 'data' in query_value:
                                    job_api_data = query_value['data']
                                    
                                    # Extract recruiter ID
                                    if 'recruiter' in job_api_data and 'recruiterId' in job_api_data['recruiter']:
                                        job_data.job_recruiter_id = job_api_data['recruiter']['recruiterId']
                                        job_data.job_recruiter_url = f"https://www.dice.com/recruiter-profile?id={job_data.job_recruiter_id}"
                                                   
                                    # Extract application details
                                    if 'applicationDetail' in job_api_data:
                                        app_detail = job_api_data['applicationDetail']
                                        job_data.application_email = app_detail.get('email', '')
                                        job_data.application_cc_email = app_detail.get('ccEmail', '')
                                        job_data.application_type = app_detail.get('type', '')
                                        job_data.application_url = app_detail.get('url', '')
                                    
                                    # Extract dates
                                    job_data.date_posted = job_api_data.get('datePosted', '')
                                    job_data.date_updated = job_api_data.get('dateUpdated', '')
                                    job_data.date_first_active = job_api_data.get('dateFirstActive', '')
                                    job_data.date_deactivated = job_api_data.get('dateDeactivated', '')
        except Exception as e:
            logger.warning(f"Error extracting JSON data: {e}")
        # print("This is job data: {job_data}")
        # break
        return job_data
    except Exception as e:
        logger.error(f"Error parsing job details for {job_url}: {e}")
        return None