from fastapi import APIRouter, Depends, BackgroundTasks
from sqlalchemy.orm import Session

from app.api.routes import jobs, recruiters, vendors, scraper, analytics, tailor, auth, profile
from app.database import get_db, SessionLocal
# from app.scrapers.dice_scraper import run_daily_job_collection
from app.scrapers.dice.scraper import run_daily_job_collection_optimized

api_router = APIRouter()
api_router.include_router(jobs.router, prefix="/api/jobs", tags=["jobs"])
api_router.include_router(recruiters.router, prefix="/api/recruiters", tags=["recruiters"])
api_router.include_router(vendors.router, prefix="/api/vendors", tags=["vendors"])
api_router.include_router(scraper.router, prefix="/api/scrape-jobs", tags=["scraper"])
api_router.include_router(analytics.router, prefix="/api/analytics", tags=["analytics"])
api_router.include_router(tailor.router, prefix="/api/tailor", tags=["tailor"])
api_router.include_router(auth.router, prefix="/api/auth", tags=["auth"])
api_router.include_router(profile.router, prefix="/api/profile", tags=["profile"])

# Add direct route for daily collection with robust Chrome options
@api_router.get("/api/run-daily-collection", tags=["scraper"])
def api_run_daily_collection(
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """Run daily job collection with robust Chrome configuration"""
    # Create a new session for the background task
    db_session = SessionLocal()
    
    # Pass the session to the background task
    background_tasks.add_task(run_daily_job_collection_optimized)
    
    return {"status": "success", "message": "Daily job collection started in background"}