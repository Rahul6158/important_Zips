from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel

from app.database import get_db
from app.schemas.job import Job as JobSchema  # Renamed to avoid confusion
from app.services.job_service import JobService

router = APIRouter()

class JobsResponse(BaseModel):
    jobs: List[JobSchema]
    total: int
    
    class Config:
        from_attributes = True

@router.get("/all", response_model=JobsResponse)
def get_jobs(
    skip: int = 0,
    limit: int = 100,
    q: Optional[str] = Query(None, description="Search term for job title or description"),
    location: Optional[str] = Query(None, description="Filter by job location"),
    employment_type: Optional[str] = Query(None, description="Filter by employment type"),
    location_type: Optional[str] = Query(None, description="Filter by location type (Remote, Hybrid, On Site)"),
    skill: Optional[str] = Query(None, description="Filter by required skill"),
    skills: Optional[str] = Query(None, description="Filter by multiple required skills (comma-separated)"),
    rate: Optional[str] = Query(None, description="Filter by rate/salary"),
    term: Optional[str] = Query(None, description="Filter by job term (Contract, Contract-to-Hire, etc.)"),
    recruiter_id: Optional[int] = Query(None, description="Filter by recruiter ID"),
    vendor_id: Optional[int] = Query(None, description="Filter by vendor ID"),
    status: Optional[str] = Query("Active", description="Filter by job status"),
    sort: Optional[str] = Query("posted_date", description="Field to sort by"),
    order: Optional[str] = Query("desc", description="Sort order (asc or desc)"),
    date_filter: Optional[str] = Query(None, description="Filter by posting date (24h, 48h, 72h)"),
    db: Session = Depends(get_db)
):
    """Get a list of jobs with optional filtering, with pagination and total count"""
    jobs, total = JobService.get_jobs_with_total(
        db, 
        skip=skip, 
        limit=limit,
        q=q,
        location=location,
        employment_type=employment_type,
        location_type=location_type,
        skill=skill,
        skills=skills,
        rate=rate,
        term=term,
        recruiter_id=recruiter_id,
        vendor_id=vendor_id,
        status=status,
        sort=sort,
        order=order,
        date_filter=date_filter
    )
    return {"jobs": jobs, "total": total}

@router.get("/{job_id}", response_model=JobSchema)
def get_job(
    job_id: str,
    db: Session = Depends(get_db)
):
    """Get a specific job by external ID (job_id)"""
    job = JobService.get_job_by_id(db, job_id=job_id)
    if not job:
        # Try to parse as integer for internal ID
        try:
            internal_id = int(job_id)
            job = JobService.get_job_by_internal_id(db, internal_id=internal_id)
        except ValueError:
            # Not an integer, so just continue with job=None
            pass
            
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job
