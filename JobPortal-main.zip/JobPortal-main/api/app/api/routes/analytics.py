from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List, Dict, Any

from app.database import get_db
from app.services.analytics_service import AnalyticsService

router = APIRouter()

@router.get("/test", response_model=Dict[str, str])
def test_analytics_endpoint():
    """Test endpoint to verify analytics router is working"""
    return {"status": "ok", "message": "Analytics API is working"}

@router.get("/skills", response_model=List[Dict[str, Any]])
def get_job_stats_by_skill(
    limit: int = 20,
    db: Session = Depends(get_db)
):
    """Get statistics about the number of jobs per skill"""
    return AnalyticsService.get_job_stats_by_skill(db, limit=limit)

@router.get("/locations", response_model=List[Dict[str, Any]])
def get_job_stats_by_location(
    limit: int = 10,
    db: Session = Depends(get_db)
):
    """Get statistics about the number of jobs per location"""
    return AnalyticsService.get_job_stats_by_location(db, limit=limit)

@router.get("/skills/all", response_model=List[str])
def get_unique_skills(
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get a list of unique skills from all jobs"""
    return AnalyticsService.get_unique_skills(db, limit=limit)

@router.get("/locations/all", response_model=List[str])
def get_unique_locations(
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get a list of unique locations from all jobs"""
    return AnalyticsService.get_unique_locations(db, limit=limit)