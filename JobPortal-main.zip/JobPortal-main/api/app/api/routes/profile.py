from fastapi import APIRouter, Depends, HTTPException, Header, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import Dict, List, Optional,Any
import jwt
import json
import logging

from app.database import get_db
from app.schemas.user import User as UserSchema
from app.schemas.skill import Skill as SkillSchema
from app.services.user_service import UserService
from app.services.s3_service import S3Service
from app.config import settings

router = APIRouter()
logger = logging.getLogger("job_portal_api")

@router.post("/upload-resume", response_model=UserSchema)
async def upload_resume(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None)
):
    """Upload a resume for the current user"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header is missing")
    
    try:
        # Extract the token from the Authorization header
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Invalid authentication scheme")
        
        # Decode the token to get user information
        payload = jwt.decode(token, options={"verify_signature": False})
        email = payload.get("email")
        
        # Get user from database by email
        user = UserService.get_user_by_email(db, email)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Check if user has candidate role
        # Convert roles to list if it's a string
        if isinstance(user.roles, str):
            try:
                roles = json.loads(user.roles)
            except json.JSONDecodeError:
                roles = [r.strip() for r in user.roles.strip('[]').split(',')]
        else:
            roles = user.roles or []
            
        if "candidate" not in roles:
            logger.warning(f"User {email} attempted to upload resume but doesn't have candidate role")
            raise HTTPException(status_code=403, detail="Only candidates can upload resumes")
        
        # Check file type
        content_type = file.content_type
        if content_type not in ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword"]:
            raise HTTPException(status_code=400, detail="Only PDF and Word documents are allowed")
        
        # Upload file to S3
        s3_service = S3Service()
        # Use username for organizing files
        username = user.username or f"user_{user.id}"
        
        # Create a filename that includes the username path
        filename = f"{username}/resume_{file.filename}"
        
        # Call upload_file without the prefix parameter
        resume_url = s3_service.upload_file(file.file, content_type=content_type, file_name=filename)
        
        # Update user with resume URL and path
        user_data = {
            "resume_url": resume_url,
            "resume_path": filename,  # Store the S3 path
            "resume_uploaded": True   # Set upload status to True
        }
        updated_user = UserService.update_user(db, user.id, user_data)
        
        return updated_user
        
    except HTTPException as he:
        # Re-raise HTTP exceptions directly to preserve status codes
        logger.error(f"Resume upload error: {he.status_code}: {he.detail}")
        raise he
    except Exception as e:
        # For other exceptions, log and return 500
        logger.error(f"Resume upload error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to upload resume: {str(e)}")

@router.post("/update-skills", response_model=UserSchema)
async def update_skills(
    skill_ids: List[int],
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None)
):
    """Update skills for the current user"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header is missing")
    
    try:
        # Extract the token from the Authorization header
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Invalid authentication scheme")
        
        # Decode the token to get user information
        payload = jwt.decode(token, options={"verify_signature": False})
        email = payload.get("email")
        
        # Get user from database by email
        user = UserService.get_user_by_email(db, email)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Update user skills
        updated_user = UserService.update_user_skills(db, user.id, skill_ids)
        
        return updated_user
        
    except Exception as e:
        logger.error(f"Skills update error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to update skills: {str(e)}")

@router.post("/extract-skills", response_model=List[SkillSchema])
async def extract_skills_from_resume(
    resume_data: Dict[str, str],
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None)
):
    """Extract skills from a resume"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header is missing")
    
    try:
        # Extract the token from the Authorization header
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Invalid authentication scheme")
        
        # Decode the token to get user information
        payload = jwt.decode(token, options={"verify_signature": False})
        email = payload.get("email")
        
        # Get user from database by email
        user = UserService.get_user_by_email(db, email)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Check if user has candidate role
        roles = user.roles.split(",") if user.roles else []
        if "candidate" not in roles:
            raise HTTPException(status_code=403, detail="Only candidates can extract skills from resumes")
        
        # Get resume URL from request
        resume_url = resume_data.get("resume_url")
        if not resume_url:
            raise HTTPException(status_code=400, detail="Resume URL is required")
        
        # TODO: Implement actual skill extraction logic
        # For now, we'll return a placeholder implementation
        # In a real implementation, you would:
        # 1. Download the resume from S3
        # 2. Parse it using a library like PyPDF2 or python-docx
        # 3. Use NLP to extract skills (or call an external API)
        # 4. Match extracted skills with skills in the database
        
        # Placeholder: Return some common skills
        common_skills = ["Python", "JavaScript", "React", "SQL", "AWS"]
        skills = []
        
        for skill_name in common_skills:
            # Find or create skill in database
            skill = UserService.find_or_create_skill(db, skill_name)
            skills.append(skill)
        
        return skills
        
    except Exception as e:
        logger.error(f"Skill extraction error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to extract skills: {str(e)}")

@router.get("/resume-status", response_model=Dict[str, Any])
async def get_resume_status(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None)
):
    """Get the resume upload status for the current user"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header is missing")
    
    try:
        # Extract the token from the Authorization header
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Invalid authentication scheme")
        
        # Decode the token to get user information
        payload = jwt.decode(token, options={"verify_signature": False})
        email = payload.get("email")
        
        # Get user from database by email
        user = UserService.get_user_by_email(db, email)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Return resume status information
        return {
            "resume_uploaded": user.resume_uploaded or False,
            "resume_url": user.resume_url,
            "resume_path": user.resume_path,
            "filename": user.resume_path.split('/')[-1] if user.resume_path else None
        }
        
    except Exception as e:
        logger.error(f"Resume status retrieval error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get resume status: {str(e)}")