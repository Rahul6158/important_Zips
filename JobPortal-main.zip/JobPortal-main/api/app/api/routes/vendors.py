from fastapi import APIRouter, Depends, HTTPException, Path
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.schemas.vendor import Vendor, VendorWithStats
from app.services.vendor_service import VendorService

router = APIRouter()

@router.get("/all", response_model=List[VendorWithStats])
def get_vendors(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get a list of vendors with additional statistics"""
    vendors = VendorService.get_vendors_with_stats(db, skip=skip, limit=limit)
    return vendors

@router.get("/{vendor_id}", response_model=Vendor)
def get_vendor(
    vendor_id: str = Path(..., description="The ID of the vendor (can be external or internal)"),
    db: Session = Depends(get_db)
):
    """Get a specific vendor by ID (tries both external and internal)"""
    # First try as external ID
    vendor = VendorService.get_vendor_by_id(db, vendor_id=vendor_id)
    
    # If not found, try parsing as internal ID
    if not vendor:
        try:
            internal_id = int(vendor_id)
            vendor = VendorService.get_vendor_by_internal_id(db, internal_id=internal_id)
        except (ValueError, TypeError):
            # Not an integer, so just continue with vendor=None
            pass
    
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    return vendor

# Keep the internal endpoint for explicit internal ID access
@router.get("/internal/{internal_id}", response_model=Vendor)
def get_vendor_by_internal_id(
    internal_id: int = Path(..., description="The internal ID of the vendor"),
    db: Session = Depends(get_db)
):
    """Get a specific vendor by internal ID"""
    vendor = VendorService.get_vendor_by_internal_id(db, internal_id=internal_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    return vendor