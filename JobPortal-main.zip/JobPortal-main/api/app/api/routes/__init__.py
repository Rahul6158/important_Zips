from fastapi import APIRouter
from app.api.routes import jobs, recruiters, vendors, scraper, auth

api_router = APIRouter()

api_router.include_router(jobs.router, prefix="/jobs", tags=["jobs"])
api_router.include_router(recruiters.router, prefix="/recruiters", tags=["recruiters"])
api_router.include_router(vendors.router, prefix="/vendors", tags=["vendors"])
api_router.include_router(scraper.router, tags=["scraper"])
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])

__all__ = ["api_router"]