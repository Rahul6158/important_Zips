from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any
import json
import jwt
from datetime import datetime
import logging

from app.database import get_db
from app.schemas.user import User as UserSchema, UserCreate
from app.services.user_service import UserService
from app.config import settings

router = APIRouter()
logger = logging.getLogger("job_portal_api")

@router.post("/validate-token", response_model=UserSchema)
async def validate_token(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None)
):
    """
    Validate the authentication token and return user information
    
    This endpoint:
    1. Validates the token format
    2. Verifies the token with the auth provider
    3. Creates a user if they don't exist in our database
    4. Returns the user profile
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header is missing")
    
    try:
        # Extract the token from the Authorization header
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Invalid authentication scheme")
        
        # Decode the token to get user information
        try:
            # For development, we're just decoding without verification
            # In production, use the proper verification with your auth provider's public key
            payload = jwt.decode(token, options={"verify_signature": False})
            print("payload:",payload)
            # Extract user information from the token
            email = payload.get("email")
            name = payload.get("name", "")
            
            # Extract username from the token if available
            username = payload.get("preferred_username", "")
            
            # Split name into first and last name (simple approach)
            name_parts = name.split(" ", 1)
            first_name = name_parts[0] if name_parts else ""
            last_name = name_parts[1] if len(name_parts) > 1 else ""
            
            # Get roles from the token
            realm_roles = payload.get("realm_access", {}).get("roles", [])
            client_id = settings.OIDC_CLIENT_ID
            client_roles = payload.get("resource_access", {}).get(client_id, {}).get("roles", [])
            roles = realm_roles #list(set(realm_roles))# + client_roles))  # Combine and deduplicate roles
        except jwt.PyJWTError as e:
            logger.error(f"JWT decode error: {str(e)}")
            raise HTTPException(status_code=401, detail="Invalid token format")
        
        # Check if user exists in our database by email instead of external_id
        user = UserService.get_user_by_email(db, email)
        
        if user:
            # Update username if it has changed
            if username and user.username != username:
                user.username = username
                
            # Update roles if they have changed - ensure they're stored as a list
            # if roles:
            #     user.roles = json.dumps(roles)
                
            db.commit()
            db.refresh(user)
            
            # Update last login time
            UserService.update_last_login(db, user.id)
        else:
            # Create new user without external_id
            user_data = {
                "email": email,
                "username": username,  # Add username
                "first_name": first_name,
                "last_name": last_name,
                "roles": roles,
                "last_login": datetime.utcnow(),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            user = UserService.create_user(db, user_data)
            logger.info(f"Created new user: {email}")
        
        return user
        
    except Exception as e:
        logger.error(f"Token validation error: {str(e)}")
        raise HTTPException(status_code=401, detail="Invalid token")

@router.get("/profile", response_model=UserSchema)
async def get_user_profile(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None)
):
    """Get the current user's profile"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header is missing")
    
    try:
        # Extract the token from the Authorization header
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Invalid authentication scheme")
        
        # Decode the token to get user information
        payload = jwt.decode(token, options={"verify_signature": False})
        email = payload.get("email")
        
        # Get user from database by email
        user = UserService.get_user_by_email(db, email)
        print("user:",user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return user
        
    except Exception as e:
        logger.error(f"Profile retrieval error: {str(e)}")
        raise HTTPException(status_code=401, detail="Invalid token")

@router.put("/profile", response_model=UserSchema)
async def update_user_profile(
    user_data: Dict[str, Any],
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None)
):
    """Update the current user's profile"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header is missing")
    
    try:
        # Extract the token from the Authorization header
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Invalid authentication scheme")
        
        # Decode the token to get user information
        payload = jwt.decode(token, options={"verify_signature": False})
        email = payload.get("email")
        
        # Get user from database by email
        user = UserService.get_user_by_email(db, email)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Update user profile
        updated_user = UserService.update_user(db, user.id, user_data)
        return user
        
    except Exception as e:
        logger.error(f"Profile update error: {str(e)}")
        raise HTTPException(status_code=401, detail="Invalid token")