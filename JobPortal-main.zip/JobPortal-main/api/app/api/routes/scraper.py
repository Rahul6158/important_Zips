from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException
from sqlalchemy.orm import Session
import logging

from app.database import get_db
from app.schemas.scraper import ScrapeJobsRequest, ScrapeJobUrlRequest
from app.scrapers.dice.scraper import scrape_jobs_optimized, run_daily_job_collection_optimized, scrape_job_by_url

router = APIRouter()
logger = logging.getLogger("job_portal_api")

@router.post("/scrape-jobs")
def api_scrape_jobs(
    background_tasks: BackgroundTasks,
    request: ScrapeJobsRequest,
    db: Session = Depends(get_db)
):
    """Trigger a job scraping task in the background"""
    # Validate request parameters
    query = request.query.strip() if request.query else ""
    posted_date = request.posted_date if request.posted_date else None
    workplace_types = request.workplace_types if request.workplace_types else []
    employment_type = request.employment_type if request.employment_type else None
    limit = max(1, min(request.limit, 1000)) if request.limit else 100  # Limit between 1 and 1000, default 100
    
    background_tasks.add_task(
        scrape_jobs_optimized,
        db=db,
        query=query,
        posted_date=posted_date,
        workplace_types=workplace_types,
        employment_type=employment_type,
        limit=limit
    )
    return {"message": f"Job scraping started in the background with limit: {limit}"}

@router.get("/run-daily-collection")
def trigger_daily_collection(background_tasks: BackgroundTasks):
    """Manually trigger the daily job collection"""
    try:
        background_tasks.add_task(run_daily_job_collection_optimized)
        return {"message": "Daily job collection started in the background"}
    except Exception as e:
        logger.error(f"Error starting daily job collection: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to start job collection: {str(e)}")

@router.post("/scrape-job-url")
def api_scrape_job_url(
    request: ScrapeJobUrlRequest,
    db: Session = Depends(get_db)
):
    """Scrape a single job by its URL and update it in the database"""
    # Validate URL format
    if not request.job_url.startswith("https://www.dice.com/job-detail/"):
        raise HTTPException(status_code=400, detail="Invalid Dice job URL format")
        
    try:
        job_data = scrape_job_by_url(request.job_url, db=db)
        if job_data:
            return {
                "status": "success",
                "message": f"Successfully scraped and updated job: {job_data.job_title}",
                "job_id": job_data.job_id
            }
        else:
            raise HTTPException(status_code=404, detail="Failed to scrape job from the provided URL")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error scraping job: {str(e)}")