from fastapi import APIRouter, File, Form, UploadFile, HTTPException
from fastapi.responses import FileResponse
import os
from app.tailor.resume_tailor import ResumeTailor

router = APIRouter()
resume_tailor = ResumeTailor()

@router.post("/tailor-resume")
async def tailor_resume(
    resume: UploadFile = File(...),
    job_description: str = Form(...)
):
    """
    Tailor a resume to match a job description
    
    - **resume**: .docx file containing the original resume
    - **job_description**: Text of the job description
    """
    if not resume.filename.endswith('.docx'):
        raise HTTPException(status_code=400, detail="Only .docx files are supported")
    
    try:
        # Read the uploaded file content
        resume_content = await resume.read()
        
        # Process the resume
        tailored_resume_path = resume_tailor.tailor_resume(resume_content, job_description)
        
        # Return the tailored resume as a downloadable file
        return FileResponse(
            path=tailored_resume_path,
            filename="tailored_resume.docx",
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error tailoring resume: {str(e)}")