from fastapi import APIRouter, Depends, HTTPException, Path
from sqlalchemy.orm import Session
from typing import List
from sqlalchemy import func

from app.database import get_db
from app.schemas.recruiter import Recruiter
from app.services.recruiter_service import RecruiterService
from app.models.job import Job
from app.models.recruiter import Recruiter as RecruiterModel

router = APIRouter()

@router.get("/all", response_model=List[Recruiter])
def get_recruiters(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get a list of recruiters with job counts"""
    # Get recruiters with job counts using a subquery
    recruiters_with_counts = RecruiterService.get_recruiters_with_job_counts(db, skip=skip, limit=limit)
    return recruiters_with_counts

@router.get("/{recruiter_id}", response_model=Recruiter)
def get_recruiter(
    recruiter_id: str = Path(..., description="The ID of the recruiter (can be external or internal)"),
    db: Session = Depends(get_db)
):
    """Get a specific recruiter by ID (tries both external and internal)"""
    # First try as external ID
    recruiter = RecruiterService.get_recruiter_by_id_with_job_count(db, recruiter_id=recruiter_id)
    
    # If not found, try parsing as internal ID
    if not recruiter:
        try:
            internal_id = int(recruiter_id)
            recruiter = RecruiterService.get_recruiter_by_internal_id_with_job_count(db, internal_id=internal_id)
        except (ValueError, TypeError):
            # Not an integer, so just continue with recruiter=None
            pass
    
    if not recruiter:
        raise HTTPException(status_code=404, detail="Recruiter not found")
    return recruiter

# Keep the internal endpoint for explicit internal ID access
@router.get("/internal/{internal_id}", response_model=Recruiter)
def get_recruiter_by_internal_id(
    internal_id: int = Path(..., description="The internal ID of the recruiter"),
    db: Session = Depends(get_db)
):
    """Get a specific recruiter by internal ID with job count"""
    recruiter = RecruiterService.get_recruiter_by_internal_id_with_job_count(db, internal_id=internal_id)
    if not recruiter:
        raise HTTPException(status_code=404, detail="Recruiter not found")
    return recruiter