from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from app.models.base import Base

class JobSkill(Base):
    __tablename__ = 'job_skills'
    
    id = Column(Integer, primary_key=True)
    job_id = Column(Integer, ForeignKey('jobs.id'), nullable=False)
    skill_name = Column(String(100), nullable=False)
    
    # Relationship
    job = relationship("Job", back_populates="skills")
    
    def __repr__(self):
        return f"<JobSkill {self.skill_name}>"