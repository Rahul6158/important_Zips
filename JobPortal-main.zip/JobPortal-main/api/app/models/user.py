from sqlalchemy import Column, Integer, String, DateTime, Boolean, JSON, Text
from sqlalchemy.sql import func
from app.models.base import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    # external_id = Column(String(255), unique=True, index=True)  # Add this column
    email = Column(String(255), unique=True, index=True)
    username = Column(String(255), nullable=True)  # Add username field
    first_name = Column(String(255))
    last_name = Column(String(255))
    phone_number = Column(String(50), nullable=True)
    smtp_server = Column(String(255), nullable=True)
    smtp_port = Column(Integer, nullable=True)
    smtp_username = Column(String(255), nullable=True)
    smtp_password = Column(String(255), nullable=True)
    smtp_from_email = Column(String(255), nullable=True)
    roles = Column(Text, nullable=True)  # Stored as JSON string
    is_active = Column(Boolean, default=True)
    resume_url = Column(String(255), nullable=True)  # URL to the resume in S3
    resume_path = Column(String(255), nullable=True)  # Path to the resume in S3
    resume_uploaded = Column(Boolean, default=False)  # Status of resume upload
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    last_login = Column(DateTime(timezone=True), nullable=True)