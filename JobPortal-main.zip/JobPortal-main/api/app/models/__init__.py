# Import Base first
from app.models.base import Base

# Import models without relationships first
from app.models.vendor import Vendor
from app.models.recruiter import Recruiter
from app.models.skill import Skill
from app.models.job import Job

# Import models with relationships last
from app.models.job_skill import JobSkill

# This ensures all models are registered with the Base metadata
__all__ = ['Base', 'Vendor', 'Recruiter', 'Skill', 'Job', 'JobSkill']