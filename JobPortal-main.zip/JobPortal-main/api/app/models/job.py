from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
import json

from app.models.base import Base

class Job(Base):
    __tablename__ = "jobs"
    
    id = Column(Integer, primary_key=True)
    job_id = Column(String(100), unique=True, nullable=False)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    requirements = Column(Text)
    responsibilities = Column(Text)
    job_type = Column(String(100))
    location = Column(String(200))
    location_type = Column(String(100))
    rate = Column(String(100))
    term = Column(String(100))
    yoe = Column(Integer)
    
    #change this json to a list of strings
    employment_details = Column(Text)
    
    source = Column(String(100))
    external_id = Column(String(100))  # New column for external_id inde
    external_url = Column(String(200))
    
    # Dates
    date_posted = Column(DateTime)
    date_updated = Column(DateTime)
    date_first_active = Column(DateTime)
    date_deactivated = Column(DateTime)
    
    # Text descriptions of dates
    posted_date_text = Column(String(100))
    updated_date_text = Column(String(100))
    
    # Application details
    application_email = Column(String(200))
    application_cc_email = Column(String(200))
    application_type = Column(String(100))
    application_url = Column(String(200))
    
    # Foreign keys
    recruiter_id = Column(Integer, ForeignKey('recruiters.id'))
    vendor_id = Column(Integer, ForeignKey('vendors.id'))
    
    # Status
    status = Column(String(50), default="ACTIVE")
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    recruiter = relationship("Recruiter", back_populates="jobs")
    vendor = relationship("Vendor", back_populates="jobs")
    skills = relationship("JobSkill", back_populates="job", cascade="all, delete-orphan")
    
    @property
    def employment_details_list(self):
        """Parse the employment_details JSON string into a list of strings"""
        if not self.employment_details:
            return []
        try:
            return json.loads(self.employment_details)
        except:
            return []
    
    def __repr__(self):
        return f"<Job {self.title}>"