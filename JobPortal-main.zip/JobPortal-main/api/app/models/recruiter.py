from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime

from app.models.base import Base

class Recruiter(Base):
    __tablename__ = 'recruiters'
    
    id = Column(Integer, primary_key=True)
    recruiter_id = Column(String(100), unique=True, nullable=False)
    name = Column(String(200))
    email = Column(String(200))
    phone = Column(String(50))
    profile_url = Column(String(200))
    work_location = Column(String(200))
    vendor_id = Column(Integer, ForeignKey('vendors.id'))
    
    source = Column(String(50))
    external_id = Column(String(100))
    external_url = Column(String(200))
    
    # Relationships
    vendor = relationship("Vendor", back_populates="recruiters")
    jobs = relationship("Job", back_populates="recruiter")
    
    def __repr__(self):
        return f"<Recruiter {self.name}>"