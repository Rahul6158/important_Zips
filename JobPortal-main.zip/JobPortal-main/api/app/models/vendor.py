from sqlalchemy import Column, Integer, String, Text
from sqlalchemy.orm import relationship

from app.models.base import Base

class Vendor(Base):
    __tablename__ = 'vendors'
    
    id = Column(Integer, primary_key=True)
    vendor_id = Column(String(100), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    url = Column(String(200))
    description = Column(Text)
    overview = Column(Text)
    headquarters = Column(String(200))
    website = Column(String(200))
    
    source = Column(String(50))
    external_id = Column(String(100))  # New column for external_id inde
    external_url = Column(String(200))
    
    # Relationships
    recruiters = relationship("Recruiter", back_populates="vendor")
    jobs = relationship("Job", back_populates="vendor")
    
    def __repr__(self):
        return f"<Vendor {self.name}>"