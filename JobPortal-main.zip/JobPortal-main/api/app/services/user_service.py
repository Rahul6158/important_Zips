from sqlalchemy.orm import Session
from typing import Dict, Any, List, Optional
import json
from datetime import datetime

from app.models.user import User

class UserService:
    @staticmethod
    def get_user_by_external_id(db: Session, external_id: str):
        """Get a user by their external ID from auth provider"""
        return db.query(User).filter(User.external_id == external_id).first()
    
    @staticmethod
    def get_user_by_email(db: Session, email: str):
        """Get a user by their email"""
        return db.query(User).filter(User.email == email).first()
    
    @staticmethod
    def get_user_by_id(db: Session, user_id: int):
        """Get a user by their internal ID"""
        return db.query(User).filter(User.id == user_id).first()
    
    @staticmethod
    def create_user(db: Session, user_data: dict):
        """Create a new user"""
        # Ensure datetime fields are set
        if "created_at" not in user_data:
            user_data["created_at"] = datetime.utcnow()
        if "updated_at" not in user_data:
            user_data["updated_at"] = datetime.utcnow()
            
        # Convert roles list to JSON string if present
        if "roles" in user_data and isinstance(user_data["roles"], list):
            user_data["roles"] = json.dumps(user_data["roles"])
            
        user = User(**user_data)
        db.add(user)
        db.commit()
        db.refresh(user)
        return user
    
    @staticmethod
    def update_user(db: Session, user_id: int, user_data: Dict[str, Any]):
        """Update an existing user"""
        user = UserService.get_user_by_id(db, user_id)
        if not user:
            return None
        
        # Convert roles list to JSON string if it's a list
        if "roles" in user_data and isinstance(user_data["roles"], list):
            user_data["roles"] = json.dumps(user_data["roles"])
        
        for key, value in user_data.items():
            if hasattr(user, key):
                setattr(user, key, value)
        
        db.commit()
        db.refresh(user)
        return user
    
    @staticmethod
    def update_last_login(db: Session, user_id: int):
        """Update the last login timestamp for a user"""
        user = UserService.get_user_by_id(db, user_id)
        if user:
            user.last_login = datetime.utcnow()
            db.commit()
            db.refresh(user)
        return user
    
    # Add this method to the UserService class
    
    @staticmethod
    def find_or_create_skill(db: Session, skill_name: str):
        """Find a skill by name or create it if it doesn't exist"""
        from app.models.skill import Skill
        
        # Look for existing skill
        skill = db.query(Skill).filter(Skill.name == skill_name).first()
        
        # Create new skill if it doesn't exist
        if not skill:
            skill = Skill(name=skill_name)
            db.add(skill)
            db.commit()
            db.refresh(skill)
        
        return skill