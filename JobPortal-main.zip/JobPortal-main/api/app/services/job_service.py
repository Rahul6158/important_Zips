from sqlalchemy.orm import Session
from typing import Dict, Any, List, Optional
import json
from sqlalchemy import func, or_

from app.models.job import Job
from app.models.job_skill import JobSkill

class JobService:
    @staticmethod
    def get_jobs_with_total(
        db: Session, 
        skip: int = 0, 
        limit: int = 100, 
        q: Optional[str] = None,
        location: Optional[str] = None,
        employment_type: Optional[str] = None, 
        location_type: Optional[str] = None,
        skill: Optional[str] = None,
        skills: Optional[str] = None,
        rate: Optional[str] = None,
        term: Optional[str] = None,
        recruiter_id: Optional[int] = None,
        vendor_id: Optional[int] = None,
        status: Optional[str] = "Active",
        sort: Optional[str] = "posted_date",
        order: Optional[str] = "desc",
        date_filter: Optional[str] = None
    ):
        query = db.query(Job)
        
        # Apply search filter if provided
        if q:
            search_term = f"%{q}%"
            query = query.filter(
                or_(
                    Job.title.ilike(search_term),
                    Job.description.ilike(search_term)
                )
            )
        
        # Apply location filter if provided
        if location:
            query = query.filter(Job.location.ilike(f"%{location}%"))
        
        # Apply employment type filter if provided
        if employment_type:
            query = query.filter(Job.employment_details.ilike(f"%{employment_type}%"))
        
        # Apply location type filter if provided
        if location_type:
            if location_type.lower() in ["remote", "hybrid", "on site"]:
                # Exact match for standard location types
                query = query.filter(Job.location_type.ilike(f"%{location_type}%"))
            else:
                # Consider everything else as hybrid (as requested)
                query = query.filter(Job.location_type.ilike("%hybrid%"))
        
        # Apply date filter if provided
        if date_filter:
            from datetime import datetime, timedelta
            now = datetime.utcnow()
            
            if date_filter == "24h":
                # Jobs posted in the last 24 hours
                time_threshold = now - timedelta(hours=24)
                query = query.filter(Job.date_posted >= time_threshold)
            elif date_filter == "48h":
                # Jobs posted in the last 48 hours
                time_threshold = now - timedelta(hours=48)
                query = query.filter(Job.date_posted >= time_threshold)
            elif date_filter == "72h":
                # Jobs posted in the last 72 hours
                time_threshold = now - timedelta(hours=72)
                query = query.filter(Job.date_posted >= time_threshold)
        
        # Apply skill filter if provided
        if skill:
            # Join with job_skills table to filter by skill
            query = query.join(JobSkill).filter(JobSkill.skill_name.ilike(f"%{skill}%"))
        
        # Apply multiple skills filter if provided
        if skills:
            skill_list = skills.split(',')
            if skill_list:
                for skill_name in skill_list:
                    skill_name = skill_name.strip()
                    if skill_name:
                        # Fix the exists subquery to avoid auto-correlation
                        subquery = db.query(JobSkill).filter(
                            JobSkill.job_id == Job.id,
                            JobSkill.skill_name.ilike(f"%{skill_name}%")
                        )
                        query = query.filter(subquery.exists())
        
        # Apply recruiter filter if provided
        if recruiter_id:
            query = query.filter(Job.recruiter_id == recruiter_id)
        
        # Apply vendor filter if provided
        if vendor_id:
            query = query.filter(Job.vendor_id == vendor_id)
        
        # Apply rate filter if provided
        if rate:
            query = query.filter(Job.rate.ilike(f"%{rate}%"))
        
        # Apply term filter if provided
        if term:
            query = query.filter(Job.term.ilike(f"%{term}%"))
        
        # Apply status filter
        if status:
            query = query.filter(Job.status.ilike(f"%{status}%"))
        
        # Apply sorting
        if sort and hasattr(Job, sort):
            sort_column = getattr(Job, sort)
            if order.lower() == "asc":
                query = query.order_by(sort_column.asc())
            else:
                query = query.order_by(sort_column.desc())
        else:
            # Default sort by date_posted descending
            query = query.order_by(Job.date_posted.desc())
        
        # Get total count before pagination
        total = query.count()
        
        # Apply pagination
        jobs = query.offset(skip).limit(limit).all()
        
        return jobs, total
    
    @staticmethod
    def get_job_by_id(db: Session, job_id: str):
        """Get a job by its external job_id (string)"""
        return db.query(Job).filter(Job.job_id == job_id).first()
    
    @staticmethod
    def get_job_by_internal_id(db: Session, internal_id: int):
        """Get a job by its internal id (integer)"""
        return db.query(Job).filter(Job.id == internal_id).first()
    
    @staticmethod
    def create_or_update_job(db: Session, job_data: Dict[str, Any]):
        # Check if job exists
        job = db.query(Job).filter(Job.job_id == job_data["job_id"]).first()
        
        # Handle employment_details if it's a list - ensure it's stored as JSON string
        if "employment_details" in job_data:
            if isinstance(job_data["employment_details"], list):
                job_data["employment_details"] = json.dumps(job_data["employment_details"])
        
        # Handle job_employment_details from scraper
        if "job_employment_details" in job_data and "employment_details" not in job_data:
            if isinstance(job_data["job_employment_details"], list):
                job_data["employment_details"] = json.dumps(job_data["job_employment_details"])
            del job_data["job_employment_details"]
        
        # Set default values for source and external fields if not provided
        if "source" not in job_data:
            job_data["source"] = "dice"
        
        if "external_id" not in job_data:
            job_data["external_id"] = job_data["job_id"]
        
        # Construct external_url if not provided
        if "external_url" not in job_data or not job_data["external_url"]:
            if job_data["source"] == "dice":
                job_data["external_url"] = f"https://www.dice.com/job-detail/{job_data['job_id']}"
        
        if job:
            # Update existing job
            for key, value in job_data.items():
                if hasattr(job, key) and key != "job_id":
                    setattr(job, key, value)
        else:
            # Create new job
            job = Job(**job_data)
            db.add(job)
        
        db.commit()
        db.refresh(job)
        return job
    
    @staticmethod
    def update_job_skills(db: Session, job_id: int, skills: List[str]):
        """
        Update the skills associated with a job
        
        Args:
            db: Database session
            job_id: The ID of the job to update skills for
            skills: List of skill names
            
        Returns:
            The updated job object
        """
        # First, remove existing skills for this job
        db.query(JobSkill).filter(JobSkill.job_id == job_id).delete()
        
        # Add new skills
        for skill_name in skills:
            if skill_name and skill_name.strip():  # Skip empty skills
                # Truncate skill name to fit in the database column (max 100 chars)
                truncated_skill = skill_name.strip()[:100]
                job_skill = JobSkill(
                    job_id=job_id,
                    skill_name=truncated_skill
                )
                db.add(job_skill)
        
        db.commit()
        return db.query(Job).filter(Job.id == job_id).first()
    
    @staticmethod
    def get_jobs_by_recruiter_id(
        db: Session,
        recruiter_id: int,
        skip: int = 0,
        limit: int = 100,
        status: Optional[str] = "Active",
        sort: Optional[str] = "posted_date",
        order: Optional[str] = "desc"
    ):
        """Get jobs for a specific recruiter by internal ID"""
        query = db.query(Job).filter(Job.recruiter_id == recruiter_id)
        
        # Apply status filter
        if status:
            query = query.filter(Job.status.ilike(f"%{status}%"))
        
        # Apply sorting
        if sort and hasattr(Job, sort):
            sort_column = getattr(Job, sort)
            if order.lower() == "asc":
                query = query.order_by(sort_column.asc())
            else:
                query = query.order_by(sort_column.desc())
        else:
            # Default sort by date_posted descending
            query = query.order_by(Job.date_posted.desc())
        
        # Get total count before pagination
        total = query.count()
        
        # Apply pagination
        jobs = query.offset(skip).limit(limit).all()
        
        return jobs, total
