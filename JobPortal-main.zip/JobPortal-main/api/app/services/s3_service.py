import boto3
import logging
from botocore.exceptions import ClientError
from app.config import settings
import uuid

logger = logging.getLogger("job_portal_api")

class S3Service:
    def __init__(self):
        self.s3_client = boto3.client(
            's3',
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            region_name=settings.AWS_REGION
        )
        self.bucket_name = settings.S3_BUCKET_NAME

    def upload_file(self, file_obj, file_name=None, content_type=None):
        """
        Upload a file to S3 bucket
        
        Args:
            file_obj: File-like object to upload
            file_name: Optional name for the file (will generate UUID if not provided)
            content_type: MIME type of the file
            
        Returns:
            S3 URL of the uploaded file
        """
        try:
            # Generate a unique file name if not provided
            if not file_name:
                file_extension = "pdf"  # Default extension
                if content_type:
                    if content_type == "application/pdf":
                        file_extension = "pdf"
                    elif content_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                        file_extension = "docx"
                    elif content_type == "application/msword":
                        file_extension = "doc"
                
                file_name = f"resumes/{str(uuid.uuid4())}.{file_extension}"
            
            # Upload the file
            self.s3_client.upload_fileobj(
                file_obj,
                self.bucket_name,
                file_name,
                ExtraArgs={
                    'ContentType': content_type
                } if content_type else {}
            )
            
            # Generate the URL
            url = f"https://{self.bucket_name}.s3.{settings.AWS_REGION}.amazonaws.com/{file_name}"
            return url
            
        except ClientError as e:
            logger.error(f"Error uploading file to S3: {str(e)}")
            raise