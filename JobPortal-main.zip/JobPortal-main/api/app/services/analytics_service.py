from sqlalchemy.orm import Session
from typing import Dict, Any, List
from sqlalchemy import func, desc, distinct

from app.models.job import Job
from app.models.job_skill import JobSkill

class AnalyticsService:
    @staticmethod
    def get_job_stats_by_skill(db: Session, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Get statistics about the number of jobs per skill
        
        Args:
            db: Database session
            limit: Maximum number of skills to return (default: 20)
            
        Returns:
            List of dictionaries with skill name and job count
        """
        # Query to count jobs by skill
        result = db.query(
            JobSkill.skill_name,
            func.count(JobSkill.job_id).label('job_count')
        ).group_by(
            JobSkill.skill_name
        ).order_by(
            desc('job_count')
        ).limit(limit).all()
        
        # Convert to list of dictionaries
        stats = [{"skill": skill, "count": count} for skill, count in result]
        return stats
    
    @staticmethod
    def get_job_stats_by_location(db: Session, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get statistics about the number of jobs per location
        
        Args:
            db: Database session
            limit: Maximum number of locations to return (default: 10)
            
        Returns:
            List of dictionaries with location and job count
        """
        # Query to count jobs by location
        result = db.query(
            Job.location,
            func.count(Job.id).label('job_count')
        ).filter(
            Job.location.isnot(None)
        ).group_by(
            Job.location
        ).order_by(
            desc('job_count')
        ).limit(limit).all()
        
        # Convert to list of dictionaries
        stats = [{"location": location, "count": count} for location, count in result]
        return stats
    
    @staticmethod
    def get_unique_skills(db: Session, limit: int = 100) -> List[str]:
        """
        Get a list of unique skills from all jobs
        
        Args:
            db: Database session
            limit: Maximum number of skills to return
            
        Returns:
            List of unique skill names
        """
        # Query to get unique skills ordered by frequency
        result = db.query(
            JobSkill.skill_name
        ).group_by(
            JobSkill.skill_name
        ).order_by(
            desc(func.count(JobSkill.job_id))
        ).limit(limit).all()
        
        # Extract skill names from result tuples
        skills = [skill[0] for skill in result]
        return skills
    
    @staticmethod
    def get_unique_locations(db: Session, limit: int = 100) -> List[str]:
        """Get a list of unique locations from all jobs"""
        locations = db.query(distinct(Job.location)).filter(Job.location != None).limit(limit).all()
        # Flatten the result and remove empty strings
        return [loc[0] for loc in locations if loc[0] and loc[0].strip()]
