from sqlalchemy.orm import Session
from typing import Dict, Any, Optional, List
from sqlalchemy import func

from app.models.recruiter import Recruiter
from app.models.job import Job
from app.services.vendor_service import VendorService

class RecruiterService:
    @staticmethod
    def get_recruiters(db: Session, skip: int = 0, limit: int = 100):
        return db.query(Recruiter).offset(skip).limit(limit).all()
    
    @staticmethod
    def get_recruiters_with_job_counts(db: Session, skip: int = 0, limit: int = 100) -> List[Dict]:
        """Get recruiters with job counts"""
        # Query to get recruiters with job counts
        result = db.query(
            Recruiter,
            func.count(Job.id).label('total_jobs')
        ).outerjoin(
            Job, Job.recruiter_id == Recruiter.id
        ).group_by(
            Recruiter.id
        ).offset(skip).limit(limit).all()
        
        # Convert to list of dictionaries with total_jobs field
        recruiters = []
        for recruiter, job_count in result:
            # Get vendor name if vendor_id exists
            vendor_name = None
            if recruiter.vendor_id:
                vendor = VendorService.get_vendor_by_internal_id(db, recruiter.vendor_id)
                if vendor:
                    vendor_name = vendor.name
                # print(vendor_name)    
                                    
            recruiter_dict = {
                "id": recruiter.id,
                "recruiter_id": recruiter.recruiter_id,
                "name": recruiter.name,
                "email": recruiter.email,
                "phone": recruiter.phone,
                "profile_url": recruiter.profile_url,
                "work_location": recruiter.work_location,
                "vendor_id": recruiter.vendor_id,
                "vendor_name": vendor_name,  # Add vendor name to the output
                "source": recruiter.source,
                "external_url": recruiter.external_url,
                "total_jobs": job_count
            }
            recruiters.append(recruiter_dict)
        
        return recruiters
    
    @staticmethod
    def get_recruiter_by_id(db: Session, recruiter_id: str):
        """Get recruiter by external ID (recruiter_id)"""
        return db.query(Recruiter).filter(Recruiter.recruiter_id == recruiter_id).first()
    
    @staticmethod
    def get_recruiter_by_id_with_job_count(db: Session, recruiter_id: str):
        """Get recruiter by external ID with job count"""
        result = db.query(
            Recruiter,
            func.count(Job.id).label('total_jobs')
        ).outerjoin(
            Job, Job.recruiter_id == Recruiter.id
        ).filter(
            Recruiter.recruiter_id == recruiter_id
        ).group_by(
            Recruiter.id
        ).first()
        
        if not result:
            return None
        
        recruiter, job_count = result
        recruiter_dict = {
            "id": recruiter.id,
            "recruiter_id": recruiter.recruiter_id,
            "name": recruiter.name,
            "email": recruiter.email,
            "phone": recruiter.phone,
            "profile_url": recruiter.profile_url,
            "work_location": recruiter.work_location,
            "vendor_id": recruiter.vendor_id,
            "total_jobs": job_count
        }
        
        # print(recruiter_dict)
        
        return recruiter_dict
    
    @staticmethod
    def get_recruiter_by_internal_id(db: Session, internal_id: int):
        """Get recruiter by internal ID (id)"""
        return db.query(Recruiter).filter(Recruiter.id == internal_id).first()
    
    @staticmethod
    def get_recruiter_by_internal_id_with_job_count(db: Session, internal_id: int):
        """Get recruiter by internal ID with job count"""
        result = db.query(
            Recruiter,
            func.count(Job.id).label('total_jobs')
        ).outerjoin(
            Job, Job.recruiter_id == Recruiter.id
        ).filter(
            Recruiter.id == internal_id
        ).group_by(
            Recruiter.id
        ).first()
        
        if not result:
            return None
        
        recruiter, job_count = result
        recruiter_dict = {
            "id": recruiter.id,
            "recruiter_id": recruiter.recruiter_id,
            "name": recruiter.name,
            "email": recruiter.email,
            "phone": recruiter.phone,
            "profile_url": recruiter.profile_url,
            "work_location": recruiter.work_location,
            "vendor_id": recruiter.vendor_id,
            "total_jobs": job_count
        }
        
        # print(recruiter_dict)
        
        return recruiter_dict
    
    @staticmethod
    def create_or_update_recruiter(db: Session, recruiter_data: Dict[str, Any]):
        # Check if recruiter exists
        recruiter = db.query(Recruiter).filter(Recruiter.recruiter_id == recruiter_data["recruiter_id"]).first()
        
        # Set default values for source and external fields if not provided
        if "source" not in recruiter_data:
            recruiter_data["source"] = "dice"
        
        if "external_id" not in recruiter_data:
            recruiter_data["external_id"] = recruiter_data["recruiter_id"]
        
        # Construct external_url if not provided
        if "external_url" not in recruiter_data or not recruiter_data["external_url"]:
            if recruiter_data["source"] == "dice":
                recruiter_data["external_url"] = f"https://www.dice.com/recruiter-profile?id={recruiter_data['recruiter_id']}"
        
        if recruiter:
            # Update existing recruiter
            for key, value in recruiter_data.items():
                if hasattr(recruiter, key) and key != "recruiter_id":
                    setattr(recruiter, key, value)
        else:
            # Create new recruiter
            recruiter = Recruiter(**recruiter_data)
            db.add(recruiter)
        
        db.commit()
        db.refresh(recruiter)
        return recruiter