from sqlalchemy.orm import Session
from typing import Dict, Any, List
from sqlalchemy import func, and_
from datetime import datetime

from app.models.vendor import Vendor
from app.models.recruiter import Recruiter
from app.models.job import Job

class VendorService:
    @staticmethod
    def get_vendors(db: Session, skip: int = 0, limit: int = 100):
        return db.query(Vendor).offset(skip).limit(limit).all()
    
    @staticmethod
    def get_vendor_by_id(db: Session, vendor_id: str):
        """Get vendor by external ID (vendor_id)"""
        return db.query(Vendor).filter(Vendor.vendor_id == vendor_id).first()
    
    @staticmethod
    def get_vendor_by_internal_id(db: Session, internal_id: int):
        """Get vendor by internal ID (id)"""
        return db.query(Vendor).filter(Vendor.id == internal_id).first()
    
    # In the create_or_update_vendor method:
    
    @staticmethod
    def create_or_update_vendor(db: Session, vendor_data: Dict[str, Any]):
        # Check if vendor exists
        vendor = db.query(Vendor).filter(Vendor.vendor_id == vendor_data["vendor_id"]).first()
        
        # Set default values for source and external fields if not provided
        if "source" not in vendor_data:
            vendor_data["source"] = "dice"
        
        if "external_id" not in vendor_data:
            vendor_data["external_id"] = vendor_data["vendor_id"]
        
        # Construct external_url if not provided
        if "external_url" not in vendor_data or not vendor_data["external_url"]:
            if vendor_data["source"] == "dice":
                vendor_data["external_url"] = f"https://www.dice.com/company-profile/{vendor_data['vendor_id']}"
        
        if vendor:
            # Update existing vendor
            for key, value in vendor_data.items():
                if hasattr(vendor, key) and key != "vendor_id":
                    setattr(vendor, key, value)
        else:
            # Create new vendor
            vendor = Vendor(**vendor_data)
            db.add(vendor)
        
        db.commit()
        db.refresh(vendor)
        return vendor
    
    @staticmethod
    def get_vendors_with_stats(db: Session, skip: int = 0, limit: int = 100) -> List[Dict]:
        """
        Get vendors with additional statistics:
        - Number of recruiters
        - Number of jobs posted
        - Number of active jobs
        - External URL
        """
        # Subquery to count active jobs (assuming a job is active if it doesn't have a deactivation date)
        active_jobs = db.query(
            Job.vendor_id,
            func.count(Job.id).label('active_jobs_count')
        ).filter(
            Job.date_deactivated.is_(None)
        ).group_by(Job.vendor_id).subquery()
        
        # Main query to get vendors with all required statistics
        result = db.query(
            Vendor,
            func.count(Recruiter.id.distinct()).label('recruiters_count'),
            func.count(Job.id.distinct()).label('total_jobs'),
            func.coalesce(active_jobs.c.active_jobs_count, 0).label('active_jobs')
        ).outerjoin(
            Recruiter, Recruiter.vendor_id == Vendor.id
        ).outerjoin(
            Job, Job.vendor_id == Vendor.id
        ).outerjoin(
            active_jobs, active_jobs.c.vendor_id == Vendor.id
        ).group_by(
            Vendor.id, active_jobs.c.active_jobs_count
        ).offset(skip).limit(limit).all()
        
        # Convert to list of dictionaries with all required fields
        vendors = []
        for vendor, recruiters_count, total_jobs, active_jobs in result:
            vendor_dict = {
                "id": vendor.id,
                "vendor_id": vendor.vendor_id,
                "name": vendor.name,
                "website": vendor.website,
                "external_url": vendor.external_url,  # Changed from dice_url to external_url
                "source": vendor.source,  # Added source field
                "recruiters_count": recruiters_count,
                "total_jobs": total_jobs,
                "active_jobs": active_jobs
            }
            vendors.append(vendor_dict)
        return vendors