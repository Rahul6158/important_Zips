import urllib.parse
from typing import Any

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Database settings
    DATABASE_URL_VALUE: str | None = Field(default=None, validation_alias="DATABASE_URL")
    DB_USER: str = "jobportalappuser"
    DB_PASSWORD: str = ""
    DB_HOST: str = "localhost"
    DB_PORT: str = "5432"
    DB_NAME: str = "jobportal"

    @property
    def DATABASE_URL(self) -> str:
        if self.DATABASE_URL_VALUE:
            return self.DATABASE_URL_VALUE

        escaped_password = urllib.parse.quote_plus(self.DB_PASSWORD)
        password = f":{escaped_password}" if escaped_password else ""
        return f"postgresql://{self.DB_USER}{password}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"

    # Application settings
    APP_NAME: str = "Job Portal API"
    APP_VERSION: str = "1.0.0"
    APP_DESCRIPTION: str = "API for job portal and recruiter management"
    APP_ENV: str = "local"
    PORT: int = 8000
    
    # CORS settings
    CORS_ORIGINS: list[str] = [
        "https://job-portal.tabner.com",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ]

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors_origins(cls, value: Any) -> Any:
        if isinstance(value, str):
            return [origin.strip() for origin in value.split(",") if origin.strip()]
        return value
    
    # Scheduler settings
    SCRAPER_ENABLED: bool = False
    SCHEDULER_JOB_HOUR: int = 1
    SCHEDULER_JOB_MINUTE: int = 0
    
    # Scraper settings
    DEFAULT_POSTED_DATE: str = "ONE"
    DEFAULT_WORKPLACE_TYPES: str = "On-Site|Remote|Hybrid"
    DEFAULT_EMPLOYMENT_TYPE: str = "THIRD_PARTY|CONTRACTS"
    DEFAULT_LIMIT: int = 1

    AWS_ACCESS_KEY_ID: str | None = None
    AWS_SECRET_ACCESS_KEY: str | None = None
    AWS_REGION: str = "us-east-1"
    S3_BUCKET_NAME: str = "job-portal-resume-store"
    
    # OIDC settings
    OIDC_CLIENT_ID: str = "JobPortal"
    OIDC_ISSUER: str = "https://keycloak.tabner.com/realms/JobPortal"
    OIDC_JWKS_URI: str = "https://keycloak.tabner.com/realms/JobPortal/protocol/openid-connect/certs"


settings = Settings()
