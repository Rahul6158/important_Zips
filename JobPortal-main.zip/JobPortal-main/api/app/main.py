import logging

import uvicorn
from fastapi import FastAPI, Response, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from app.api.api import api_router
from app.config import Settings, settings
from app.middleware.auth import AuthMiddleware
from app.schemas.health import HealthResponse
from app.scrapers.scheduler import initialize_scheduler, shutdown_scheduler, start_scheduler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("api.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("job_portal_api")


def create_app(app_settings: Settings | None = None) -> FastAPI:
    resolved_settings = app_settings or settings

    app = FastAPI(
        title=resolved_settings.APP_NAME,
        description=resolved_settings.APP_DESCRIPTION,
        version=resolved_settings.APP_VERSION,
        redirect_slashes=False,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=resolved_settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(AuthMiddleware)
    app.include_router(api_router)

    @app.on_event("startup")
    def startup_event() -> None:
        initialize_scheduler()
        start_scheduler()
        logger.info("Application started")

    @app.on_event("shutdown")
    def shutdown_event() -> None:
        shutdown_scheduler()
        logger.info("Application shut down")

    @app.get("/api")
    def read_root() -> dict[str, str]:
        return {
            "message": f"Welcome to the {resolved_settings.APP_NAME}",
            "version": resolved_settings.APP_VERSION,
            "description": resolved_settings.APP_DESCRIPTION,
        }

    @app.get("/api/health", response_model=HealthResponse)
    @app.get("/health/live", response_model=HealthResponse)
    def health_check() -> HealthResponse:
        return HealthResponse(status="healthy", api_version=resolved_settings.APP_VERSION)

    @app.get("/health/ready", response_model=HealthResponse)
    def readiness_check(response: Response) -> HealthResponse:
        checks: dict[str, str] = {}

        try:
            from app.database import engine

            with engine.connect() as connection:
                connection.execute(text("SELECT 1"))
            checks["database"] = "ok"
        except SQLAlchemyError:
            response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
            checks["database"] = "unavailable"
            return HealthResponse(
                status="not_ready",
                api_version=resolved_settings.APP_VERSION,
                checks=checks,
            )

        return HealthResponse(
            status="ready",
            api_version=resolved_settings.APP_VERSION,
            checks=checks,
        )

    return app


app = create_app()

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=settings.PORT, reload=True)
