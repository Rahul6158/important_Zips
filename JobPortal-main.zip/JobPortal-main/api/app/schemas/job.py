from pydantic import BaseModel, validator
from typing import List, Optional, Union
from datetime import datetime
from app.schemas.skill import Skill
import json

class JobBase(BaseModel):
    job_id: str
    title: str
    description: Optional[str] = None
    requirements: Optional[str] = None
    responsibilities: Optional[str] = None
    location: Optional[str] = None
    location_type: Optional[str] = None
    rate: Optional[str] = None
    term: Optional[str] = None
    employment_details: Optional[Union[List[str], str]] = None
    posted_date_text: Optional[str] = None
    updated_date_text: Optional[str] = None
    application_email: Optional[str] = None
    application_cc_email: Optional[str] = None
    application_type: Optional[str] = None
    application_url: Optional[str] = None
    status: Optional[str] = "Active"
    source: Optional[str] = None
    external_id: Optional[str] = None
    external_url: Optional[str] = None
    yoe: Optional[int] = None
    
    @validator('employment_details', pre=True)
    def parse_employment_details(cls, v):
        if v is None:
            return []
        if isinstance(v, list):
            return v
        if isinstance(v, str):
            try:
                return json.loads(v)
            except:
                return [v]
        return []

class Job(JobBase):
    id: int
    date_posted: Optional[datetime] = None
    date_updated: Optional[datetime] = None
    date_first_active: Optional[datetime] = None
    date_deactivated: Optional[datetime] = None
    recruiter_id: Optional[int] = None
    vendor_id: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    skills: List[Skill] = []
    
    class Config:
        from_attributes = True

class JobCreate(JobBase):
    pass

class JobUpdate(JobBase):
    pass