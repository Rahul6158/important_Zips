from pydantic import BaseModel
from typing import Optional

class RecruiterBase(BaseModel):
    recruiter_id: str
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    profile_url: Optional[str] = None
    work_location: Optional[str] = None
    source: Optional[str] = None
    external_id: Optional[str] = None
    external_url: Optional[str] = None

class Recruiter(RecruiterBase):
    id: int
    vendor_id: Optional[int] = None
    vendor_name: Optional[str] = None
    total_jobs: Optional[int] = 0
    
    class Config:
        from_attributes = True

class RecruiterCreate(RecruiterBase):
    pass

class RecruiterUpdate(RecruiterBase):
    pass