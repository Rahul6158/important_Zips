from pydantic import BaseModel
from typing import Optional

class VendorBase(BaseModel):
    name: str
    website: Optional[str] = None
    external_url: Optional[str] = None
    source: Optional[str] = None  # Add this line

class VendorCreate(VendorBase):
    vendor_id: str

class VendorUpdate(VendorBase):
    pass

class Vendor(VendorBase):
    id: int
    vendor_id: str

    class Config:
        from_attributes = True

class VendorWithStats(Vendor):
    recruiters_count: int
    total_jobs: int
    active_jobs: int

    class Config:
        from_attributes = True