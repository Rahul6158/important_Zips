from pydantic import BaseModel, EmailStr, validator, Field
from typing import List, Optional
from datetime import datetime
import json

class UserBase(BaseModel):
    email: EmailStr
    username: Optional[str] = None  # Add username field
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone_number: Optional[str] = None
    
    # SMTP settings
    smtp_server: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_username: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_from_email: Optional[str] = None

class UserCreate(UserBase):
    roles: Optional[List[str]] = []
    
    @validator('roles', pre=True)
    def parse_roles(cls, v):
        if isinstance(v, str):
            try:
                return json.loads(v)
            except:
                return []
        return v or []

class UserUpdate(UserBase):
    is_active: Optional[bool] = None
    roles: Optional[List[str]] = None
    
    @validator('roles', pre=True)
    def parse_roles(cls, v):
        if isinstance(v, str):
            try:
                return json.loads(v)
            except:
                return []
        return v

# Add these fields to your UserSchema class
# Note: I'm showing only the fields to add since I don't have the full file

class User(BaseModel):
    id: int
    is_active: bool
    roles: List[str] = []
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default_factory=datetime.now)
    last_login: Optional[datetime] = None
    resume_url: Optional[str] = None
    resume_path: Optional[str] = None
    resume_uploaded: Optional[bool] = False
    email: EmailStr
    username: Optional[str] = None  # Add username field
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone_number: Optional[str] = None
    
    # SMTP settings
    smtp_server: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_username: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_from_email: Optional[str] = None

    @validator('roles', pre=True)
    def parse_roles(cls, v):
        if isinstance(v, str):
            try:
                return json.loads(v)
            except:
                return []
        return v
    
    class Config:
        # orm_mode = True  # For Pydantic v1
        # If using Pydantic v2, use:
        from_attributes = True