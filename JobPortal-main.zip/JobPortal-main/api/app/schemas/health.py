from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: str = Field(..., description="Current health state.")
    api_version: str = Field(..., description="Application version.")
    checks: dict[str, str] = Field(default_factory=dict, description="Readiness dependency checks.")
