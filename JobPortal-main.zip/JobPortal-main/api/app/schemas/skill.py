from pydantic import BaseModel

class SkillBase(BaseModel):
    skill_name: str

class Skill(SkillBase):
    id: int
    job_id: int
    
    class Config:
        from_attributes = True

class SkillCreate(SkillBase):
    pass