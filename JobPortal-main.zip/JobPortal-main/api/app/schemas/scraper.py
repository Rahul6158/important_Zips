from pydantic import BaseModel
from typing import Optional

class ScrapeJobsRequest(BaseModel):
    query: Optional[str] = ""
    posted_date: Optional[str] = "ONE"
    workplace_types: Optional[str] = "Remote"
    employment_type: Optional[str] = "THIRD_PARTY"
    limit: Optional[int] = 1000

class ScrapeJobUrlRequest(BaseModel):
    job_url: str