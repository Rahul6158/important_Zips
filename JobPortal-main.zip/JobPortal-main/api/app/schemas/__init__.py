from app.schemas.job import Job, JobCreate, JobUpdate, JobBase
from app.schemas.recruiter import Recruiter, RecruiterCreate, RecruiterUpdate, RecruiterBase
from app.schemas.vendor import Vendor, VendorCreate, VendorUpdate, VendorBase
from app.schemas.skill import Skill, SkillCreate, SkillBase
from app.schemas.scraper import ScrapeJobsRequest

__all__ = [
    'Job', 'JobCreate', 'JobUpdate', 'JobBase',
    'Recruiter', 'RecruiterCreate', 'RecruiterUpdate', 'RecruiterBase',
    'Vendor', 'VendorCreate', 'VendorUpdate', 'VendorBase',
    'Skill', 'SkillCreate', 'SkillBase',
    'ScrapeJobsRequest'
]