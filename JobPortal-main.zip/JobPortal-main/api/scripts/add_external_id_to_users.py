from sqlalchemy import create_engine, Column, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import sys
import os

# Add the parent directory to the path so we can import from app
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.config import settings
from app.models.user import User

def add_external_id_column():
    # Create engine and session
    engine = create_engine(settings.DATABASE_URL)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    
    try:
        # Add the column if it doesn't exist
        engine.execute('ALTER TABLE users ADD COLUMN IF NOT EXISTS external_id VARCHAR(255)')
        engine.execute('CREATE INDEX IF NOT EXISTS ix_users_external_id ON users (external_id)')
        print("Successfully added external_id column to users table")
    except Exception as e:
        print(f"Error adding external_id column: {str(e)}")
    finally:
        db.close()

if __name__ == "__main__":
    add_external_id_column()
