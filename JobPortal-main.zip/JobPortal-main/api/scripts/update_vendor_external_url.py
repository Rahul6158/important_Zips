#!/usr/bin/env python3
"""
Script to update existing vendors with source, external_id, and external_url
"""
import sys
import os

# Add the parent directory to the path so we can import app modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.database import SessionLocal
from app.models.vendor import Vendor

def update_existing_vendors():
    """Update existing vendors with source, external_id, and external_url"""
    db = SessionLocal()
    try:
        # Get all vendors
        vendors = db.query(Vendor).all()
        
        # Update each vendor
        updated_count = 0
        for vendor in vendors:
            updated = False
            
            # Set source if not set
            if not vendor.source:
                vendor.source = "dice"
                updated = True
            
            # Set external_id if not set
            if not vendor.external_id:
                vendor.external_id = vendor.vendor_id
                updated = True
            
            # Set external_url if not set
            if not vendor.external_url:
                vendor.external_url = f"https://www.dice.com/company-profile/{vendor.vendor_id}"
                updated = True
            
            if updated:
                updated_count += 1
        
        # Commit changes
        db.commit()
        print(f"Updated {updated_count} vendors with source, external_id, and external_url")
    except Exception as e:
        db.rollback()
        print(f"Error updating vendors: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    print("Starting vendor external URL update...")
    update_existing_vendors()
    print("Vendor external URL update completed")