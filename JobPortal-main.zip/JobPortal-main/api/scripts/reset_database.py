import sys
import os
from sqlalchemy import create_engine, text
import logging

# Add the parent directory to the path so we can import app modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.config import settings
from app.models import Base

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def reset_database():
    """
    Reset the database by:
    1. Disconnecting all active connections
    2. Dropping all tables
    3. Recreating all tables from models
    """
    logger.info("Starting database reset...")
    
    # Create a new engine for admin operations
    admin_engine = create_engine(settings.DATABASE_URL)
    
    try:
        # Connect to the database
        with admin_engine.connect() as conn:
            # Get database name from connection URL
            db_name = settings.DATABASE_URL.split('/')[-1]
            
            # Terminate all connections to the database
            logger.info("Terminating all active connections...")
            conn.execute(text(f"""
                SELECT pg_terminate_backend(pg_stat_activity.pid)
                FROM pg_stat_activity
                WHERE pg_stat_activity.datname = '{db_name}'
                AND pid <> pg_backend_pid();
            """))
            conn.commit()
            
            logger.info("Dropping all tables...")
            # Drop all tables
            Base.metadata.drop_all(bind=admin_engine)
            conn.commit()
            
            logger.info("Recreating all tables...")
            # Recreate all tables
            Base.metadata.create_all(bind=admin_engine)
            conn.commit()
            
        logger.info("Database reset completed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"Error resetting database: {e}")
        return False
    finally:
        admin_engine.dispose()

if __name__ == "__main__":
    reset_database()