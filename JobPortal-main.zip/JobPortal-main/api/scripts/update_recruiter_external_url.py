#!/usr/bin/env python3
"""
Script to update existing recruiters with source, external_id, and external_url
"""
import sys
import os

# Add the parent directory to the path so we can import app modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.database import SessionLocal
from app.models.recruiter import Recruiter

def update_existing_recruiters():
    """Update existing recruiters with source, external_id, and external_url"""
    db = SessionLocal()
    try:
        # Get all recruiters
        recruiters = db.query(Recruiter).all()
        
        # Update each recruiter
        updated_count = 0
        for recruiter in recruiters:
            updated = False
            
            # Set source if not set
            if not recruiter.source:
                recruiter.source = "dice"
                updated = True
            
            # Set external_id if not set
            if not recruiter.external_id:
                recruiter.external_id = recruiter.recruiter_id
                updated = True
            
            # Set external_url if not set
            if not recruiter.external_url:
                recruiter.external_url = f"https://www.dice.com/recruiter-profile?id={recruiter.recruiter_id}"
                updated = True
            
            if updated:
                updated_count += 1
        
        # Commit changes
        db.commit()
        print(f"Updated {updated_count} recruiters with source, external_id, and external_url")
    except Exception as e:
        db.rollback()
        print(f"Error updating recruiters: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    print("Starting recruiter external URL update...")
    update_existing_recruiters()
    print("Recruiter external URL update completed")