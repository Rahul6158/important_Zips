from sqlalchemy import create_engine, Column, String, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from app.config import settings

# Create database connection
engine = create_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create a base class for declarative models
Base = declarative_base()

def add_resume_columns():
    """Add resume_path and resume_uploaded columns to the users table"""
    from app.models.user import User
    
    # Create a session
    db = SessionLocal()
    
    try:
        # Add the columns if they don't exist
        # This is a simplified approach - in production, use Alembic for migrations
        conn = engine.connect()
        
        # Check if resume_path column exists
        result = conn.execute("SELECT column_name FROM information_schema.columns WHERE table_name='users' AND column_name='resume_path'")
        if result.rowcount == 0:
            conn.execute("ALTER TABLE users ADD COLUMN resume_path VARCHAR(255)")
            print("Added resume_path column to users table")
        
        # Check if resume_uploaded column exists
        result = conn.execute("SELECT column_name FROM information_schema.columns WHERE table_name='users' AND column_name='resume_uploaded'")
        if result.rowcount == 0:
            conn.execute("ALTER TABLE users ADD COLUMN resume_uploaded BOOLEAN DEFAULT FALSE")
            print("Added resume_uploaded column to users table")
        
        # Update existing users with resume_url to set resume_uploaded=True
        conn.execute("UPDATE users SET resume_uploaded=TRUE WHERE resume_url IS NOT NULL AND resume_url != ''")
        print("Updated resume_uploaded status for existing users")
        
        conn.close()
        print("Database migration completed successfully")
        
    except Exception as e:
        print(f"Error during migration: {str(e)}")
    finally:
        db.close()

if __name__ == "__main__":
    add_resume_columns()