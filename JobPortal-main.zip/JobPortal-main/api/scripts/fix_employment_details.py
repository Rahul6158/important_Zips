import sys
import os
import json

# Add the parent directory to the path so we can import app modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import get_db
from app.models.job import Job

def fix_employment_details():
    db = next(get_db())
    try:
        # Get all jobs
        jobs = db.query(Job).all()
        
        # Fix each job's employment_details
        for job in jobs:
            if job.employment_details:
                try:
                    # Try to parse as JSON
                    details = json.loads(job.employment_details)
                    # If it's not a list, convert it to a list
                    if not isinstance(details, list):
                        job.employment_details = json.dumps([details])
                except json.JSONDecodeError:
                    # If it's not valid JSON, convert it to a list with one item
                    job.employment_details = json.dumps([job.employment_details])
            else:
                # If it's None or empty, set it to an empty list
                job.employment_details = json.dumps([])
        
        db.commit()
        print("Employment details fixed successfully")
        
        # Verify the fix
        sample_jobs = db.query(Job).limit(5).all()
        for job in sample_jobs:
            print(f"Job ID: {job.job_id}")
            print(f"Employment details (raw): {job.employment_details}")
            print(f"Employment details (parsed): {job.employment_details_list}")
            print("---")
            
    except Exception as e:
        db.rollback()
        print(f"Error fixing employment details: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    fix_employment_details()