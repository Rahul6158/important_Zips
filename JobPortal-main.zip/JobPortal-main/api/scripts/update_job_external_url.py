#!/usr/bin/env python3
"""
Script to update existing jobs with source, external_id, and external_url
"""
import sys
import os

# Add the parent directory to the path so we can import app modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.database import SessionLocal
from app.models.job import Job

def update_existing_jobs():
    """Update existing jobs with source, external_id, and external_url"""
    db = SessionLocal()
    try:
        # Get all jobs
        jobs = db.query(Job).all()
        
        # Update each job
        updated_count = 0
        for job in jobs:
            updated = False
            
            # Set source if not set
            if not job.source:
                job.source = "dice"
                updated = True
            
            # Set external_id if not set
            if not job.external_id:
                job.external_id = job.job_id
                updated = True
            
            # Set external_url if not set
            if not job.external_url:
                job.external_url = f"https://www.dice.com/job-detail/{job.job_id}"
                updated = True
            
            if updated:
                updated_count += 1
        
        # Commit changes
        db.commit()
        print(f"Updated {updated_count} jobs with source, external_id, and external_url")
    except Exception as e:
        db.rollback()
        print(f"Error updating jobs: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    print("Starting job external URL update...")
    update_existing_jobs()
    print("Job external URL update completed")