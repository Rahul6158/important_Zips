# Job Portal API

FastAPI service for Job Portal jobs, recruiters, vendors, analytics, profile
operations, resume upload, and Dice scraping.

## Documentation

| Need | Link |
| --- | --- |
| API docs hub | [docs/README.md](./docs/README.md) |
| Architecture | [docs/architecture.md](./docs/architecture.md) |
| Local development | [docs/local-development.md](./docs/local-development.md) |
| Endpoints | [docs/api-endpoints.md](./docs/api-endpoints.md) |
| Models | [docs/request-response-models.md](./docs/request-response-models.md) |
| Authentication | [docs/authentication.md](./docs/authentication.md) |
| Database | [docs/database.md](./docs/database.md) |
| Configuration | [docs/configuration.md](./docs/configuration.md) |
| Testing | [docs/testing.md](./docs/testing.md) |
| Deployment | [docs/build-and-deployment.md](./docs/build-and-deployment.md) |
| Troubleshooting | [docs/troubleshooting.md](./docs/troubleshooting.md) |

## Service Boundary

- Service root: `api/`
- ASGI app: `app.main:app`
- Dockerfile: `api/Dockerfile`
- Runtime port: `PORT`, default `8000`
- OpenAPI: `/docs` and `/redoc`
- Liveness: `/health/live`
- Readiness: `/health/ready`
- Legacy health endpoint: `/api/health`

## Local Setup

```bash
cd api
python -m venv .venv
. .venv/bin/activate
make install
cp .env.example .env
```

Edit `.env` with a reachable PostgreSQL `DATABASE_URL` and any optional S3/OIDC
values needed for the workflow you are testing.

## Running

```bash
make run
```

The API is available at `http://localhost:8000`.

## Configuration

The service uses `pydantic-settings` in `app/config.py`. Deployed environments
should provide values through environment variables or secrets. Do not commit
real credentials to `.env` or source files.

Common runtime inputs:

- `DATABASE_URL`: preferred PostgreSQL DSN.
- `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`, `DB_NAME`: fallback DSN inputs
  used only when `DATABASE_URL` is unset.
- `CORS_ORIGINS`: comma-separated browser origins.
- `PORT`: service port.
- `SCRAPER_ENABLED`: explicitly enables scheduled Dice scraping. Defaults to
  `false`.
- `SCHEDULER_JOB_HOUR` and `SCHEDULER_JOB_MINUTE`: schedule for scraper runs.
- `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION`, `S3_BUCKET_NAME`:
  resume upload storage settings.
- `OIDC_CLIENT_ID`, `OIDC_ISSUER`, `OIDC_JWKS_URI`: auth provider settings.

See `.env.example` and `docs/api-service-deployment.md` for the full deployment
input list.

## Command Contract

```bash
make install
make run
make test
make test-unit
make test-integration
make lint
make format-check
make type-check
make docker-build
```

These targets align this service with the NAINAxAI backend API command contract.

## API Routes

Current route prefixes:

- `GET /api/jobs/all`
- `GET /api/jobs/{job_id}`
- `GET /api/recruiters/all`
- `GET /api/recruiters/{recruiter_id}`
- `GET /api/vendors/all`
- `GET /api/vendors/{vendor_id}`
- `GET /api/analytics/*`
- `POST /api/profile/upload-resume`
- `POST /api/tailor/*`
- `GET /api/run-daily-collection`

Swagger remains the source of truth for full request and response details.

## Database

The application creates a SQLAlchemy engine from `settings.DATABASE_URL`.
Readiness checks validate connectivity with `SELECT 1`.

Migration handling is currently script-based under `api/scripts/`. Before a
production rollout, standardize schema changes with Alembic migrations.

## Scraper Runtime

Scheduled scraping is disabled by default:

```text
SCRAPER_ENABLED=false
```

Set it to `true` only in environments that are prepared for Selenium/Chromium
runtime work. The Docker image includes Chromium and ChromeDriver dependencies.

## Validation

```bash
make test
make docker-build
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
```

If `/health/ready` returns `503`, inspect `DATABASE_URL` and database network
access first.
