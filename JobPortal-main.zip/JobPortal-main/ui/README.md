# JobPortal UI

The JobPortal UI is a React single-page application for job search, recruiter
and vendor review, analytics, profile management, resume upload, and resume
tailoring.

## Start Here

| Need | Link |
| --- | --- |
| UI docs hub | [docs/README.md](./docs/README.md) |
| Overview | [docs/overview.md](./docs/overview.md) |
| Architecture | [docs/architecture.md](./docs/architecture.md) |
| Local development | [docs/local-development.md](./docs/local-development.md) |
| Routing | [docs/routing.md](./docs/routing.md) |
| API integration | [docs/api-integration.md](./docs/api-integration.md) |
| Configuration | [docs/configuration.md](./docs/configuration.md) |
| Testing | [docs/testing.md](./docs/testing.md) |
| Build and deployment | [docs/build-and-deployment.md](./docs/build-and-deployment.md) |
| Troubleshooting | [docs/troubleshooting.md](./docs/troubleshooting.md) |

## Quick Start

```bash
cd ui
npm install
npm start
```

The development server starts on `http://localhost:3000`.

Create `ui/.env` for local configuration:

```text
REACT_APP_API_URL=http://localhost:8000/api
REACT_APP_OIDC_AUTHORITY=<oidc-authority>
REACT_APP_OIDC_CLIENT_ID=<oidc-client-id>
REACT_APP_OIDC_CLIENT_SECRET=<oidc-client-secret>
```

## Validation

```bash
npm test -- --watchAll=false
npm run build
```
