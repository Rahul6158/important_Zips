import axios from 'axios';

// Use environment variable for API URL
export const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

// Jobs API
export const getJobs = async (params = {}) => {
  // Ensure location parameter is properly passed
  if (params.location) {
    // Keep the location parameter as is - backend will handle the filtering logic
    console.log(`Filtering by location: ${params.location}`);
  }
  
  const response = await axios.get(`${API_URL}/jobs/all`, { params });
  return response.data;
};

export const getJobById = async (jobId) => {
  try {
    console.log(`Calling API: ${API_URL}/jobs/${jobId}`); // Debug log
    const response = await axios.get(`${API_URL}/jobs/${jobId}`);
    return response.data;
  } catch (error) {
    console.error("API error:", error.response || error); // Log detailed error
    throw error;
  }
};

// Add a new function to get job by internal ID
export const getJobByInternalId = async (internalId) => {
  try {
    console.log(`Calling API: ${API_URL}/jobs/internal/${internalId}`); // Debug log
    const response = await axios.get(`${API_URL}/jobs/internal/${internalId}`);
    return response.data;
  } catch (error) {
    console.error("API error:", error.response || error); // Log detailed error
    throw error;
  }
};

// Vendors API
export const getVendors = async (params = {}) => {
  const response = await axios.get(`${API_URL}/vendors/all`, { params });
  return response.data;
};

export const getVendorById = async (id) => {
  // Use the general endpoint which handles both ID types
  const response = await axios.get(`${API_URL}/vendors/${id}`);
  return response.data;
};

// Recruiters API
export const getRecruiters = async (params = {}) => { // Accept params object
  // Pass params to the API call
  const response = await axios.get(`${API_URL}/recruiters/all`, { params }); 
  return response.data;
};

export const getRecruiterById = async (id) => {
  // Use the general endpoint which handles both ID types
  const response = await axios.get(`${API_URL}/recruiters/${id}`);
  return response.data;
};

// Search API
export const searchJobs = async (query, filters = {}) => {
  const params = { q: query, ...filters };
  return getJobs(params);
};

// Analytics API
export const getJobStatsBySkill = async (limit = 20) => {
  const response = await axios.get(`${API_URL}/analytics/skills`, { params: { limit } });
  return response.data;
};

export const getJobStatsByLocation = async (limit = 10) => {
  const response = await axios.get(`${API_URL}/analytics/locations`, { params: { limit } });
  return response.data;
};

// Add this function to your existing api.js file

// Add this function to fetch unique skills for the dropdown
// export const getUniqueSkills = async () => {
//   try {
//     const response = await axios.get(`${API_URL}/analytics/skills/unique`);
//     return response.data;
//   } catch (error) {
//     console.error("API error:", error.response || error);
//     throw error;
//   }
// };

// Get unique locations for autocomplete
export const getUniqueLocations = async () => {
  try {
    const response = await axios.get(`${API_URL}/analytics/locations/all`);
    return response.data;
  } catch (error) {
    console.error('Error fetching locations:', error);
    return [];
  }
};

// Get unique skills for autocomplete
export const getUniqueSkills = async () => {
  try {
    const response = await axios.get(`${API_URL}/analytics/skills/all`);
    return response.data;
  } catch (error) {
    console.error('Error fetching skills:', error);
    return [];
  }
};

// Resume Tailor API
export const tailorResume = async (resumeFile, jobDescription) => {
  try {
    const formData = new FormData();
    formData.append('resume', resumeFile);
    formData.append('job_description', jobDescription);
    
    const response = await axios.post(`${API_URL}/tailor/tailor-resume`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      responseType: 'blob', // Important for handling file download
    });
    
    return response.data;
  } catch (error) {
    console.error('Error tailoring resume:', error);
    throw error;
  }
};

// Add authentication validation endpoint
export const validateToken = async (token) => {
  try {
    const response = await axios.post(`${API_URL}/auth/validate-token`, {}, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error validating token:', error);
    throw error;
  }
};

// Profile API
export const uploadResume = async (file, onProgressUpdate) => {
  try {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await axios.post(`${API_URL}/profile/upload-resume`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (progressEvent) => {
        const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
        // Call the progress update callback if provided
        if (onProgressUpdate) {
          onProgressUpdate(percentCompleted);
        }
        console.log(`Upload progress: ${percentCompleted}%`);
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error uploading resume:', error);
    throw error;
  }
};

export const updateUserSkills = async (skillIds) => {
  try {
    const response = await axios.post(`${API_URL}/profile/update-skills`, skillIds);
    return response.data;
  } catch (error) {
    console.error('Error updating skills:', error);
    throw error;
  }
};

export const extractSkillsFromResume = async (resumeUrl) => {
  try {
    const response = await axios.post(`${API_URL}/profile/extract-skills`, { resume_url: resumeUrl });
    return response.data;
  } catch (error) {
    console.error('Error extracting skills:', error);
    throw error;
  }
};

export const getAllSkills = async () => {
  try {
    const response = await axios.get(`${API_URL}/analytics/skills/all`);
    return response.data;
  } catch (error) {
    console.error('Error fetching skills:', error);
    return [];
  }
};

// Create a named API object
const apiService = {
  uploadResume,
  updateUserSkills,
  getAllSkills,
};

// Export the named object as default
export default apiService;
