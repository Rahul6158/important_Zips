import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

import { AuthProvider } from './auth/AuthProvider';
import ProtectedRoute from './auth/ProtectedRoute';

import Navbar from './components/Navbar';
import Home from './components/Home';
import JobSearch from './components/JobSearch';
import JobDetail from './components/JobDetail';
import VendorList from './components/VendorList';
import VendorDetail from './components/VendorDetail';
import RecruiterList from './components/RecruiterList';
import RecruiterDetail from './components/RecruiterDetail';
import JobAnalytics from './components/JobAnalytics';
import ResumeTailor from './pages/ResumeTailor';
import Profile from './pages/Profile';
import Unauthorized from './pages/Unauthorized';
import Callback from './pages/Callback';

function App() {
  return (
    <Router>
      <AuthProvider>
        <div className="App">
          <Navbar />
          <div className="container-fluid mt-4 p-6">
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<Home />} />
              <Route path="/unauthorized" element={<Unauthorized />} />
              <Route path="/callback" element={<Callback />} />
              <Route path="/jobs/:jobId" element={<JobDetail />} />
              {/* Protected routes */}
              <Route element={<ProtectedRoute />}>
                <Route path="/jobs" element={<JobSearch />} />
                <Route path="/recruiters" element={<RecruiterList />} />
                <Route path="/recruiters/:recruiterId" element={<RecruiterDetail />} />
                <Route path="/vendors" element={<VendorList />} />
                <Route path="/vendors/:vendorId" element={<VendorDetail />} />
                <Route path="/analytics" element={<JobAnalytics />} />
                <Route path="/resume-tailor" element={<ResumeTailor />} />
                <Route path="/profile" element={<Profile />} />
              </Route>
              
              {/* Admin routes */}
              <Route element={<ProtectedRoute requiredRoles={['admin']} />}>
                {/* Add admin routes here */}
              </Route>
              
              {/* Catch all route - redirect to home */}
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </div>
        </div>
      </AuthProvider>
    </Router>
  );
}

export default App;