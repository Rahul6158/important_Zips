import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getVendorById, getJobs, getRecruiters, getVendors } from '../services/api';

const VendorDetail = () => {
  const { vendorId } = useParams();
  const [vendor, setVendor] = useState(null);
  const [recruiters, setRecruiters] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchVendorData = async () => {
      try {
        setLoading(true);
        
        // First try to fetch by internal ID
        let vendorData;
        try {
          vendorData = await getVendorById(vendorId);
        } catch (err) {
          console.error('Error fetching vendor by ID:', err);
          // If that fails, try to fetch all vendors and find by external ID
          const allVendors = await getVendors();
          // Check if allVendors is an array or has a vendors property
          const vendorsArray = Array.isArray(allVendors) ? allVendors : (allVendors.vendors || []);
          vendorData = vendorsArray.find(v => v.vendor_id === vendorId);
          
          if (!vendorData) {
            throw new Error('Vendor not found');
          }
        }
        
        setVendor(vendorData);
        
        // Fetch recruiters for this vendor
        const allRecruiters = await getRecruiters();
        // Check if allRecruiters is an array or has a recruiters property
        const recruitersArray = Array.isArray(allRecruiters) ? allRecruiters : (allRecruiters.recruiters || []);
        const vendorRecruiters = recruitersArray.filter(
          recruiter => recruiter.vendor_id === vendorData.id
        );
        setRecruiters(vendorRecruiters);
        
        // Fetch jobs for this vendor using the API's vendor_id filter
        const jobsResponse = await getJobs({ vendor_id: vendorData.id });
        const jobsArray = Array.isArray(jobsResponse) ? jobsResponse : (jobsResponse.jobs || []);
        setJobs(jobsArray);
        
        setLoading(false);
      } catch (err) {
        console.error('Error in fetchVendorData:', err);
        setError('Failed to fetch vendor details. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchVendorData();
  }, [vendorId]);
  
  if (loading) {
    return (
      <div className="text-center">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }
  
  if (error) {
    return <div className="alert alert-danger">{error}</div>;
  }
  
  if (!vendor) {
    return <div className="alert alert-warning">Vendor not found</div>;
  }
  
  return (
    <div className="p-5">
      <nav aria-label="breadcrumb">
        <ol className="breadcrumb">
          <li className="breadcrumb-item"><Link to="/vendors">Vendors</Link></li>
          <li className="breadcrumb-item active" aria-current="page">{vendor.name}</li>
        </ol>
      </nav>
      
      <div className="card mb-4">
        <div className="card-body">
          <h2 className="card-title">{vendor.name}</h2>
          
          {vendor.headquarters && (
            <p className="mb-2">
              <strong>Headquarters:</strong> {vendor.headquarters}
            </p>
          )}
          
          {vendor.website && (
            <p className="mb-2">
              <strong>Website:</strong>{' '}
              <a href={vendor.website} target="_blank" rel="noopener noreferrer">
                {vendor.website}
              </a>
            </p>
          )}
          
          {vendor.description && (
            <div className="mb-4">
              <h4>Description</h4>
              <p>{vendor.description}</p>
            </div>
          )}
          
          {vendor.overview && (
            <div className="mb-4">
              <h4>Overview</h4>
              <p>{vendor.overview}</p>
            </div>
          )}
        </div>
      </div>
      
      <div className="row">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h3>Recruiters ({recruiters.length})</h3>
            </div>
            <div className="card-body">
              {recruiters.length === 0 ? (
                <p>No recruiters found for this vendor.</p>
              ) : (
                <div className="list-group">
                  {recruiters.map(recruiter => (
                    <Link 
                      key={recruiter.id}
                      to={`/recruiters/${recruiter.recruiter_id}`}
                      className="list-group-item list-group-item-action"
                    >
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">{recruiter.name}</h5>
                      </div>
                      {recruiter.email && <p className="mb-1">{recruiter.email}</p>}
                      {recruiter.work_location && (
                        <small className="text-muted">{recruiter.work_location}</small>
                      )}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h3>Jobs ({jobs.length})</h3>
            </div>
            <div className="card-body">
              {jobs.length === 0 ? (
                <p>No jobs found for this vendor.</p>
              ) : (
                <div className="list-group">
                  {jobs.map(job => (
                    <Link 
                      key={job.id}
                      to={`/jobs/${job.job_id}`}
                      className="list-group-item list-group-item-action"
                    >
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">{job.title}</h5>
                        {job.status && (
                          <span className={`badge ${job.status === 'Active' ? 'bg-success' : 'bg-secondary'}`}>
                            {job.status}
                          </span>
                        )}
                      </div>
                      {job.location && <p className="mb-1">{job.location}</p>}
                      <div>
                        {job.rate && <span className="badge bg-info me-2">{job.rate}</span>}
                        {job.term && <span className="badge bg-primary">{job.term}</span>}
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VendorDetail;