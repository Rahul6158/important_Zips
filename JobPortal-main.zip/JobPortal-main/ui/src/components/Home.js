import React from 'react';
import { useAuth } from '../auth/AuthProvider';
import { Box, Button, Container, Typography, Paper } from '@mui/material';
import { Link } from 'react-router-dom';

const Home = () => {
  const auth = useAuth();
  
  const handleLogin = () => {
    console.log('Login button clicked');
    if (auth && auth.signinRedirect) {
      auth.signinRedirect();
    } else {
      console.error('Auth context or signinRedirect method is not available');
    }
  };
  
  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Paper elevation={3} sx={{ p: 4, textAlign: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Welcome to Job Portal
        </Typography>
        
        {auth.isAuthenticated ? (
          <Box>
            <Typography variant="h6" gutterBottom>
              Hello, {auth.userProfile?.given_name || auth.userProfile?.name || 'User'}!
            </Typography>
            <Typography variant="body1" paragraph>
              You are logged in. You can now access all features of the application.
            </Typography>
            <Box sx={{ mt: 3, display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button 
                component={Link} 
                to="/jobs" 
                variant="contained" 
                color="primary"
              >
                Browse Jobs
              </Button>
              <Button 
                component={Link} 
                to="/profile" 
                variant="outlined"
              >
                View Profile
              </Button>
            </Box>
          </Box>
        ) : (
          <Box>
            <Typography variant="body1" paragraph>
              Please log in to access the Job Portal features.
            </Typography>
            <Button 
              variant="contained" 
              color="primary" 
              onClick={handleLogin}
              size="large"
              sx={{ mt: 2 }}
            >
              Log In
            </Button>
          </Box>
        )}
      </Paper>
    </Container>
  );
};

export default Home;