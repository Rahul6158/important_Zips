import React, { useState, useEffect } from 'react';
import { getJobStatsBySkill, getJobStatsByLocation } from '../services/api';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const JobAnalytics = () => {
  const [skillStats, setSkillStats] = useState([]);
  const [locationStats, setLocationStats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setLoading(true);
        const [skillData, locationData] = await Promise.all([
          getJobStatsBySkill(20),
          getJobStatsByLocation(10)
        ]);
        
        setSkillStats(skillData);
        setLocationStats(locationData);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch analytics data. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchAnalytics();
  }, []);
  
  // Prepare data for skill chart
  const skillChartData = {
    labels: skillStats.map(item => item.skill),
    datasets: [
      {
        label: 'Number of Jobs',
        data: skillStats.map(item => item.count),
        backgroundColor: 'rgba(54, 162, 235, 0.6)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
    ],
  };
  
  // Prepare data for location chart
  const locationChartData = {
    labels: locationStats.map(item => item.location),
    datasets: [
      {
        label: 'Number of Jobs',
        data: locationStats.map(item => item.count),
        backgroundColor: 'rgba(255, 99, 132, 0.6)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      },
    ],
  };
  
  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Job Market Analytics',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0
        }
      }
    }
  };
  
  if (loading) {
    return (
      <div className="text-center">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }
  
  if (error) {
    return <div className="alert alert-danger">{error}</div>;
  }
  
  return (
    <div className="container mt-4">
      <h2>Job Market Analytics</h2>
      
      <div className="row mt-4">
        <div className="col-md-12 mb-4">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Most In-Demand Skills</h5>
              <div className="chart-container" style={{ height: '400px' }}>
                <Bar data={skillChartData} options={chartOptions} />
              </div>
            </div>
          </div>
        </div>
        
        <div className="col-md-12">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Jobs by Location</h5>
              <div className="chart-container" style={{ height: '400px' }}>
                <Bar data={locationChartData} options={chartOptions} />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="row mt-4">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Top Skills</h5>
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Skill</th>
                    <th>Number of Jobs</th>
                  </tr>
                </thead>
                <tbody>
                  {skillStats.map((item, index) => (
                    <tr key={index}>
                      <td>{item.skill}</td>
                      <td>{item.count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Top Locations</h5>
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Location</th>
                    <th>Number of Jobs</th>
                  </tr>
                </thead>
                <tbody>
                  {locationStats.map((item, index) => (
                    <tr key={index}>
                      <td>{item.location}</td>
                      <td>{item.count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobAnalytics;