import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getRecruiterById, getJobs, getVendorById, getRecruiters } from '../services/api';

const RecruiterDetail = () => {
  const { recruiterId } = useParams();
  const [recruiter, setRecruiter] = useState(null);
  const [vendor, setVendor] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchRecruiterData = async () => {
      try {
        setLoading(true);
        
        // First try to fetch by internal ID
        let recruiterData;
        try {
          recruiterData = await getRecruiterById(recruiterId);
        } catch (err) {
          console.error('Error fetching recruiter by ID:', err);
          // If that fails, try to fetch all recruiters and find by external ID
          const allRecruiters = await getRecruiters();
          // Check if allRecruiters is an array or has a recruiters property
          const recruitersArray = Array.isArray(allRecruiters) ? allRecruiters : (allRecruiters.recruiters || []);
          recruiterData = recruitersArray.find(r => r.recruiter_id === recruiterId);
          
          if (!recruiterData) {
            throw new Error('Recruiter not found');
          }
        }
        
        setRecruiter(recruiterData);
        
        // Fetch vendor if available
        if (recruiterData.vendor_id) {
          try {
            const vendorData = await getVendorById(recruiterData.vendor_id);
            setVendor(vendorData);
          } catch (vendorErr) {
            console.error('Error fetching vendor:', vendorErr);
          }
        }
        
        // Fetch jobs for this recruiter
        // Use the recruiter's internal ID to fetch jobs
        const params = {
          recruiter_id: recruiterData.id, // Use the internal ID
          status: 'Active',
          limit: 100 // Get a reasonable number of jobs
        };
        
        const jobsData = await getJobs(params);
        const jobsArray = Array.isArray(jobsData) ? jobsData : (jobsData.jobs || []);
        
        setJobs(jobsArray);
        setLoading(false);
      } catch (err) {
        console.error('Error in fetchRecruiterData:', err);
        setError('Failed to fetch recruiter details. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchRecruiterData();
  }, [recruiterId]);
  
  if (loading) {
    return (
      <div className="text-center">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }
  
  if (error) {
    return <div className="alert alert-danger">{error}</div>;
  }
  
  if (!recruiter) {
    return <div className="alert alert-warning">Recruiter not found</div>;
  }
  
  return (
    <div className="p-5">
      <nav aria-label="breadcrumb">
        <ol className="breadcrumb">
          <li className="breadcrumb-item"><Link to="/recruiters">Recruiters</Link></li>
          <li className="breadcrumb-item active" aria-current="page">{recruiter.name}</li>
        </ol>
      </nav>
      
      <div className="card mb-4">
        <div className="card-body">
          <h2 className="card-title">{recruiter.name}</h2>
          
          <div className="row">
            <div className="col-md-6">
              {recruiter.email && (
                <p className="mb-2">
                  <strong>Email:</strong> 
                  <a href={`mailto:${recruiter.email}`}> {recruiter.email}</a>
                </p>
              )}
              
              {recruiter.phone && (
                <p className="mb-2">
                  <strong>Phone:</strong> {recruiter.phone}
                </p>
              )}
              
              {recruiter.work_location && (
                <p className="mb-2">
                  <strong>Location:</strong> {recruiter.work_location}
                </p>
              )}
            </div>
            
            <div className="col-md-6">
              {recruiter.profile_url && (
                <p className="mb-2">
                  <strong>Profile:</strong>{' '}
                  <a href={recruiter.profile_url} target="_blank" rel="noopener noreferrer">
                    View Profile
                  </a>
                </p>
              )}
              
              {vendor && (
                <p className="mb-2">
                  <strong>Vendor:</strong>{' '}
                  <Link to={`/vendors/${vendor.vendor_id}`}>
                    {vendor.name}
                  </Link>
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="card">
        <div className="card-header">
          <h3>Job Postings ({jobs.length})</h3>
        </div>
        <div className="card-body">
          {jobs.length === 0 ? (
            <p>No job postings found for this recruiter.</p>
          ) : (
            <div className="list-group">
              {jobs.map(job => (
                <Link 
                  key={job.id}
                  to={`/jobs/${job.job_id}`}
                  className="list-group-item list-group-item-action"
                >
                  <div className="d-flex w-100 justify-content-between">
                    <h5 className="mb-1">{job.title}</h5>
                    {job.status && (
                      <span className={`badge ${job.status === 'Active' ? 'bg-success' : 'bg-secondary'}`}>
                        {job.status}
                      </span>
                    )}
                  </div>
                  {job.location && <p className="mb-1">{job.location}</p>}
                  <div>
                    {job.rate && <span className="badge bg-info me-2">{job.rate}</span>}
                    {job.term && <span className="badge bg-primary">{job.term}</span>}
                  </div>
                  {job.posted_date_text && (
                    <small className="text-muted">Posted: {job.posted_date_text}</small>
                  )}
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecruiterDetail;