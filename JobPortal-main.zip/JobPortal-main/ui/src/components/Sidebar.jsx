import React from 'react';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import {
  Box,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Typography,
  Divider,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import WorkIcon from '@mui/icons-material/Work';
import PeopleIcon from '@mui/icons-material/People';
import BusinessIcon from '@mui/icons-material/Business';
import DescriptionIcon from '@mui/icons-material/Description';
// ... other imports

const Sidebar = ({ open, onClose, drawerWidth }) => {
  const location = useLocation();
  
  const menuItems = [
    { text: 'Dashboard', icon: <DashboardIcon />, path: '/' },
    { text: 'Jobs', icon: <WorkIcon />, path: '/jobs' },
    { text: 'Recruiters', icon: <PeopleIcon />, path: '/recruiters' },
    { text: 'Vendors', icon: <BusinessIcon />, path: '/vendors' },
    { text: 'Resume Tailor', icon: <DescriptionIcon />, path: '/resume-tailor' },
    // ... other menu items
  ];

  // ... existing code

  return (
    <Drawer
      variant="permanent"
      open={open}
      // ... existing props
    >
      {/* ... existing drawer content */}
      
      <List>
        {menuItems.map((item) => (
          <ListItem
            button
            key={item.text}
            component={RouterLink}
            to={item.path}
            selected={location.pathname === item.path}
            // ... existing props
          >
            <ListItemIcon>{item.icon}</ListItemIcon>
            <ListItemText primary={item.text} />
          </ListItem>
        ))}
      </List>
      
      {/* ... existing drawer content */}
    </Drawer>
  );
};

export default Sidebar;