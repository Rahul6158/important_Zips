import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getVendors } from '../services/api';

const VendorList = () => {
  const navigate = useNavigate();
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Add sorting state
  const [sortBy, setSortBy] = useState('name'); // Default sort by name
  const [sortOrder, setSortOrder] = useState('asc'); // Default sort order
  
  useEffect(() => {
    const fetchVendors = async () => {
      try {
        setLoading(true);
        const data = await getVendors();
        setVendors(data);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch vendors. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchVendors();
  }, []);
  
  // Updated to use internal ID instead of vendor_id
  const handleVendorClick = (vendorId) => {
    navigate(`/vendors/${vendorId}`);
  };
  
  // Handle sorting click
  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc'); // Default to ascending when changing field
    }
  };
  
  const filteredVendors = vendors.filter(vendor => 
    vendor.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Client-side sorting
  const sortedVendors = [...filteredVendors].sort((a, b) => {
    let valueA, valueB;

    if (sortBy === 'total_jobs') {
      valueA = a.total_jobs || 0;
      valueB = b.total_jobs || 0;
    } else if (sortBy === 'recruiters_count') {
      valueA = a.recruiters_count || 0;
      valueB = b.recruiters_count || 0;
    } else { // Default to sorting by name
      valueA = (a.name || '').toLowerCase();
      valueB = (b.name || '').toLowerCase();
    }

    if (valueA < valueB) {
      return sortOrder === 'asc' ? -1 : 1;
    }
    if (valueA > valueB) {
      return sortOrder === 'asc' ? 1 : -1;
    }
    return 0;
  });
  
  return (
    <div className="p-5">
      <h2>Vendors</h2>
      
      <div className="search-container mb-4">
        <div className="input-group">
          <input
            type="text"
            className="form-control"
            placeholder="Search vendors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button className="btn btn-primary" type="button">
            Search
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : error ? (
        <div className="alert alert-danger">{error}</div>
      ) : filteredVendors.length === 0 ? (
        <div className="alert alert-info">No vendors found matching your search.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover">
            <thead>
              <tr>
                <th onClick={() => handleSort('name')} style={{ cursor: 'pointer' }}>
                  Name {sortBy === 'name' && (sortOrder === 'asc' ? '▲' : '▼')}
                </th>
                <th onClick={() => handleSort('recruiters_count')} style={{ cursor: 'pointer' }}>
                  Total Recruiters {sortBy === 'recruiters_count' && (sortOrder === 'asc' ? '▲' : '▼')}
                </th>
                <th onClick={() => handleSort('total_jobs')} style={{ cursor: 'pointer' }}>
                  Total Jobs {sortBy === 'total_jobs' && (sortOrder === 'asc' ? '▲' : '▼')}
                </th>
                <th>Location</th>
                <th>Source</th>
                <th>External Link</th>
              </tr>
            </thead>
            <tbody>
              {sortedVendors.map((vendor) => (
                <tr 
                  key={vendor.id} 
                  onClick={() => handleVendorClick(vendor.id)}
                  style={{ cursor: 'pointer' }}
                >
                  <td>{vendor.name || 'N/A'}</td>
                  <td>{vendor.recruiters_count !== undefined ? vendor.recruiters_count : 0}</td>
                  <td>{vendor.total_jobs !== undefined ? vendor.total_jobs : 0}</td>
                  <td>{vendor.headquarters || 'N/A'}</td>
                  <td>{vendor.source || 'N/A'}</td>
                  <td>
                    {vendor.external_url && (
                      <a 
                        href={vendor.external_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()} // Prevent row click when clicking the link
                        className="btn btn-sm btn-outline-primary"
                      >
                        View Profile
                      </a>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default VendorList;