import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { getJobs, getUniqueLocations, getUniqueSkills } from '../services/api';
import { formatRelativeDate } from '../utils/dateUtils';

const JobSearch = () => {
  const navigate = useNavigate();
  const locationHook = useLocation();
  const queryParams = new URLSearchParams(locationHook.search);
  
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Pagination state
  const [page, setPage] = useState(Number(queryParams.get('page')) || 1);
  const [pageSize, setPageSize] = useState(Number(queryParams.get('limit')) || 10);
  const [totalJobs, setTotalJobs] = useState(0);
  
  // Search and filter states
  const [searchTerm, setSearchTerm] = useState(queryParams.get('q') || '');
  const [location, setLocation] = useState(queryParams.get('location') || '');
  const [locationType, setLocationType] = useState(queryParams.get('location_type') || '');
  const [rate, setRate] = useState(queryParams.get('rate') || '');
  const [term, setTerm] = useState(queryParams.get('term') || '');
  
  // Sorting state
  const [sortBy, setSortBy] = useState(queryParams.get('sort') || 'posted_date');
  const [sortOrder, setSortOrder] = useState(queryParams.get('order') || 'desc');
  
  // Add date filter state
  const [dateFilter, setDateFilter] = useState(queryParams.get('date_filter') || '');
  
  // Add employment type filter
  const [employmentType, setEmploymentType] = useState(queryParams.get('employment_type') || '');
  
  // Add skill filter
  const [skillFilter, setSkillFilter] = useState('');
  const [selectedSkills, setSelectedSkills] = useState(
    queryParams.get('skills') ? queryParams.get('skills').split(',') : []
  );
  
  // Add autocomplete options
  const [locationOptions, setLocationOptions] = useState([]);
  const [skillOptions, setSkillOptions] = useState([]);
  const [locationSuggestions, setLocationSuggestions] = useState([]);
  const [skillSuggestions, setSkillSuggestions] = useState([]);

  // Fetch autocomplete options
  useEffect(() => {
    const fetchOptions = async () => {
      try {
        console.log('Fetching location options...');
        const locations = await getUniqueLocations();
        console.log('Received locations:', locations);
        setLocationOptions(locations);
        
        const skills = await getUniqueSkills();
        setSkillOptions(skills);
      } catch (err) {
        console.error('Failed to fetch autocomplete options:', err);
      }
    };
    
    fetchOptions();
  }, []);
  
  // Update location suggestions when user types
  useEffect(() => {
    if (location.trim() === '') {
      setLocationSuggestions([]);
    } else {
      const filteredLocations = locationOptions.filter(
        loc => loc && loc.toLowerCase().includes(location.toLowerCase())
      ).slice(0, 5); // Limit to 5 suggestions
      setLocationSuggestions(filteredLocations);
      console.log("Location suggestions:", filteredLocations); // Debug log
    }
  }, [location, locationOptions]);
  
  // Update skill suggestions when user types
  useEffect(() => {
    if (skillFilter.trim() === '') {
      setSkillSuggestions([]);
    } else {
      const filteredSkills = skillOptions
        .filter(
          skill => skill && 
          skill.toLowerCase().includes(skillFilter.toLowerCase()) && 
          !selectedSkills.includes(skill)
        )
        .slice(0, 5); // Limit to 5 suggestions
      setSkillSuggestions(filteredSkills);
    }
  }, [skillFilter, skillOptions, selectedSkills]);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);
        
        // Build filter params
        const params = {};
        if (searchTerm) params.q = searchTerm;
        if (location) params.location = location;
        if (locationType) params.location_type = locationType;
        if (rate) params.rate = rate;
        if (term) params.term = term;
        if (employmentType) params.employment_type = employmentType;
        // Remove skillFilter from params - only use selectedSkills
        // if (skillFilter) params.skill = skillFilter;
        if (selectedSkills.length > 0) params.skills = selectedSkills.join(',');
        if (dateFilter) params.date_filter = dateFilter;
        params.status = 'Active';
        params.sort = sortBy;
        params.order = sortOrder;
        params.limit = pageSize;
        params.skip = (page - 1) * pageSize;
        
        const data = await getJobs(params);
        
        // Add console log to debug the response
        console.log('API Response:', data);
        
        // Check if data exists and has the expected structure
        if (!data || typeof data !== 'object') {
          throw new Error('Invalid response format from API');
        }
        
        // Process date fields for display
        const processedJobs = Array.isArray(data.jobs) 
          ? data.jobs.map(job => ({
              ...job,
              posted_date_text: job.date_posted ? formatRelativeDate(job.date_posted) : '',
              updated_date_text: job.date_updated ? formatRelativeDate(job.date_updated) : ''
            }))
          : [];
        
        // Use backend's paginated response
        setJobs(processedJobs);
        setTotalJobs(data.total || 0);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching jobs:', err);
        setError('Failed to fetch jobs. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchJobs();
  // Remove skillFilter from dependency array to prevent API calls while typing
  }, [searchTerm, location, locationType, rate, term, employmentType, selectedSkills, dateFilter, sortBy, sortOrder, page, pageSize]);
  
  // // Add useEffect to fetch unique skills
  // useEffect(() => {
  //   const fetchUniqueSkills = async () => {
  //     try {
  //       const skills = await getUniqueSkills(100); // Get top 100 skills
  //       setUniqueSkills(skills);
  //     } catch (err) {
  //       console.error('Failed to fetch unique skills:', err);
  //     }
  //   };
    
  //   fetchUniqueSkills();
  // }, []);
  
  const handleSearch = (e) => {
    e.preventDefault();
    
    // Update URL with search params
    const params = new URLSearchParams();
    if (searchTerm) params.set('q', searchTerm);
    if (location) params.set('location', location);
    if (locationType) params.set('location_type', locationType);
    if (rate) params.set('rate', rate);
    if (term) params.set('term', term);
    if (employmentType) params.set('employment_type', employmentType);
    if (selectedSkills.length > 0) params.set('skills', selectedSkills.join(','));
    if (dateFilter) params.set('date_filter', dateFilter);
    params.set('sort', sortBy);
    params.set('order', sortOrder);
    params.set('page', 1); // Reset to first page on new search
    
    navigate(`/jobs?${params.toString()}`);
  };
  
  const handleSort = (field) => {
    if (sortBy === field) {
      // Toggle sort order if clicking the same field
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      // Set new sort field and default to descending
      setSortBy(field);
      setSortOrder('desc');
    }
  };
  
  const handleJobClick = (jobId) => {
    navigate(`/jobs/${jobId}`);
  };
  
  // Pagination controls
  const totalPages = Math.ceil(totalJobs / pageSize);
  
  const handlePageChange = (newPage) => {
    setPage(newPage);
    const params = new URLSearchParams(locationHook.search);
    params.set('page', newPage);
    params.set('limit', pageSize);
    navigate(`/jobs?${params.toString()}`);
  };
  
  const handlePageSizeChange = (e) => {
    const newSize = Number(e.target.value);
    setPageSize(newSize);
    setPage(1); // Reset to first page
    const params = new URLSearchParams(locationHook.search);
    params.set('page', 1);
    params.set('limit', newSize);
    navigate(`/jobs?${params.toString()}`);
  };
  
  // Helper function to create Dice.com URL from job_id
  const getDiceJobUrl = (jobId) => {
    if (!jobId) return null;
    return `https://www.dice.com/job-detail/${jobId}`;
  };
  
  // Add a skill to the selected skills list
  const addSkill = (skill) => {
    if (skill && !selectedSkills.includes(skill)) {
      const newSelectedSkills = [...selectedSkills, skill];
      setSelectedSkills(newSelectedSkills);
      
      // Update URL params with the new skills
      const params = new URLSearchParams(locationHook.search);
      params.set('skills', newSelectedSkills.join(','));
      params.set('page', 1); // Reset to first page when adding a filter
      navigate(`/jobs?${params.toString()}`);
      
      setSkillFilter(''); // Clear the input after adding
      setSkillSuggestions([]); // Clear suggestions
    }
  };
  
  // Remove a skill from the selected skills list
  const removeSkill = (skillToRemove) => {
    const newSelectedSkills = selectedSkills.filter(skill => skill !== skillToRemove);
    setSelectedSkills(newSelectedSkills);
    
    // Update URL params with the new skills
    const params = new URLSearchParams(locationHook.search);
    if (newSelectedSkills.length > 0) {
      params.set('skills', newSelectedSkills.join(','));
    } else {
      params.delete('skills');
    }
    params.set('page', 1); // Reset to first page when removing a filter
    navigate(`/jobs?${params.toString()}`);
  };
  
  // Handle skill input keydown (for Enter key)
  const handleSkillKeyDown = (e) => {
    if (e.key === 'Enter' && skillFilter.trim() !== '') {
      e.preventDefault(); // Prevent form submission
      if (skillSuggestions.length > 0) {
        // Add the first suggestion if there are any
        addSkill(skillSuggestions[0]);
      } else {
        // Add the current input as a new skill
        addSkill(skillFilter.trim());
      }
    }
  };
  
  // Add state for context menu
  const [contextMenu, setContextMenu] = useState(null);
  const [selectedJobId, setSelectedJobId] = useState(null);
  
  // Handle right-click on job card
  const handleContextMenu = (e, jobId) => {
    e.preventDefault();
    setSelectedJobId(jobId);
    setContextMenu(
      contextMenu === null
        ? {
            mouseX: e.clientX + 2,
            mouseY: e.clientY - 6,
          }
        : null,
    );
  };
  
  // Handle closing the context menu
  const handleClose = () => {
    setContextMenu(null);
  };
  
  // Handle opening job in new tab
  const handleOpenInNewTab = () => {
    if (selectedJobId) {
      window.open(`/jobs/${selectedJobId}`, '_blank');
      handleClose();
    }
  };
  
  return (
    <div className="container-fluid">
      <div className="row">
        {/* Filter Sidebar - Modified to be more responsive */}
        <div className="col-md-4 col-lg-3">
          <div className="filter-sidebar position-sticky" style={{ 
            top: '55px', 
            maxHeight: '100vh', 
            overflowY: 'auto',
            paddingBottom: '10px'
          }}>
            <h4>Filters</h4>
            <form onSubmit={handleSearch}>
              {/* Search input */}
              <div className="mb-3">
                <label htmlFor="searchTerm" className="form-label">Search(ALpha)</label>
                <input
                  type="text"
                  className="form-control"
                  id="searchTerm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Job title, skills, etc."
                />
              </div>
              
              <div className="mb-3">
                <label htmlFor="location" className="form-label">Location</label>
                <div className="position-relative">
                  <input
                    type="text"
                    className="form-control"
                    id="location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Austin, TX"
                    autoComplete="on"
                  />
                  {locationSuggestions.length > 0 && (
                    <div className="position-absolute w-100 bg-white border rounded-bottom shadow-sm" 
                         style={{ zIndex: 1050, maxHeight: '200px', overflowY: 'auto' }}>
                      {locationSuggestions.map((loc, index) => (
                        <div 
                          key={index} 
                          className="p-2 border-bottom hover-bg-light cursor-pointer" 
                          style={{ cursor: 'pointer' }}
                          onClick={() => {
                            setLocation(loc);
                            setLocationSuggestions([]);
                          }}
                          onMouseDown={(e) => e.preventDefault()} // Prevent input blur
                        >
                          {loc}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              
              {/* Updated location filter with specific options */}
              {/* Update the location filter dropdown to ensure it has the correct options */}
              <div className="mb-3">
                <label htmlFor="locationType" className="form-label">Location Type</label>
                <select
                  className="form-select"
                  id="locationType"
                  value={locationType}
                  onChange={(e) => setLocationType(e.target.value)}
                >
                  <option value="">Any Location Type</option>
                  <option value="Remote">Remote</option>
                  <option value="Hybrid">Hybrid</option>
                  <option value="On-Site">On-Site</option>
                </select>
              </div>
              

              
              <div className="mb-3">
                <label htmlFor="rate" className="form-label">Rate(Alpha)</label>
                <input
                  type="text"
                  className="form-control"
                  id="rate"
                  value={rate}
                  onChange={(e) => setRate(e.target.value)}
                  placeholder="e.g. $50-70/hr"
                />
              </div>
              
              <div className="mb-3">
                <label htmlFor="term" className="form-label">Term(Alpha)</label>
                <select
                  className="form-select"
                  id="term"
                  value={term}
                  onChange={(e) => setTerm(e.target.value)}
                >
                  <option value="">Any Term</option>
                  <option value="Contract">Contract</option>
                  <option value="Contract-to-Hire">Contract-to-Hire</option>
                  <option value="Direct Hire">Direct Hire</option>
                </select>
              </div>
              
              {/* New employment type filter */}
              <div className="mb-3">
                <label htmlFor="employmentType" className="form-label">Employment Type</label>
                <select
                  className="form-select"
                  id="employmentType"
                  value={employmentType}
                  onChange={(e) => setEmploymentType(e.target.value)}
                >
                  <option value="">Any Type</option>
                  <option value="Accepts corp to corp applications">Accepts corp to corp applications</option>
                  {/* <option value="Full-time">Full-time</option>
                  <option value="Part-time">Part-time</option>
                  <option value="Contract">Contract</option>
                  <option value="Temporary">Temporary</option>
                  <option value="Internship">Internship</option> */}
                </select>
              </div>
              
              {/* New multi-skill filter */}
              <div className="mb-3">
                <label htmlFor="skillFilter" className="form-label">Skills</label>
                <div className="position-relative">
                  <input
                    type="text"
                    className="form-control"
                    id="skillFilter"
                    value={skillFilter}
                    onChange={(e) => setSkillFilter(e.target.value)}
                    onKeyDown={handleSkillKeyDown}
                    placeholder="e.g. React, Python, AWS"
                    autoComplete="off"
                  />
                  {skillSuggestions.length > 0 && (
                    <div className="position-absolute w-100 bg-white border rounded-bottom shadow-sm" 
                         style={{ zIndex: 1050, maxHeight: '200px', overflowY: 'auto' }}>
                      {skillSuggestions.map((skill, index) => (
                        <div 
                          key={index} 
                          className="p-2 border-bottom hover-bg-light" 
                          style={{ cursor: 'pointer' }}
                          onClick={() => {
                            addSkill(skill);
                            setSkillSuggestions([]);
                          }}
                          onMouseDown={(e) => e.preventDefault()} // Prevent input blur
                        >
                          {skill}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {/* Display selected skills as badges */}
                <div className="selected-skills mt-2">
                  {selectedSkills.map((skill, index) => (
                    <span 
                      key={index} 
                      className="badge bg-primary me-1 mb-1" 
                      style={{ cursor: 'pointer' }}
                    >
                      {skill}
                      <span 
                        className="ms-1" 
                        onClick={() => removeSkill(skill)}
                      >
                        &times;
                      </span>
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Date filter */}
              <div className="mb-3">
                <label htmlFor="dateFilter" className="form-label">Posted Date</label>
                <select
                  className="form-select"
                  id="dateFilter"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  style={{ 
                    border: '2px solid #007bff',
                    borderRadius: '4px',
                    backgroundColor: '#f8f9fa'
                  }}
                >
                  <option value="">Any Time</option>
                  <option value="24h">Last 24 Hours</option>
                  <option value="48h">Last 2 Days</option>
                  <option value="72h">Last 3 Days</option>
                </select>
              </div>
              
              <div className="mb-3">
                <label htmlFor="pageSize" className="form-label">Jobs per page</label>
                <select
                  className="form-select"
                  id="pageSize"
                  value={pageSize}
                  onChange={handlePageSizeChange}
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
              
              {/* <button type="submit" className="btn btn-primary w-100">Apply Filters</button> */}
            </form>
          </div>
        </div>
        
        {/* Main content - Adjusted column width to match sidebar */}
        <div className="col-md-8 col-lg-9 main-content-with-sidebar">
          {/* Modified header section to have all elements on one line */}
          <div className="d-flex justify-content-between align-items-center mb-3">
            <div className="d-flex align-items-center">
              <h2 className="me-3 mb-0">Jobs</h2>
              {!loading && jobs.length > 0 && (
                <p className="mb-0">{totalJobs} jobs found (showing {jobs.length})</p>
              )}
            </div>
            <div>
              <select
                className="form-select form-select-sm me-2"
                value={dateFilter}
                onChange={(e) => {
                  setDateFilter(e.target.value);
                  // Update URL with the new date filter
                  const params = new URLSearchParams(locationHook.search);
                  if (e.target.value) {
                    params.set('date_filter', e.target.value);
                  } else {
                    params.delete('date_filter');
                  }
                  navigate(`/jobs?${params.toString()}`);
                }}
                style={{ 
                  width: 'auto', 
                  display: 'inline-block',
                  minWidth: '150px',
                  padding: '6px 12px',
                  border: '2px solid #007bff',
                  borderRadius: '4px',
                  backgroundColor: '#f8f9fa'
                }}
              >
                <option value="">All Time</option>
                <option value="24h">Last 24 Hours</option>
                <option value="48h">Last 2 Days</option>
                <option value="72h">Last 3 Days</option>
              </select>
              <button
                className={`btn btn-sm ${sortBy === 'title' ? 'btn-primary' : 'btn-outline-primary'}`}
                onClick={() => handleSort('title')}
              >
                Title {sortBy === 'title' && (sortOrder === 'desc' ? '↓' : '↑')}
              </button>
            </div>
          </div>
          
          {loading ? (
            <div className="text-center">
              <div className="spinner-border" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            </div>
          ) : error ? (
            <div className="alert alert-danger">{error}</div>
          ) : jobs.length === 0 ? (
            <div className="alert alert-info">No jobs found matching your criteria.</div>
          ) : (
            <div>
              {jobs.map((job) => (
                <div 
                  key={job.id} 
                  className="card mb-3 job-card" 
                  onClick={() => handleJobClick(job.id)}
                  onContextMenu={(e) => handleContextMenu(e, job.id)}
                >
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-start">
                      <h5 className="card-title mb-1">{job.title}</h5>
                      {job.job_id && (
                        <a 
                          href={getDiceJobUrl(job.job_id)} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()} // Prevent card click
                          className="btn btn-sm btn-outline-primary"
                        >
                          View on Dice
                        </a>
                      )}
                    </div>
                    
                    <div className="mb-2">
                      {job.rate && <span className="badge bg-success me-2">{job.rate}</span>}
                      {job.term && <span className="badge bg-info me-2">{job.term}</span>}
                      {job.location && <span className="badge bg-secondary me-2">{job.location}</span>}
                      {job.location_type && <span className="badge bg-secondary me-2">{job.location_type}</span>}
                      {job.yoe && job.yoe !== 'N/A' && <span className="badge bg-primary me-2">{job.yoe}+ years</span>}
                      
                      {/* Display employment details if available */}
                      {job.employment_details_list && job.employment_details_list.map((detail, idx) => (
                        <span key={idx} className="badge bg-light text-dark me-2">{detail}</span>
                      ))}
                    </div>
                    
                    <p className="card-text mb-1">{job.description_short || job.description?.substring(0, 150) + '...' || 'No description available'}</p>
                    
                    <div className="d-flex justify-content-between align-items-end mt-2">
                      <div>
                        {/* Display application email instead of recruiter info */}
                        <small className="text-muted">
                          {job.application_email ? (
                            <>
                              <strong>Apply via: </strong>
                              <a 
                                href={`mailto:${job.application_email}`}
                                onClick={(e) => e.stopPropagation()} // Prevent card click
                              >
                                {job.application_email}
                              </a>
                            </>
                          ) : job.recruiter_email ? (
                            <>
                              <strong>Contact: </strong>
                              <a 
                                href={`mailto:${job.recruiter_email}`}
                                onClick={(e) => e.stopPropagation()} // Prevent card click
                              >
                                {job.recruiter_email}
                              </a>
                            </>
                          ) : (
                            job.recruiter_name || 'Unknown recruiter'
                          )}
                        </small>
                      </div>
                      <div className="text-end">
                        <small className="text-muted">
                          {job.posted_date_text && <span>Posted: {job.posted_date_text}</span>}
                          {job.posted_date_text && job.updated_date_text && <span> • </span>}
                          {job.updated_date_text && <span>Updated: {job.updated_date_text}</span>}
                        </small>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Pagination Controls */}
              {totalJobs > 0 && (
                <nav aria-label="Job pagination" className="mt-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <span>Page {page} of {totalPages}</span>
                    </div>
                    <ul className="pagination">
                      <li className={`page-item ${page === 1 ? 'disabled' : ''}`}>
                        <button 
                          className="page-link" 
                          onClick={() => handlePageChange(page - 1)} 
                          disabled={page === 1}
                        >
                          Previous
                        </button>
                      </li>
                      
                      {/* Show page numbers */}
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        // Logic to show pages around current page
                        let pageNum;
                        if (totalPages <= 5) {
                          // If 5 or fewer pages, show all
                          pageNum = i + 1;
                        } else if (page <= 3) {
                          // If near start, show first 5 pages
                          pageNum = i + 1;
                        } else if (page >= totalPages - 2) {
                          // If near end, show last 5 pages
                          pageNum = totalPages - 4 + i;
                        } else {
                          // Otherwise show 2 before and 2 after current page
                          pageNum = page - 2 + i;
                        }
                        
                        return (
                          <li key={pageNum} className={`page-item ${page === pageNum ? 'active' : ''}`}>
                            <button 
                              className="page-link" 
                              onClick={() => handlePageChange(pageNum)}
                            >
                              {pageNum}
                            </button>
                          </li>
                        );
                      })}
                      
                      <li className={`page-item ${page === totalPages ? 'disabled' : ''}`}>
                        <button 
                          className="page-link" 
                          onClick={() => handlePageChange(page + 1)} 
                          disabled={page === totalPages}
                        >
                          Next
                        </button>
                      </li>
                    </ul>
                  </div>
                </nav>
              )}
              
                {/* Context Menu */}
                {contextMenu !== null && (
                  <div 
                    className="position-fixed bg-white border rounded shadow-sm"
                    style={{
                      top: contextMenu.mouseY,
                      left: contextMenu.mouseX,
                      zIndex: 1500,
                    }}
                  >
                    <ul className="list-group list-group-flush" style={{ minWidth: '150px' }}>
                      <li 
                        className="list-group-item list-group-item-action"
                        onClick={handleOpenInNewTab}
                        style={{ cursor: 'pointer' }}
                      >
                        Open in new tab
                      </li>
                    </ul>
                  </div>
                )}
                
                {/* Overlay to capture clicks outside the context menu */}
                {contextMenu !== null && (
                  <div 
                    className="position-fixed"
                    style={{
                      top: 0,
                      left: 0,
                      width: '100vw',
                      height: '100vh',
                      zIndex: 1400,
                    }}
                    onClick={handleClose}
                  />
                )}
              </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default JobSearch;
