import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getJobById, getJobByInternalId } from '../services/api';
import { formatRelativeDate } from '../utils/dateUtils';

const JobDetail = () => {
  const { jobId } = useParams();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [matchingCandidates, setMatchingCandidates] = useState([]);
  const [loadingCandidates, setLoadingCandidates] = useState(false);
  
  useEffect(() => {
    const fetchJobDetail = async () => {
      try {
        setLoading(true);
        console.log("Fetching job with ID:", jobId); // Debug log
        
        let data;
        try {
          // First try with the regular endpoint
          data = await getJobById(jobId);
        } catch (err) {
          // If that fails, try with the internal ID endpoint
          console.log("Trying with internal ID endpoint");
          data = await getJobByInternalId(jobId);
        }
        
        // Process date fields for display
        if (data) {
          // Format for relative time (e.g., "2 hours ago")
          data.posted_date_text = data.date_posted ? formatRelativeDate(data.date_posted) : '';
          data.updated_date_text = data.date_updated ? formatRelativeDate(data.date_updated) : '';
          
          // Format for actual dates with explicit timezone handling
          const formatDateWithTimezone = (dateString) => {
            if (!dateString) return '';
            
            // Create date object from UTC string
            const date = new Date(dateString);
            
            // Format with explicit timezone information
            return date.toLocaleString(undefined, {
              year: 'numeric',
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
              timeZoneName: 'short',
              timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone // Use system timezone
            });
          };
          
          // Apply the formatting to all date fields
          data.posted_date_actual = formatDateWithTimezone(data.date_posted);
          data.updated_date_actual = formatDateWithTimezone(data.date_updated);
          
          if (data.date_first_active) {
            data.first_active_formatted = formatDateWithTimezone(data.date_first_active);
          }
          
          if (data.date_deactivated) {
            data.deactivated_formatted = formatDateWithTimezone(data.date_deactivated);
          }
        }
        
        console.log("Job data received:", data); // Debug log
        setJob(data);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching job details:", err); // Log the actual error
        setError(`Failed to fetch job details. Error: ${err.message}`);
        setLoading(false);
      }
    };
    
    fetchJobDetail();
  }, [jobId]);
  
  // Add effect to fetch matching candidates
  useEffect(() => {
    const fetchMatchingCandidates = async () => {
      // This would be replaced with an actual API call in the future
      if (!job) return;
      
      setLoadingCandidates(true);
      
      // Simulate API call with timeout
      setTimeout(() => {
        // Mock data for now - would be replaced with actual API response
        const mockCandidates = [
          { id: 1, name: "John Doe", matchScore: 92, skills: ["React", "Node.js", "TypeScript"] },
          { id: 2, name: "Jane Smith", matchScore: 87, skills: ["JavaScript", "React", "MongoDB"] },
          { id: 3, name: "Alex Johnson", matchScore: 81, skills: ["React", "Express", "SQL"] },
        ];
        
        setMatchingCandidates(mockCandidates);
        setLoadingCandidates(false);
      }, 1000);
    };
    
    if (job) {
      fetchMatchingCandidates();
    }
  }, [job]);
  
  if (loading) {
    return (
      <div className="text-center">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }
  
  if (error) {
    return <div className="alert alert-danger">{error}</div>;
  }
  
  if (!job) {
    return <div className="alert alert-warning">Job not found</div>;
  }
  
  // Parse employment details if it's a string
  const employmentDetails = Array.isArray(job.employment_details) 
    ? job.employment_details 
    : (job.employment_details ? JSON.parse(job.employment_details) : []);
  
  return (
    <div className="container-fluid px-4">
      {/* <nav aria-label="breadcrumb">
        <ol className="breadcrumb">
          <li className="breadcrumb-item"><Link to="/jobs">Jobs</Link></li>
          <li className="breadcrumb-item active" aria-current="page">{job.title}</li>
        </ol>
      </nav> */}
      
      <div className="row">
        {/* Left Sidebar - Matching Candidates */}
        <div className="col-md-2">
          <div className="card mb-2 sticky-top" style={{ top: "20px" }}>
            <div className="card-header bg-primary text-white">
              <h5 className="mb-0">Matching Candidates alpha</h5>
            </div>
            <div className="card-body">
              {loadingCandidates ? (
                <div className="text-center py-4">
                  <div className="spinner-border" role="status">
                    <span className="visually-hidden">Loading candidates...</span>
                  </div>
                </div>
              ) : matchingCandidates.length > 0 ? (
                <div>
                  {matchingCandidates.map(candidate => (
                    <div key={candidate.id} className="card mb-3 border-light">
                      <div className="card-body p-2">
                        <div className="d-flex justify-content-between align-items-center mb-2">
                          <h6 className="mb-0">{candidate.name}</h6>
                          <span className="badge bg-success">{candidate.matchScore}% Match</span>
                        </div>
                        <div className="d-flex flex-wrap">
                          {candidate.skills.map((skill, index) => (
                            <span key={index} className="badge bg-light text-dark me-1 mb-1">
                              {skill}
                            </span>
                          ))}
                        </div>
                        <button className="btn btn-sm btn-outline-primary mt-2 me-3">
                          View Profile
                        </button>
                        <button className="btn btn-sm btn-outline-primary mt-2 me-2">
                          Tailor Resume
                        </button>
                      </div>
                    </div>
                  ))}
                  {/* <div className="text-center mt-3">
                    <button className="btn btn-outline-primary btn-sm">
                      View All Matching Candidates
                    </button>
                  </div> */}
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-muted">No matching candidates found</p>
                  <button className="btn btn-outline-primary btn-sm">
                    Search for Candidates
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>
        
        {/* Main Content - Job Details */}
        <div className="col-md-7">
          <div className={`card mb-2 ${job.status === 'INACTIVE' ? 'bg-secondary' : 'bg-gray'}`}>
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h2 className="card-title mb-0">{job.title}</h2>
                <a href={job.external_url} target="_blank" rel="noopener noreferrer" className="btn btn-outline-primary  bg-primary text-light btn-sm">
                  View Source
                </a>
                <span className={`badge fs-6 px-3 py-2 ${job.status === 'INACTIVE' ? 'bg-secondary' : 'bg-success'}`}>
                  {job.status}
                </span>
              </div>
              
              <div className="mb-3">
                {job.rate && <span className="badge bg-success me-2">{job.rate}</span>}
                {job.term && <span className="badge bg-info me-2">{job.term}</span>}
                {job.location ? <span className="badge bg-secondary me-2">{job.location}</span> : <span className="badge bg-secondary me-2">No Location</span>}
                {job.location_type && <span className="badge bg-secondary me-2">{job.location_type}</span>}
                {job.yoe && job.yoe !== 'N/A' && <span className="badge bg-primary me-2">{job.yoe}+ years</span>}
              </div>

              <div className="row mb-4">
                <div className="col-md-6">
                  <h5>Posted by</h5>
                  {job.recruiter ? (
                    <Link to={`/recruiters/${job.recruiter.id}`}>
                      View Recruiter {job.recruiter.name ? `(${job.recruiter.name})` : ''}
                    </Link>
                  ) : job.recruiter_id ? (
                    <Link to={`/recruiters/${job.recruiter_id}`}>
                      View Recruiter
                    </Link>
                  ) : (
                    <span>No recruiter information</span>
                  )}
                
                  {(job.vendor || job.vendor_id) && (
                    <div className="mt-2">
                      {job.vendor ? (
                        <Link to={`/vendors/${job.vendor.id}`}>
                          View Vendor {job.vendor.name ? `(${job.vendor.name})` : ''}
                        </Link>
                      ) : job.vendor_id ? (
                        <Link to={`/vendors/${job.vendor_id}`}>
                          View Vendor
                        </Link>
                      ) : null}
                    </div>
                  )}
                
                  {/* Recruiter Email - Moved from How to Apply section */}
                  {job.application_email && (
                    <div className="mt-2">
                      <strong>Recruiter Email:</strong> <a href={`mailto:${job.application_email}`}>{job.application_email}</a>
                    </div>
                  )}
                </div>
                
                {/* Dates Section */}
                <div className="col-md-6">
                  <div className="mt-3">
                    {/* <h5>Dates</h5> */}
                    <div className="d-flex flex-wrap justify-content-between">
                      {job.date_posted && (
                        <div className="timeline-item mb-1 me-2" style={{ width: '48%' }}>
                          <div className="timeline-marker bg-success"></div>
                          <div className="timeline-content">
                            <h6 className="mb-1">Posted</h6>
                            <p className="small text-muted mb-0">{job.posted_date_actual}</p>
                          </div>
                        </div>
                      )}
                      
                      {job.date_updated && (
                        <div className="timeline-item mb-3 me-2" style={{ width: '48%' }}>
                          <div className="timeline-marker bg-info"></div>
                          <div className="timeline-content">
                            <h6 className="mb-1">Updated</h6>
                            <p className="small text-muted mb-0">{job.updated_date_actual}</p>
                          </div>
                        </div>
                      )}
                      
                      {job.date_first_active && (
                        <div className="timeline-item mb-3 me-2" style={{ width: '48%' }}>
                          <div className="timeline-marker bg-primary"></div>
                          <div className="timeline-content">
                            <h6 className="mb-1">First Active</h6>
                            <p className="small text-muted mb-0">{job.first_active_formatted}</p>
                          </div>
                        </div>
                      )}
                      
                      {job.date_deactivated && (
                        <div className="timeline-item me-2" style={{ width: '48%' }}>
                          <div className="timeline-marker bg-danger"></div>
                          <div className="timeline-content">
                            <h6 className="mb-1">Expires</h6>
                            <p className="small text-muted mb-0">{job.deactivated_formatted}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Employment Details Section */}
          {employmentDetails && employmentDetails.length > 0 && (
            <div className="card mb-2">
              <div className="card-body">
                <h5>Employment Details</h5>
                <div className="d-flex flex-wrap">
                  {employmentDetails.map((detail, index) => (
                    <span key={index} className="badge bg-secondary text-light me-2 mb-2 p-2">
                      {detail}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Skills Section */}
          {job.skills && job.skills.length > 0 && (
            <div className="card mb-2">
              <div className="card-body">
                <h5>Skills</h5>
                <div className="d-flex flex-wrap">
                  {job.skills.map(skill => (
                    <span key={skill.id} className="badge bg-secondary me-2 mb-2 p-2">
                      {skill.skill_name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Description Section */}
          {job.description && (
            <div className="card mb-2">
              <div className="card-body">
                <h5>Description</h5>
                <div className="bg-light p-3 rounded">
                  <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit' }}>{job.description}</pre>
                </div>
              </div>
            </div>
          )}
          
          {/* Requirements Section */}
          {job.requirements && (
            <div className="card mb-4">
              <div className="card-body">
                <h5>Requirements</h5>
                <div className="bg-light p-3 rounded">
                  <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit' }}>{job.requirements}</pre>
                </div>
              </div>
            </div>
          )}
          
          {/* Responsibilities Section */}
          {job.responsibilities && (
            <div className="card mb-4">
              <div className="card-body">
                <h5>Responsibilities</h5>
                <div className="bg-light p-3 rounded">
                  <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit' }}>{job.responsibilities}</pre>
                </div>
              </div>
            </div>
          )}
          
          {/* Application Section */}
          <div className="card mb-4">
            <div className="card-body">
              <h5>How to Apply</h5>
              {job.application_email && (
                <div className="mb-2">
                  <strong>Email:</strong> <a href={`mailto:${job.application_email}`}>{job.application_email}</a>
                </div>
              )}
              {job.application_cc_email && (
                <div className="mb-2">
                  <strong>CC Email:</strong> <a href={`mailto:${job.application_cc_email}`}>{job.application_cc_email}</a>
                </div>
              )}
              {job.application_url && (
                <div className="mb-2">
                  <strong>Application URL:</strong> <a href={job.application_url} target="_blank" rel="noopener noreferrer">Apply Online</a>
                </div>
              )}
              {job.application_type && (
                <div className="mb-2">
                  <strong>Application Type:</strong> {job.application_type.replace('APPLY_TO_', '').replace('_', ' ')}
                </div>
              )}
              
              <div className="mt-4">
                <Link to="/jobs" className="btn btn-secondary">
                  Back to Jobs
                </Link>
                {job.application_email && (
                  <a href={`mailto:${job.application_email}${job.application_cc_email ? `?cc=${job.application_cc_email}` : ''}&subject=Application for ${job.title} (${job.job_id})&body=I am interested in the ${job.title} position.`} 
                    className="btn btn-primary ms-2">
                    Apply Now
                  </a>
                )}
                {job.application_url && !job.application_email && (
                  <a href={job.application_url} target="_blank" rel="noopener noreferrer" className="btn btn-primary ms-2">
                    Apply Now
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Right Sidebar - Job History */}
        <div className="col-md-3">
          <div className="card mb-4 sticky-top" style={{ top: "20px" }}>
            <div className="card-header bg-secondary text-white">
              <h5 className="mb-0">Recent Activity</h5>
            </div>
            <div className="card-body">
              
              {/* Activity Tracking Section */}
              <div className="activity-tracking">
                
                {/* This would be populated from API data in the future */}
                <div className="timeline">
                  {/* Example marketer view activity */}
                  <div className="timeline-item mb-3">
                    <div className="timeline-marker bg-info"></div>
                    <div className="timeline-content">
                      <h6 className="mb-1">Viewed by Marketer</h6>
                      <p className="small text-muted mb-0">Jane Smith - 2 hours ago</p>
                    </div>
                  </div>
                  
                  {/* Example application activity */}
                  <div className="timeline-item mb-3">
                    <div className="timeline-marker bg-success"></div>
                    <div className="timeline-content">
                      <h6 className="mb-1">Application Submitted</h6>
                      <p className="small text-muted mb-0">For John Doe - 1 day ago</p>
                    </div>
                  </div>
                  
                  {/* Example status change activity */}
                  <div className="timeline-item mb-3">
                    <div className="timeline-marker bg-warning"></div>
                    <div className="timeline-content">
                      <h6 className="mb-1">Status Changed</h6>
                      <p className="small text-muted mb-0">Moved to Interview - 3 days ago</p>
                    </div>
                  </div>
                </div>
                
                {/* View all activities button */}
                <div className="text-center mt-3">
                  <button className="btn btn-sm btn-outline-secondary">
                    View All Activities
                  </button>
                </div>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDetail;