import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthProvider';

const Navbar = () => {
  const auth = useAuth();
  
  const handleLogin = () => {
    auth.signinRedirect();
  };
  
  const handleLogout = () => {
    auth.signoutRedirect();
  };
  
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">Job Portal</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            {auth.isAuthenticated && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/jobs">Jobs</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/recruiters">Recruiters</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/vendors">Vendors</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/analytics">Analytics</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/resume-tailor">Resume Tailor</Link>
                </li>
              </>
            )}
          </ul>
          
          <div className="d-flex">
            {auth.isAuthenticated ? (
              <div className="d-flex align-items-center">
                <span className="text-light me-3">
                  Hello, {auth.userProfile?.given_name || auth.userProfile?.name || 'User'}
                </span>
                <div className="dropdown">
                  <button className="btn btn-outline-light dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    Logout
                  </button>
                  <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><Link className="dropdown-item" to="/profile">Profile</Link></li>
                    <li><hr className="dropdown-divider" /></li>
                    <li><button className="dropdown-item" onClick={handleLogout}>Logout</button></li>
                  </ul>
                </div>
              </div>
            ) : (
              <button className="btn btn-outline-light" onClick={handleLogin}>Login</button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
