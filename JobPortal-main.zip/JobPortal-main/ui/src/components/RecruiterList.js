import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getRecruiters, getVendors } from '../services/api';

const RecruiterList = () => {
  const navigate = useNavigate();
  const [recruiters, setRecruiters] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVendor, setSelectedVendor] = useState('');
  
  // Add sorting state
  const [sortBy, setSortBy] = useState('name'); // Default sort by name
  const [sortOrder, setSortOrder] = useState('asc'); // Default sort order

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch recruiters and vendors in parallel
        // Pass sorting params if backend supports it, otherwise sort client-side
        const [recruitersData, vendorsData] = await Promise.all([
          getRecruiters({ sort: sortBy, order: sortOrder }), // Pass sorting params
          getVendors()
        ]);
        
        setRecruiters(recruitersData);
        setVendors(vendorsData);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch data. Please try again later.');
        setLoading(false);
      }
    };
    
    fetchData();
  }, [sortBy, sortOrder]); // Re-fetch when sorting changes
  
  // Updated to use internal ID instead of recruiter_id
  const handleRecruiterClick = (recruiterId) => {
    navigate(`/recruiters/${recruiterId}`);
  };

  // Handle sorting click
  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc'); // Default to ascending when changing field
    }
  };
  
  // Filter recruiters based on search term and selected vendor
  const filteredRecruiters = recruiters.filter(recruiter => {
    const nameMatch = recruiter.name || ''; // Handle potential null names
    const matchesSearch = nameMatch.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesVendor = selectedVendor === '' || 
      recruiter.vendor_id === parseInt(selectedVendor);
    
    return matchesSearch && matchesVendor;
  });

  // Client-side sorting (if backend doesn't sort)
  // Note: If backend handles sorting, this part can be removed.
  const sortedRecruiters = [...filteredRecruiters].sort((a, b) => {
    let valueA, valueB;

    if (sortBy === 'total_jobs') {
      valueA = a.total_jobs || 0;
      valueB = b.total_jobs || 0;
    } else { // Default to sorting by name
      valueA = (a.name || '').toLowerCase();
      valueB = (b.name || '').toLowerCase();
    }

    if (valueA < valueB) {
      return sortOrder === 'asc' ? -1 : 1;
    }
    if (valueA > valueB) {
      return sortOrder === 'asc' ? 1 : -1;
    }
    return 0;
  });
  
  // Get vendor name by ID
  // const getVendorName = (vendorId) => {
  //   const vendor = vendors.find(v => v.id === vendorId);
  //   return vendor ? vendor.name : 'Unknown Vendor';
  // };
  
  return (
    <div className="p-5">
      <h2>Recruiters</h2>
      
      <div className="search-container mb-4">
        <div className="row">
          <div className="col-md-6">
            <div className="input-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Search recruiters..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <button className="btn btn-primary" type="button">
                Search
              </button>
            </div>
          </div>
          
          <div className="col-md-6">
            <select
              className="form-select"
              value={selectedVendor}
              onChange={(e) => setSelectedVendor(e.target.value)}
            >
              <option value="">All Vendors</option>
              {vendors.map(vendor => (
                <option key={vendor.id} value={vendor.id}>
                  {vendor.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : error ? (
        <div className="alert alert-danger">{error}</div>
      ) : sortedRecruiters.length === 0 ? (
        <div className="alert alert-info">No recruiters found matching your search.</div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover">
            <thead>
              <tr>
                <th onClick={() => handleSort('name')} style={{ cursor: 'pointer' }}>
                  Name {sortBy === 'name' && (sortOrder === 'asc' ? '▲' : '▼')}
                </th>
                <th>Vendor</th>
                <th onClick={() => handleSort('total_jobs')} style={{ cursor: 'pointer' }}>
                  Total Jobs {sortBy === 'total_jobs' && (sortOrder === 'asc' ? '▲' : '▼')}
                </th>
                <th>Location</th>
                <th>Contact</th>
                {/* Add new column for source */}
                <th>Source</th>
                {/* Add new column for external link */}
                <th>External Link</th>
              </tr>
            </thead>
            <tbody>
              {sortedRecruiters.map((recruiter) => (
                <tr 
                  key={recruiter.id} 
                  onClick={() => handleRecruiterClick(recruiter.id)} 
                  style={{ cursor: 'pointer' }}
                >
                  <td>{recruiter.name || 'N/A'}</td>
                  <td>{recruiter.vendor_name || 'N/A'}</td>
                  <td>{recruiter.total_jobs !== undefined ? recruiter.total_jobs : 0}</td>
                  <td>{recruiter.work_location || 'N/A'}</td>
                  <td>
                    {recruiter.email && (
                      <a 
                        href={`mailto:${recruiter.email}`} 
                        onClick={(e) => e.stopPropagation()}
                      >
                        {recruiter.email}
                      </a>
                    )}
                    {recruiter.email && recruiter.phone && <br />}
                    {recruiter.phone}
                  </td>
                  {/* Add source column */}
                  <td>{recruiter.source || 'N/A'}</td>
                  {/* Add external URL column */}
                  <td>
                    {recruiter.external_url && (
                      <a 
                        href={recruiter.external_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()} // Prevent row click when clicking the link
                        className="btn btn-sm btn-outline-primary"
                      >
                        View Profile
                      </a>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RecruiterList;