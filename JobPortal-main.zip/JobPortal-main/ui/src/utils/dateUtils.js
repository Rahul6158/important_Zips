/**
 * Format a date string to show relative time (hours ago) or actual date
 * @param {string} dateString - ISO date string (e.g. "2025-04-28T17:41:07")
 * @returns {string} Formatted date string
 */
export const formatRelativeDate = (dateString) => {
  if (!dateString) return '';
  
  const date = new Date(dateString);
  const now = new Date();
  
  // Calculate the difference in hours
  const diffMs = now - date;
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  
  if (diffHours < 24) {
    // Less than 24 hours, show hours ago
    return diffHours === 0 
      ? 'Just now' 
      : diffHours === 1 
        ? '1 hour ago' 
        : `${diffHours} hours ago`;
  } else if (diffHours < 48) {
    // Less than 48 hours, show "Yesterday"
    return 'Yesterday';
  } else {
    // More than 48 hours, show the date
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  }
};