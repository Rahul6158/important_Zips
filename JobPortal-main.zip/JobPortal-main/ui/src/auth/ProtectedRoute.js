import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './AuthProvider';
import { Box, CircularProgress, Typography } from '@mui/material';

const ProtectedRoute = ({ requiredRoles = [] }) => {
  const auth = useAuth();
  
  // Show loading state while OIDC is initializing
  if (auth.isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
        <Typography variant="body1" sx={{ ml: 2 }}>
          Authenticating...
        </Typography>
      </Box>
    );
  }
  
  // Redirect to home if not authenticated
  if (!auth.isAuthenticated) {
    return <Navigate to="/" />;
  }
  
  // Check for required roles if specified
  if (requiredRoles.length > 0) {
    const hasRequiredRole = requiredRoles.some(role => 
      auth.userRoles.includes(role)
    );
    
    if (!hasRequiredRole) {
      return <Navigate to="/unauthorized" />;
    }
  }
  
  // Render child routes
  return <Outlet />;
};

export default ProtectedRoute;