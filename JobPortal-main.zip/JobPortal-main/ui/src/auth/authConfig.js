// OIDC Configuration
export const oidcConfig = {
  authority: process.env.REACT_APP_OIDC_AUTHORITY,
  client_id: process.env.REACT_APP_OIDC_CLIENT_ID,
  client_secret: process.env.REACT_APP_OIDC_CLIENT_SECRET,
  redirect_uri: window.location.origin,
  post_logout_redirect_uri: window.location.origin,
  response_type: 'code',
  scope: 'openid profile email',
  automaticSilentRenew: true,
  loadUserInfo: true,
  // Add these settings to fix immediate logout issue
  silentRequestTimeout: 10000,
  monitorSession: false, // Disable session monitoring which can cause logout issues
  // Add onSigninCallback to handle redirect after login
  onSigninCallback: (user) => {
    window.history.replaceState({}, document.title, window.location.pathname);
  }
};

// Helper function to get tokens for API requests
export const getAuthHeaders = (user) => {
  if (!user || !user.access_token) {
    return {};
  }
  
  return {
    Authorization: `Bearer ${user.access_token}`,
  };
};

// Helper to check if user has a specific role
export const hasRole = (user, roleName) => {
  if (!user || !user.profile) return false;
  
  // Check resource_access for client roles
  const resourceAccess = user.profile.resource_access;
  if (resourceAccess && resourceAccess[oidcConfig.client_id]) {
    const clientRoles = resourceAccess[oidcConfig.client_id].roles || [];
    if (clientRoles.includes(roleName)) return true;
  }
  
  // Check realm roles
  const realmRoles = user.profile.realm_access?.roles || [];
  return realmRoles.includes(roleName);
};