import React, { createContext, useContext, useEffect, useState } from 'react';
import { AuthProvider as OidcProvider, useAuth as useOidcAuth } from 'react-oidc-context';
import { oidcConfig } from './authConfig';
import axios from 'axios';
import { API_URL } from '../services/api';
import { useNavigate } from 'react-router-dom';

// Create context
const AuthContext = createContext(null);

// Custom hook to use auth context
export const useAuth = () => useContext(AuthContext);

// Auth provider component
export const AuthProvider = ({ children }) => {
  return (
    <OidcProvider {...oidcConfig}>
      <AuthContextProvider>{children}</AuthContextProvider>
    </OidcProvider>
  );
};

// Internal provider that uses the OIDC auth
const AuthContextProvider = ({ children }) => {
  const auth = useOidcAuth();
  const [isValidated, setIsValidated] = useState(false);
  const [validationError, setValidationError] = useState(null);
  const navigate = useNavigate();
  
  // Handle successful login - only redirect to /jobs if coming from login
  useEffect(() => {
    if (auth.isAuthenticated && auth.user && !auth.isLoading && auth.activeNavigator === 'signinRedirect') {
      navigate('/jobs');
    }
  }, [auth.isAuthenticated, auth.user, auth.isLoading, auth.activeNavigator, navigate]);
  
  // Validate token with backend when user is authenticated
  useEffect(() => {
    const validateToken = async () => {
      if (auth.isAuthenticated && auth.user) {
        try {
          // Comment out token validation for now since backend might not be ready
          // Uncomment when backend is ready
          
          await axios.post(
            `${API_URL}/auth/validate-token`,
            {},
            {
              headers: {
                Authorization: `Bearer ${auth.user.access_token}`,
              },
            }
          );
          
          
          setIsValidated(true);
          setValidationError(null);
        } catch (error) {
          console.error('Token validation failed:', error);
          setIsValidated(false);
          setValidationError('Your authentication token is invalid or expired');
          
          // Sign out if token is invalid
          auth.signoutRedirect();
        }
      } else {
        setIsValidated(false);
        setValidationError(null);
      }
    };
    
    if (auth.isAuthenticated && auth.user) {
      validateToken();
    }
  }, [auth.isAuthenticated, auth.user, auth]);
  
  // Add auth headers to all axios requests
  useEffect(() => {
    const requestInterceptor = axios.interceptors.request.use((config) => {
      if (auth.isAuthenticated && auth.user) {
        config.headers.Authorization = `Bearer ${auth.user.access_token}`;
      }
      return config;
    });
    
    return () => {
      axios.interceptors.request.eject(requestInterceptor);
    };
  }, [auth.isAuthenticated, auth.user, auth]);
  
  // Enhanced auth context with additional properties
  const authContext = {
    ...auth,
    isValidated,
    validationError,
    userProfile: auth.user?.profile || null,
    userRoles: getUserRoles(auth.user),
  };
  
  return (
    <AuthContext.Provider value={authContext}>
      {children}
    </AuthContext.Provider>
  );
};

// Helper function to extract user roles
const getUserRoles = (user) => {
  if (!user || !user.profile) return [];
  
  const roles = [];
  
  // Get realm roles
  const realmRoles = user.profile.realm_access?.roles || [];
  roles.push(...realmRoles);
  
  // Get client roles
  const clientId = oidcConfig.client_id;
  const clientRoles = user.profile.resource_access?.[clientId]?.roles || [];
  roles.push(...clientRoles);
  
  return [...new Set(roles)]; // Remove duplicates
};