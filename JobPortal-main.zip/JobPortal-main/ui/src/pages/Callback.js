import React, { useEffect } from 'react';
import { useAuth } from '../auth/AuthProvider';
import { useNavigate } from 'react-router-dom';
import { Box, CircularProgress, Typography } from '@mui/material';

const Callback = () => {
  const auth = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // If authentication is complete, redirect to jobs page
    if (auth.isAuthenticated && !auth.isLoading) {
      navigate('/jobs');
    }
  }, [auth.isAuthenticated, auth.isLoading, navigate]);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
      <CircularProgress size={60} />
      <Typography variant="h6" sx={{ mt: 2 }}>
        Completing login...
      </Typography>
    </Box>
  );
};

export default Callback;