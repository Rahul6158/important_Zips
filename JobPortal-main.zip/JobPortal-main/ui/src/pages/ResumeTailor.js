import React, { useState } from 'react';
import { 
  Box, 
  Button, 
  Container, 
  TextField, 
  Typography, 
  Paper, 
  CircularProgress,
  Alert,
  Stack
} from '@mui/material';
import { styled } from '@mui/material/styles';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import DownloadIcon from '@mui/icons-material/Download';
import { tailorResume } from '../services/api';

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

const ResumeTailor = () => {
  const [file, setFile] = useState(null);
  const [jobDescription, setJobDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState('');

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && selectedFile.name.endsWith('.docx')) {
      setFile(selectedFile);
      setError('');
    } else {
      setFile(null);
      setError('Please upload a .docx file');
    }
  };

  const handleJobDescriptionChange = (event) => {
    setJobDescription(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    
    if (!file) {
      setError('Please upload a resume file');
      return;
    }
    
    if (!jobDescription.trim()) {
      setError('Please enter a job description');
      return;
    }
    
    setLoading(true);
    setError('');
    setSuccess(false);
    
    try {
      const blobData = await tailorResume(file, jobDescription);
      const url = window.URL.createObjectURL(blobData);
      
      setDownloadUrl(url);
      setSuccess(true);
    } catch (err) {
      setError(err.message || 'An error occurred while tailoring your resume');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Resume Tailor
        </Typography>
        <Typography variant="body1" paragraph align="center">
          Upload your resume and paste a job description to get a tailored version that highlights your relevant skills and experience.
        </Typography>
        
        {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ mb: 3 }}>Resume successfully tailored! Click the download button below.</Alert>}
        
        <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 3 }}>
          <Stack spacing={3}>
            <Box>
              <Typography variant="subtitle1" gutterBottom>
                Upload Resume (.docx only)
              </Typography>
              <Button
                component="label"
                variant="contained"
                startIcon={<CloudUploadIcon />}
                fullWidth
              >
                {file ? file.name : 'Upload Resume'}
                <VisuallyHiddenInput type="file" onChange={handleFileChange} accept=".docx" />
              </Button>
            </Box>
            
            <Box>
              <Typography variant="subtitle1" gutterBottom>
                Job Description
              </Typography>
              <TextField
                multiline
                rows={10}
                fullWidth
                placeholder="Paste the job description here..."
                value={jobDescription}
                onChange={handleJobDescriptionChange}
              />
            </Box>
            
            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                disabled={loading || !file || !jobDescription.trim()}
                sx={{ minWidth: 150 }}
              >
                {loading ? <CircularProgress size={24} /> : 'Tailor Resume'}
              </Button>
              
              {downloadUrl && (
                <Button
                  variant="contained"
                  color="success"
                  startIcon={<DownloadIcon />}
                  href={downloadUrl}
                  download="tailored_resume.docx"
                  sx={{ minWidth: 150 }}
                >
                  Download
                </Button>
              )}
            </Box>
          </Stack>
        </Box>
      </Paper>
    </Container>
  );
};

export default ResumeTailor;