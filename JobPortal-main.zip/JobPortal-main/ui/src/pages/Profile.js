import React, { useState, useEffect } from 'react';
import { useAuth } from '../auth';
import { Container, Row, Col, Card, Form, Button, Alert, Badge, ListGroup } from 'react-bootstrap';
import axios from 'axios';
import { uploadResume, updateUserSkills, getAllSkills } from '../services/api';

const Profile = () => {
  const auth = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({});
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [updateError, setUpdateError] = useState(null);
  const [resumeFile, setResumeFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadingResume, setUploadingResume] = useState(false);
  const [resumeUploadSuccess, setResumeUploadSuccess] = useState(false);
  const [resumeUploadError, setResumeUploadError] = useState(null);
  const [resumeStatus, setResumeStatus] = useState(''); // Added for resume status
  const [availableSkills, setAvailableSkills] = useState([]);
  const [selectedSkills, setSelectedSkills] = useState([]);
  const [skillSearchTerm, setSkillSearchTerm] = useState('');
  const [updatingSkills, setUpdatingSkills] = useState(false);
  const [skillsUpdateSuccess, setSkillsUpdateSuccess] = useState(false);
  const [skillsUpdateError, setSkillsUpdateError] = useState(null);
  const [smtpUpdateSuccess, setSmtpUpdateSuccess] = useState(false);
  const [smtpUpdateError, setSmtpUpdateError] = useState(null);

  // Check if user is a candidate
  const isCandidate = () => {
    if (!profile || !profile.roles) return false;
    
    // Check if roles is a string before splitting
    const roles = typeof profile.roles === 'string' 
      ? profile.roles.split(',') 
      : Array.isArray(profile.roles) ? profile.roles : [];
      
    return roles.includes('candidate');
  };

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        // Use auth.user.access_token instead of getAccessToken()
        const token = auth.user?.access_token;
        if (!token) {
          throw new Error('No access token available');
        }
        
        const response = await axios.get(`${process.env.REACT_APP_API_URL}/auth/profile`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        console.log('Profile data:', response.data); // Debug log to see what's coming from backend
        setProfile(response.data);
        setFormData(response.data);
        
        // Set selected skills from profile
        if (response.data.skills) {
          setSelectedSkills(response.data.skills.map(skill => skill.id));
        }
        
        // Set resume status based on profile data
        if (response.data.resume_url) {
          setResumeStatus('Uploaded');
        } else {
          setResumeStatus('Not Uploaded');
        }
        
        setLoading(false);
      } catch (err) {
        console.error('Error fetching profile:', err);
        setError('Failed to load profile data');
        setLoading(false);
      }
    };

    const fetchSkills = async () => {
      try {
        const skills = await getAllSkills();
        setAvailableSkills(skills);
      } catch (err) {
        console.error('Error fetching skills:', err);
      }
    };

    fetchProfile();
    fetchSkills();
  }, [auth.user]);

  // Filter skills based on search term
  const filteredSkills = availableSkills.filter(skill => 
    skill && skill.name && skill.name.toLowerCase().includes(skillSearchTerm.toLowerCase())
  );

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUpdateSuccess(false);
    setUpdateError(null);

    try {
      // Use auth.user.access_token instead of getAccessToken()
      const token = auth.user?.access_token;
      if (!token) {
        throw new Error('No access token available');
      }
      
      const response = await axios.put(
        `${process.env.REACT_APP_API_URL}/auth/profile`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      setProfile(response.data);
      setUpdateSuccess(true);
    } catch (err) {
      console.error('Error updating profile:', err);
      setUpdateError('Failed to update profile');
    }
  };

  const handleSmtpSubmit = async (e) => {
    e.preventDefault();
    setSmtpUpdateSuccess(false);
    setSmtpUpdateError(null);

    try {
      const token = auth.user?.access_token;
      if (!token) {
        throw new Error('No access token available');
      }
      
      const smtpData = {
        smtp_server: formData.smtp_server,
        smtp_port: formData.smtp_port,
        smtp_username: formData.smtp_username,
        smtp_password: formData.smtp_password,
        smtp_from_email: formData.smtp_from_email
      };
      
      const response = await axios.put(
        `${process.env.REACT_APP_API_URL}/auth/profile`,
        smtpData,
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      setProfile(response.data);
      setSmtpUpdateSuccess(true);
    } catch (err) {
      console.error('Error updating SMTP settings:', err);
      setSmtpUpdateError('Failed to update SMTP settings');
    }
  };

  const handleResumeChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Check file type
      const fileType = file.type;
      if (fileType !== 'application/pdf' && 
          fileType !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' && 
          fileType !== 'application/msword') {
        setResumeUploadError('Only PDF and Word documents are allowed');
        setResumeFile(null);
        return;
      }
      
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setResumeUploadError('File size should not exceed 5MB');
        setResumeFile(null);
        return;
      }
      
      setResumeFile(file);
      setResumeUploadError(null);
    }
  };

  const handleResumeUpload = async () => {
    if (!resumeFile) return;
    
    setUploadingResume(true);
    setResumeUploadSuccess(false);
    setResumeUploadError(null);
    setUploadProgress(0);
    
    try {
      const response = await uploadResume(resumeFile);
      
      // Update profile with new resume URL
      setProfile(prev => ({
        ...prev,
        resume_url: response.resume_url
      }));
      
      setResumeUploadSuccess(true);
      setResumeStatus('Uploaded'); // Update resume status
      setResumeFile(null);
    } catch (err) {
      console.error('Error uploading resume:', err);
      setResumeUploadError('Failed to upload resume');
      setResumeStatus('Upload Failed'); // Update resume status on failure
    } finally {
      setUploadingResume(false);
    }
  };

  const handleSkillSelect = (skillId) => {
    setSelectedSkills(prev => {
      if (prev.includes(skillId)) {
        return prev.filter(id => id !== skillId);
      } else {
        return [...prev, skillId];
      }
    });
    setSkillSearchTerm('');
  };

  const handleSkillsUpdate = async () => {
    setUpdatingSkills(true);
    setSkillsUpdateSuccess(false);
    setSkillsUpdateError(null);
    
    try {
      const response = await updateUserSkills(selectedSkills);
      
      // Update profile with new skills
      setProfile(prev => ({
        ...prev,
        skills: response.skills
      }));
      
      setSkillsUpdateSuccess(true);
    } catch (err) {
      console.error('Error updating skills:', err);
      setSkillsUpdateError('Failed to update skills');
    } finally {
      setUpdatingSkills(false);
    }
  };

  if (loading) return <div className="text-center mt-5">Loading profile...</div>;
  if (error) return <Alert variant="danger">{error}</Alert>;
  
  return (
    <Container className="mt-4">
      <h1 className="mb-4">User Profile</h1>
      
      {updateSuccess && (
        <Alert variant="success" dismissible onClose={() => setUpdateSuccess(false)}>
          Profile updated successfully!
        </Alert>
      )}
      
      {updateError && (
        <Alert variant="danger" dismissible onClose={() => setUpdateError(null)}>
          {updateError}
        </Alert>
      )}
      
      <Row>
        <Col md={4}>
          <Card className="mb-4">
            <Card.Body>
              <Card.Title>Account Information</Card.Title>
              <div className="mb-3">
                <strong>Email:</strong> {profile.email}
              </div>
              {profile.username && (
                <div className="mb-3">
                  <strong>Username:</strong> {profile.username}
                </div>
              )}
              <div className="mb-3">
                <strong>First Name:</strong> {profile.first_name || 'Not set'}
              </div>
              <div className="mb-3">
                <strong>Last Name:</strong> {profile.last_name || 'Not set'}
              </div>
              <div className="mb-3">
                <strong>Phone:</strong> {profile.phone_number || 'Not set'}
              </div>
              <div className="mb-3">
                <strong>Roles:</strong> {
                  profile.roles 
                    ? (typeof profile.roles === 'string' 
                        ? profile.roles.split(',').join(', ') 
                        : Array.isArray(profile.roles) 
                          ? profile.roles.join(', ') 
                          : '')
                    : ''
                }
              </div>
              <div className="mb-3">
                <strong>Account Status:</strong> {profile.is_active ? 'Active' : 'Inactive'}
              </div>
              <div className="mb-3">
                <strong>Last Login:</strong> {profile.last_login ? new Date(profile.last_login).toLocaleString() : 'Never'}
              </div>
              <div className="mb-3">
                <strong>Account Created:</strong> {new Date(profile.created_at).toLocaleString()}
              </div>
            </Card.Body>
          </Card>
          
          {isCandidate() && (
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Resume</Card.Title>
                
                {resumeUploadSuccess && (
                  <Alert variant="success" dismissible onClose={() => setResumeUploadSuccess(false)}>
                    Resume uploaded successfully!
                  </Alert>
                )}
                
                {resumeUploadError && (
                  <Alert variant="danger" dismissible onClose={() => setResumeUploadError(null)}>
                    {resumeUploadError}
                  </Alert>
                )}
                
                {resumeStatus === 'Uploaded' ? (
                  <Badge bg="success">Uploaded</Badge>
                ) : resumeStatus === 'Upload Failed' ? (
                  <Badge bg="danger">Upload Failed</Badge>
                ) : (
                  <Badge bg="warning">Not Uploaded</Badge>
                )}
                
                {profile.resume_url ? (
                  <div className="mb-3">
                    <p>Your resume is uploaded.</p>
                    <a 
                      href={profile.resume_url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="btn btn-outline-primary btn-sm"
                    >
                      Download Resume
                    </a>
                  </div>
                ) : (
                  <p className="text-muted">No resume uploaded yet.</p>
                )}
                
                <Form.Group className="mb-3">
                  <Form.Label>
                    {profile.resume_url ? "Replace current resume" : "Upload a resume"}
                  </Form.Label>
                  <Form.Control
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={handleResumeChange}
                  />
                  <Form.Text className="text-muted">
                    Accepted formats: PDF, DOC, DOCX. Max size: 5MB
                  </Form.Text>
                </Form.Group>
                
                {uploadingResume && (
                  <div className="mb-3">
                    <Form.Label>Upload Progress</Form.Label>
                    <div className="progress">
                      <div
                        className="progress-bar"
                        role="progressbar"
                        style={{ width: `${uploadProgress}%` }}
                        aria-valuenow={uploadProgress}
                        aria-valuemin="0"
                        aria-valuemax="100"
                      >
                        {uploadProgress}%
                      </div>
                    </div>
                  </div>
                )}
                
                <Button
                  variant="primary"
                  onClick={handleResumeUpload}
                  disabled={!resumeFile || uploadingResume}
                >
                  {uploadingResume ? 'Uploading...' : 'Upload Resume'}
                </Button>
              </Card.Body>
            </Card>
          )}
        </Col>
        
        <Col md={8}>
          <Card className="mb-4">
            <Card.Body>
              <Card.Title>Personal Information</Card.Title>
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>First Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="first_name"
                        value={formData.first_name || ''}
                        onChange={handleChange}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Last Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="last_name"
                        value={formData.last_name || ''}
                        onChange={handleChange}
                      />
                    </Form.Group>
                  </Col>
                </Row>
                
                <Form.Group className="mb-3">
                  <Form.Label>Phone Number</Form.Label>
                  <Form.Control
                    type="tel"
                    name="phone_number"
                    value={formData.phone_number || ''}
                    onChange={handleChange}
                  />
                </Form.Group>
                
                <Button type="submit" variant="primary">
                  Update Profile
                </Button>
              </Form>
            </Card.Body>
          </Card>
          
          {/* New SMTP Settings Card */}
          <Card className="mb-4">
            <Card.Header>
              <h5 className="mb-0">SMTP Settings</h5>
            </Card.Header>
            <Card.Body>
              {smtpUpdateSuccess && (
                <Alert variant="success" dismissible onClose={() => setSmtpUpdateSuccess(false)}>
                  SMTP settings updated successfully!
                </Alert>
              )}
              {smtpUpdateError && (
                <Alert variant="danger" dismissible onClose={() => setSmtpUpdateError(null)}>
                  {smtpUpdateError}
                </Alert>
              )}
              
              <Form onSubmit={handleSmtpSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>SMTP Server</Form.Label>
                  <Form.Control
                    type="text"
                    name="smtp_server"
                    value={formData.smtp_server || ''}
                    onChange={handleChange}
                    placeholder="e.g., smtp.gmail.com"
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>SMTP Port</Form.Label>
                  <Form.Control
                    type="number"
                    name="smtp_port"
                    value={formData.smtp_port || ''}
                    onChange={handleChange}
                    placeholder="e.g., 587"
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>SMTP Username</Form.Label>
                  <Form.Control
                    type="text"
                    name="smtp_username"
                    value={formData.smtp_username || ''}
                    onChange={handleChange}
                    placeholder="Your email address"
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>SMTP Password</Form.Label>
                  <Form.Control
                    type="password"
                    name="smtp_password"
                    value={formData.smtp_password || ''}
                    onChange={handleChange}
                    placeholder="Your email password or app password"
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>From Email</Form.Label>
                  <Form.Control
                    type="email"
                    name="smtp_from_email"
                    value={formData.smtp_from_email || ''}
                    onChange={handleChange}
                    placeholder="Email address to send from"
                  />
                </Form.Group>
                
                <Button type="submit" variant="primary">
                  Update SMTP Settings
                </Button>
              </Form>
            </Card.Body>
          </Card>
          
          {isCandidate() && (
            <Card className="mb-4">
              <Card.Header>
                <h5 className="mb-0">Skills</h5>
              </Card.Header>
              <Card.Body>
                {skillsUpdateSuccess && (
                  <Alert variant="success" dismissible onClose={() => setSkillsUpdateSuccess(false)}>
                    Skills updated successfully!
                  </Alert>
                )}
                {skillsUpdateError && (
                  <Alert variant="danger" dismissible onClose={() => setSkillsUpdateError(null)}>
                    {skillsUpdateError}
                  </Alert>
                )}
                
                <Form.Group className="mb-3">
                  <Form.Label>Search Skills</Form.Label>
                  <Form.Control 
                    type="text" 
                    placeholder="Search for skills..." 
                    value={skillSearchTerm}
                    onChange={(e) => setSkillSearchTerm(e.target.value)}
                  />
                </Form.Group>
                
                {skillSearchTerm && filteredSkills.length > 0 && (
                  <ListGroup className="mb-3">
                    {filteredSkills.slice(0, 5).map(skill => (
                      <ListGroup.Item 
                        key={skill.id}
                        action
                        onClick={() => handleSkillSelect(skill.id)}
                      >
                        {skill.name}
                      </ListGroup.Item>
                    ))}
                  </ListGroup>
                )}
                
                <div className="mb-3">
                  <Form.Label>Your Skills</Form.Label>
                  <div className="d-flex flex-wrap gap-2">
                    {selectedSkills.length > 0 ? (
                      availableSkills
                        .filter(skill => skill && skill.id && selectedSkills.includes(skill.id))
                        .map(skill => (
                          <Badge 
                            key={skill.id} 
                            bg="primary" 
                            className="p-2 mb-2 me-2"
                            style={{ cursor: 'pointer' }}
                            onClick={() => handleSkillSelect(skill.id)}
                          >
                            {skill.name} &times;
                          </Badge>
                        ))
                    ) : (
                      <p className="text-muted">No skills selected</p>
                    )}
                  </div>
                </div>
                
                <Button
                  variant="primary"
                  onClick={handleSkillsUpdate}
                  disabled={updatingSkills}
                >
                  {updatingSkills ? 'Updating...' : 'Update Skills'}
                </Button>
              </Card.Body>
            </Card>
          )}
        </Col>
      </Row>
    </Container>
  );
};

export default Profile;