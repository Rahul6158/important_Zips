# UI Build And Deployment

## Build

```bash
cd ui
npm install
npm run build
```

The build output is written to `ui/build/`.

## Container

`ui/Dockerfile` uses `nginx:alpine`, copies `nginx.conf`, copies `build/` to
`/usr/share/nginx/html`, exposes port `8081`, and starts Nginx.

`ui/nginx.conf` serves static files and falls back to `index.html` for SPA
routes:

```nginx
try_files $uri $uri/ /index.html;
```

## CI/CD

`ui/Jenkinsfile` defines build, Docker image build, release-branch image
publish, and release/Helm-values update stages through a shared library.

Production deployment target details are not yet documented in this repository.
