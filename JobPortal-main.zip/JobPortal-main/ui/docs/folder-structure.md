# UI Folder Structure

```text
ui/
├── docs/
├── src/
│   ├── auth/
│   ├── components/
│   ├── pages/
│   ├── services/
│   ├── utils/
│   ├── App.css
│   ├── App.js
│   ├── index.css
│   └── index.js
├── Dockerfile
├── Jenkinsfile
├── nginx.conf
└── package.json
```

## Source Areas

| Path | Purpose |
| --- | --- |
| `src/auth/` | OIDC configuration, auth context, route guards, role helpers. |
| `src/components/` | Home, navbar, job, recruiter, vendor, analytics, and sidebar components. |
| `src/pages/` | Callback, profile, unauthorized, and resume-tailor pages. |
| `src/services/api.js` | Axios API helper functions. |
| `src/utils/` | Shared utility helpers. |
