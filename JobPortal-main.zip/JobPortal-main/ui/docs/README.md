# UI Documentation

## Start Here

| Area | Description | Link |
| --- | --- | --- |
| Overview | Frontend purpose, stack, and workflows. | [overview.md](./overview.md) |
| Architecture | React app structure and auth/request flow. | [architecture.md](./architecture.md) |
| Local Development | Setup, run, and build commands. | [local-development.md](./local-development.md) |
| Folder Structure | Source directory map. | [folder-structure.md](./folder-structure.md) |
| Routing | Public, protected, and admin route definitions. | [routing.md](./routing.md) |
| Components | Major reusable views and pages. | [components.md](./components.md) |
| State Management | Auth context, local state, and server data. | [state-management.md](./state-management.md) |
| API Integration | Axios client and backend route usage. | [api-integration.md](./api-integration.md) |
| Configuration | Required `REACT_APP_*` variables. | [configuration.md](./configuration.md) |
| Testing | CRA tests and current coverage gaps. | [testing.md](./testing.md) |
| Build And Deployment | CRA build and Nginx container. | [build-and-deployment.md](./build-and-deployment.md) |
| Troubleshooting | Common browser/runtime issues. | [troubleshooting.md](./troubleshooting.md) |

## Runtime Summary

- Framework: React 18
- Build tool: Create React App / `react-scripts`
- Router: `react-router-dom`
- Auth: `react-oidc-context`
- HTTP client: Axios
- UI libraries: Bootstrap, React Bootstrap, Material UI, Chart.js
- Dev server: `npm start`
- Static runtime: Nginx on port `8081`
