# UI Overview

The UI provides browser workflows for:

- public home page,
- OIDC login/logout,
- protected job search and job detail views,
- recruiter and vendor lists/details,
- job analytics,
- profile read/update,
- resume upload and skill updates,
- resume tailoring against a job description.

## Stack

| Area | Source |
| --- | --- |
| React 18 | `package.json` |
| Routing | `react-router-dom`, `src/App.js` |
| Auth | `react-oidc-context`, `src/auth/` |
| HTTP | `axios`, `src/services/api.js` |
| Styling | Bootstrap, React Bootstrap, Material UI, app CSS |
| Charts | Chart.js and `react-chartjs-2` |

The UI expects the API base URL to include `/api`.
