# API Integration

`ui/src/services/api.js` sets:

```javascript
export const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';
```

Most API calls are centralized in that file. `Profile.js` also makes direct
Axios calls to auth profile routes.

## API Helpers

| Helper | Backend Route |
| --- | --- |
| `getJobs` | `GET /api/jobs/all` |
| `getJobById` | `GET /api/jobs/{job_id}` |
| `getVendors` | `GET /api/vendors/all` |
| `getVendorById` | `GET /api/vendors/{id}` |
| `getRecruiters` | `GET /api/recruiters/all` |
| `getRecruiterById` | `GET /api/recruiters/{id}` |
| `getJobStatsBySkill` | `GET /api/analytics/skills` |
| `getJobStatsByLocation` | `GET /api/analytics/locations` |
| `getUniqueLocations` | `GET /api/analytics/locations/all` |
| `getUniqueSkills` / `getAllSkills` | `GET /api/analytics/skills/all` |
| `tailorResume` | `POST /api/tailor/tailor-resume` |
| `validateToken` | `POST /api/auth/validate-token` |
| `uploadResume` | `POST /api/profile/upload-resume` |
| `updateUserSkills` | `POST /api/profile/update-skills` |
| `extractSkillsFromResume` | `POST /api/profile/extract-skills` |

## Known Contract Gap

`getJobByInternalId` calls `/api/jobs/internal/{internalId}`, but the backend
does not currently expose that path. Use `/api/jobs/{job_id}` with a numeric ID
until the contract is aligned.
