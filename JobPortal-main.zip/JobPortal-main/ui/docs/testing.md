# UI Testing

## Commands

```bash
cd ui
npm test -- --watchAll=false
npm run build
```

The repository includes Create React App testing dependencies in
`package.json`. Dedicated UI test files are not currently visible under
`ui/src/`.

## Recommended Tests

- Route guard behavior for authenticated, unauthenticated, and unauthorized
  users.
- OIDC callback handling.
- Job search filter interactions.
- Vendor, recruiter, and job detail data loading.
- Analytics loading and empty states.
- Profile update and resume-upload progress.
- Resume-tailor submission and file-download behavior.
- Contract coverage for every helper in `src/services/api.js`.
