# UI Configuration

Environment variables are read from Create React App `REACT_APP_*` values.

| Name | Required | Purpose |
| --- | --- | --- |
| `REACT_APP_API_URL` | yes | Backend API base URL, expected to include `/api`. |
| `REACT_APP_OIDC_AUTHORITY` | yes for auth flows | OIDC authority. |
| `REACT_APP_OIDC_CLIENT_ID` | yes for auth flows | OIDC client ID. |
| `REACT_APP_OIDC_CLIENT_SECRET` | repository-visible, risk to review | OIDC client secret value referenced by frontend code. |

Local example:

```text
REACT_APP_API_URL=http://localhost:8000/api
REACT_APP_OIDC_AUTHORITY=<oidc-authority>
REACT_APP_OIDC_CLIENT_ID=<oidc-client-id>
REACT_APP_OIDC_CLIENT_SECRET=<oidc-client-secret>
```

Do not commit real secrets. Browser-delivered client secrets should be reviewed
before production use.
