# State Management

The UI does not use Redux, Zustand, or another global state store.

## Auth State

Authentication state comes from `react-oidc-context` and is wrapped by
`src/auth/AuthProvider.js`. The custom context exposes:

- OIDC auth state,
- `isValidated`,
- `validationError`,
- `userProfile`,
- `userRoles`.

## Server State

Server data is fetched through Axios helper functions in `src/services/api.js`
and stored in component/page-local React state.

## Request State

Axios receives a request interceptor in `AuthProvider` that attaches the bearer
token when the user is authenticated.

## Persistence

OIDC library persistence behavior is handled by `react-oidc-context`. No custom
localStorage/sessionStorage persistence is visible in repository source.
