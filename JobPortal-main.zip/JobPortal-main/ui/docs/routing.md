# Routing

Routes are defined in `ui/src/App.js`.

## Public Routes

| Path | Component |
| --- | --- |
| `/` | `Home` |
| `/unauthorized` | `Unauthorized` |
| `/callback` | `Callback` |
| `/jobs/:jobId` | `JobDetail` |

## Protected Routes

These routes require an authenticated user through `ProtectedRoute`.

| Path | Component |
| --- | --- |
| `/jobs` | `JobSearch` |
| `/recruiters` | `RecruiterList` |
| `/recruiters/:recruiterId` | `RecruiterDetail` |
| `/vendors` | `VendorList` |
| `/vendors/:vendorId` | `VendorDetail` |
| `/analytics` | `JobAnalytics` |
| `/resume-tailor` | `ResumeTailor` |
| `/profile` | `Profile` |

## Admin Routes

`App.js` contains an admin route guard placeholder with
`requiredRoles={['admin']}`, but no concrete admin child routes are currently
defined.

## Fallback

Unknown routes redirect to `/`.
