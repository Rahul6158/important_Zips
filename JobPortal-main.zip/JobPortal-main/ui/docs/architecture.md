# UI Architecture

```mermaid
flowchart TD
  Index[src/index.js] --> App[src/App.js]
  App --> AuthProvider[src/auth/AuthProvider.js]
  App --> Routes[React Router routes]
  Routes --> Components[src/components/*]
  Routes --> Pages[src/pages/*]
  AuthProvider --> Axios[Axios interceptor]
  Components --> ApiClient[src/services/api.js]
  Pages --> ApiClient
  ApiClient --> API[FastAPI /api]
```

## Main Pieces

| Piece | File | Responsibility |
| --- | --- | --- |
| App shell | `src/App.js` | Router, route protection, navbar, layout container. |
| Auth provider | `src/auth/AuthProvider.js` | OIDC provider wrapper, token validation, auth context, Axios interceptor. |
| Route guard | `src/auth/ProtectedRoute.js` | Authenticated and role-gated route rendering. |
| API client | `src/services/api.js` | Backend route helpers. |
| Navbar | `src/components/Navbar.js` | Navigation and login/logout controls. |
| Product views | `src/components/`, `src/pages/` | Job, vendor, recruiter, analytics, profile, and resume-tailor workflows. |

## Request Flow

1. User signs in through the OIDC provider.
2. `AuthProvider` validates the token through `/api/auth/validate-token`.
3. Axios requests receive an `Authorization` header when the user is
   authenticated.
4. Components and pages call helpers in `src/services/api.js`.
5. Backend responses update component-local state.
