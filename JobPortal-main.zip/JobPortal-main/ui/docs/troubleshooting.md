# UI Troubleshooting

## API Calls Fail

- Confirm `REACT_APP_API_URL` includes `/api`.
- Confirm the backend is running and `/health/live` returns healthy.
- Confirm CORS allows the UI origin.

## Protected Routes Redirect To Home

- Confirm OIDC variables are set.
- Confirm the user is authenticated.
- Confirm `POST /api/auth/validate-token` succeeds.
- Check browser console for token validation errors.

## Login Immediately Logs Out

`authConfig.js` disables session monitoring with `monitorSession: false`.
Confirm the OIDC authority, client ID, redirect URI, and callback route match
the identity-provider client configuration.

## Build Fails

Run:

```bash
npm install
npm run build
```

If build errors reference environment variables, confirm all required
`REACT_APP_*` variables are available at build time.

## Job Internal ID Lookup Fails

The UI helper `getJobByInternalId` references a backend path that is not
currently exposed. Use `getJobById` or align the backend route contract.
