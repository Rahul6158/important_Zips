# UI Local Development

## Setup

```bash
cd ui
npm install
```

Create `ui/.env` when local configuration is needed:

```text
REACT_APP_API_URL=http://localhost:8000/api
REACT_APP_OIDC_AUTHORITY=<oidc-authority>
REACT_APP_OIDC_CLIENT_ID=<oidc-client-id>
REACT_APP_OIDC_CLIENT_SECRET=<oidc-client-secret>
```

## Run

```bash
npm start
```

The development server starts on `http://localhost:3000`.

## Build

```bash
npm run build
```

The production static output is written to `ui/build/`.

## Test

```bash
npm test -- --watchAll=false
```
