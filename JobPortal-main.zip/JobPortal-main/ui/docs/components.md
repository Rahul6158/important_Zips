# Components And Pages

## Components

| Component | Purpose |
| --- | --- |
| `Home` | Public landing/home route. |
| `Navbar` | Navigation, login/logout, profile menu. |
| `JobSearch` | Protected job list/search workflow. |
| `JobDetail` | Job detail page for `/jobs/:jobId`. |
| `VendorList` / `VendorDetail` | Vendor browsing workflows. |
| `RecruiterList` / `RecruiterDetail` | Recruiter browsing workflows. |
| `JobAnalytics` | Skill and location analytics views. |
| `Sidebar` | Sidebar component available for layout usage. |

## Pages

| Page | Purpose |
| --- | --- |
| `Callback` | OIDC callback route. |
| `Profile` | Profile read/update and resume-related actions. |
| `ResumeTailor` | Resume tailoring upload/submission workflow. |
| `Unauthorized` | Role/access failure screen. |

## Auth Components

| File | Purpose |
| --- | --- |
| `auth/AuthProvider.js` | OIDC provider wrapper and app auth context. |
| `auth/ProtectedRoute.js` | Authenticated/role-gated route outlet. |
| `auth/authConfig.js` | OIDC settings and role helper. |
