# Glossary

| Term | Meaning |
| --- | --- |
| Candidate | A user role allowed to upload resumes and run resume-skill workflows. |
| Dice | Job source scraped by backend modules under `api/app/scrapers/dice/`. |
| Job | A stored job listing with title, description, skills, recruiter, vendor, location, and application metadata. |
| JobPortal API | FastAPI service under `api/`. |
| JobPortal UI | React application under `ui/`. |
| Recruiter | A contact associated with job records and optionally a vendor. |
| Resume tailoring | Backend flow that rewrites an uploaded `.docx` resume against a job description and returns a generated `.docx`. |
| Scraper | Background or manual Dice collection path using Selenium/Chromium dependencies. |
| Skill | Job skill entry used for analytics, filtering, and user profile workflows. |
| Vendor | Organization associated with recruiters and jobs. |
| OIDC | OpenID Connect configuration used by the frontend and backend bearer-token paths. |
