# Features

## User-Facing Features

| Feature | Source Evidence | Notes |
| --- | --- | --- |
| Public home page | `ui/src/components/Home.js`, `ui/src/App.js` | Entry route at `/`. |
| OIDC sign-in and sign-out | `ui/src/auth/`, `api/app/middleware/auth.py` | Uses `react-oidc-context` in the browser and bearer-token checks in the API. |
| Job search and filtering | `ui/src/components/JobSearch.js`, `api/app/api/routes/jobs.py` | Supports query, location, employment type, location type, skill, rate, term, recruiter, vendor, status, sort, order, and date filters. |
| Job detail view | `ui/src/components/JobDetail.js`, `api/app/api/routes/jobs.py` | Uses `/api/jobs/{job_id}`. |
| Vendor browsing | `ui/src/components/VendorList.js`, `ui/src/components/VendorDetail.js`, `api/app/api/routes/vendors.py` | Includes aggregate vendor stats through `VendorWithStats`. |
| Recruiter browsing | `ui/src/components/RecruiterList.js`, `ui/src/components/RecruiterDetail.js`, `api/app/api/routes/recruiters.py` | Includes recruiter job counts. |
| Analytics | `ui/src/components/JobAnalytics.js`, `api/app/api/routes/analytics.py` | Aggregates by skills and locations. |
| Profile management | `ui/src/pages/Profile.js`, `api/app/api/routes/auth.py`, `api/app/api/routes/profile.py` | Supports profile reads/updates, resume upload, skill updates, and resume status. |
| Resume tailoring | `ui/src/pages/ResumeTailor.jsx`, `api/app/api/routes/tailor.py` | Accepts `.docx` resumes and job descriptions; returns a tailored `.docx`. |

## Operational Features

| Feature | Source Evidence | Notes |
| --- | --- | --- |
| Liveness health | `api/app/main.py`, `api/tests/integration/test_health.py` | `GET /health/live` and legacy `GET /api/health`. |
| Readiness health | `api/app/main.py` | `GET /health/ready` checks database connectivity. |
| API container | `api/Dockerfile` | Python 3.11 slim image with Chromium and ChromeDriver for scraping. |
| UI container | `ui/Dockerfile`, `ui/nginx.conf` | Nginx image serving the React build on port `8081`. |
| CI pipeline definitions | `api/Jenkinsfile`, `ui/Jenkinsfile` | Builds Docker images and release metadata on the configured release branch. Sensitive webhook details are not duplicated in docs. |
| Graph artifacts | `graphify-out/` | Generated graph and HTML views for repository exploration. |

## Known Product Gaps

- Production support ownership is not yet documented in repository.
- User-role policy beyond `admin` and `candidate` checks is not yet documented
  in repository.
- The UI service helper references `/api/jobs/internal/{id}`, but the backend
  does not expose that exact route. The backend currently accepts numeric IDs
  through `/api/jobs/{job_id}`.
