# Product Overview

JobPortal is a job-search and career-management application. It combines a
React frontend with a FastAPI backend that stores job, vendor, recruiter, user,
skill, and resume metadata.

## Intended Audience

| Audience | What they use |
| --- | --- |
| Candidates | Job search, profile management, resume upload, skill selection, and resume tailoring. |
| Recruiter/vendor reviewers | Recruiter and vendor browsing pages. |
| Operators | Health checks, scraper controls, configuration, and deployment assets. |
| Developers and agents | Source-backed docs, API/UI maps, local setup, and validation commands. |

## Source-Backed Capabilities

- Browse jobs from `GET /api/jobs/all`.
- Open job detail pages through `GET /api/jobs/{job_id}`.
- Browse vendors and recruiters from `/api/vendors/*` and `/api/recruiters/*`.
- View job analytics by skill and location from `/api/analytics/*`.
- Validate OIDC bearer tokens and create/update user records.
- Upload resumes to S3-compatible storage from the profile workflow.
- Tailor `.docx` resumes through a CrewAI and OpenAI-backed backend flow.
- Run scheduled or manual Dice scraping when scraper configuration is enabled.

## Product Boundaries

The repository shows the application code and service deployment assets. It does
not document production hostnames, production data ownership, support process,
or user onboarding policy beyond what is visible in source.

Unknowns are intentionally marked as `TBD` or `Not yet documented in
repository` in the operations pages.
