# User Journeys

## Sign In

1. The user lands on `/`.
2. The navbar starts the OIDC redirect through `react-oidc-context`.
3. After the identity provider returns, the frontend validates the access token
   against `POST /api/auth/validate-token`.
4. The backend creates or updates the user record by email.
5. Protected routes become available when the user is authenticated.

## Search Jobs

1. The user opens `/jobs`.
2. The UI calls `GET /api/jobs/all` through `ui/src/services/api.js`.
3. Query parameters filter by search term, location, employment type, location
   type, skill, multiple skills, rate, term, recruiter, vendor, status, sort,
   order, and posting-date filter.
4. Selecting a job opens `/jobs/:jobId`, backed by `GET /api/jobs/{job_id}`.

## Review Vendors And Recruiters

1. The user opens `/vendors` or `/recruiters`.
2. The UI calls `/api/vendors/all` or `/api/recruiters/all`.
3. Detail pages call `/api/vendors/{vendor_id}` or
   `/api/recruiters/{recruiter_id}`.
4. Backend service methods include aggregate job counts where route schemas
   expose them.

## View Analytics

1. The user opens `/analytics`.
2. The UI requests skill and location aggregates from `/api/analytics/skills`
   and `/api/analytics/locations`.
3. Chart components render counts from the current database contents.

## Manage Profile And Resume

1. The user opens `/profile`.
2. The UI reads and updates profile data through `/api/auth/profile`.
3. Resume upload calls `POST /api/profile/upload-resume`.
4. Candidate role checks happen in the backend before S3 upload.
5. Resume status is available from `GET /api/profile/resume-status`.

## Tailor A Resume

1. The user opens `/resume-tailor`.
2. The user uploads a `.docx` resume and provides a target job description.
3. The UI posts multipart form data to `/api/tailor/tailor-resume`.
4. The backend reads the document, formats `api/app/tailor/resume_tailoring_prompt.txt`,
   calls the configured LLM path, and returns `tailored_resume.docx`.

## Operate The Scraper

Manual scraper routes exist under `/api/scrape-jobs`. Scheduled collection is
disabled by default through `SCRAPER_ENABLED=false` and must be explicitly
enabled by environment configuration.
