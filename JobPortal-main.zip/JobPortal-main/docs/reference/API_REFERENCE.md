# JobPortal API Reference

The backend is a FastAPI application. Route groups are assembled in `api/app/api/api.py` and mounted under `/api`.

## System

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api` | API welcome and version payload. |
| `GET` | `/api/health` | Health check response. |

## Auth

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/api/auth/validate-token` | Validate a bearer token and return the current user profile. |
| `GET` | `/api/auth/profile` | Return the current authenticated user profile. |
| `PUT` | `/api/auth/profile` | Update the current authenticated user profile. |

## Jobs

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api/jobs/all` | List jobs with optional query parameters. |
| `GET` | `/api/jobs/{job_id}` | Fetch a single job by id. |

## Vendors and Recruiters

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api/vendors/all` | List vendors with aggregate stats. |
| `GET` | `/api/vendors/{vendor_id}` | Fetch a vendor by id. |
| `GET` | `/api/vendors/internal/{internal_id}` | Fetch a vendor by internal id. |
| `GET` | `/api/recruiters/all` | List recruiters. |
| `GET` | `/api/recruiters/{recruiter_id}` | Fetch a recruiter by id. |
| `GET` | `/api/recruiters/internal/{internal_id}` | Fetch a recruiter by internal id. |

## Analytics

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api/analytics/test` | Analytics route smoke response. |
| `GET` | `/api/analytics/skills` | Aggregate jobs by skill. |
| `GET` | `/api/analytics/locations` | Aggregate jobs by location. |
| `GET` | `/api/analytics/skills/all` | List unique skill names. |
| `GET` | `/api/analytics/locations/all` | List unique location names. |

## Profile

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/api/profile/upload-resume` | Upload a resume for the current user. |
| `POST` | `/api/profile/update-skills` | Update selected skills for the current user. |
| `POST` | `/api/profile/extract-skills` | Extract skill matches from a resume URL. |
| `GET` | `/api/profile/resume-status` | Return resume upload/status metadata for the current user. |

## Resume Tailoring

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/api/tailor/tailor-resume` | Upload a `.docx` resume and job description, then return a tailored `.docx` file. |

## Scraper

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/api/scrape-jobs/scrape-jobs` | Start scraping jobs from configured criteria. |
| `GET` | `/api/scrape-jobs/run-daily-collection` | Start the daily collection task in the background. |
| `POST` | `/api/scrape-jobs/scrape-job-url` | Scrape a specific job URL. |
| `GET` | `/api/run-daily-collection` | Direct daily collection trigger registered on the main API router. |
