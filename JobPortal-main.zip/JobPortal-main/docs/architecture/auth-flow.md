# Authentication Flow

## Frontend

The UI uses `react-oidc-context` with settings from
`ui/src/auth/authConfig.js`.

Required frontend variables:

- `REACT_APP_OIDC_AUTHORITY`
- `REACT_APP_OIDC_CLIENT_ID`
- `REACT_APP_OIDC_CLIENT_SECRET`
- `REACT_APP_API_URL`

`AuthProvider` validates tokens against the backend and installs an Axios
interceptor that attaches `Authorization: Bearer <token>` to requests.

## Backend

`api/app/middleware/auth.py` protects API routes except public paths:

- `/api/health`
- `/health/live`
- `/health/ready`
- `/api`
- `/docs`
- `/redoc`
- `/openapi.json`
- `/api/auth/validate-token`

Admin paths currently require an `admin` role:

- `/api/scrape-jobs/run-daily-collection`
- `/api/run-daily-collection`

Profile resume upload requires a `candidate` role in the user record.

## Security Note

The current backend decodes JWTs with signature verification disabled in
multiple paths. Production hardening should verify tokens against
`OIDC_JWKS_URI` before relying on claims.
