# JobPortal System Architecture

JobPortal is organized as a React single-page application backed by a FastAPI service. The backend owns domain data, scraping, authentication validation, resume storage, and resume tailoring. The frontend owns route-level user workflows and calls the API through `ui/src/services/api.js`.

## Component Overview

### Frontend

- Location: `ui/`
- Framework: React 18 with React Router, Bootstrap, Material UI, Axios, and Chart.js.
- Entry points: `ui/src/index.js`, `ui/src/App.js`
- API client: `ui/src/services/api.js`
- Authentication wrapper: `ui/src/auth/AuthProvider.js`, `ui/src/auth/ProtectedRoute.js`

The application exposes public routes for the home page, callback handling, unauthorized access, and job detail pages. Job search, vendors, recruiters, analytics, resume tailoring, and profile routes are protected.

### Backend API

- Location: `api/`
- Framework: FastAPI served by Uvicorn.
- Entry point: `api/app/main.py`
- Router assembly: `api/app/api/api.py`
- Configuration: `api/app/config.py`
- Database access: `api/app/database.py`

`api/app/main.py` creates the FastAPI app, configures CORS from settings, installs `AuthMiddleware`, includes the API router, and starts or stops the scraping scheduler during application lifecycle events.

### Domain Model and Services

The backend uses SQLAlchemy models under `api/app/models/` for jobs, users, skills, vendors, recruiters, and relationships such as job skills. Service modules under `api/app/services/` hold data access and domain operations for jobs, users, analytics, vendors, recruiters, and S3 resume storage.

### Scraping

Scraping code lives under `api/app/scrapers/`. The Dice scraper implementation is in `api/app/scrapers/dice/`, while common browser, concurrency, export, and data model helpers live in `api/app/scrapers/common/`.

The API starts a scheduler through `initialize_scheduler`, `start_scheduler`, and `shutdown_scheduler` in `api/app/scrapers/scheduler.py`. Manual scraping endpoints are exposed under `/api/scrape-jobs`.

### Resume Storage and Tailoring

Resume upload and profile flows are exposed under `/api/profile`. Uploaded resume handling uses the profile route and `api/app/services/s3_service.py`.

Resume tailoring is exposed under `/api/tailor/tailor-resume`. The implementation in `api/app/tailor/resume_tailor.py` reads an uploaded `.docx`, formats `api/app/tailor/resume_tailoring_prompt.txt`, invokes a CrewAI agent backed by `ChatOpenAI`, and returns a generated `.docx` file.

## Request Flow

1. A user navigates in the React app.
2. The UI calls the backend through `ui/src/services/api.js`.
3. FastAPI receives the request through route modules in `api/app/api/routes/`.
4. Middleware validates authorization where required.
5. Route handlers call service modules and SQLAlchemy models.
6. The API returns JSON for normal application data or a binary `.docx` response for resume tailoring.

## External Dependencies

- PostgreSQL-compatible database configured through `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`, and `DB_NAME`.
- Keycloak/OIDC configuration through `OIDC_CLIENT_ID`, `OIDC_ISSUER`, and `OIDC_JWKS_URI`.
- S3-compatible resume storage through AWS and bucket environment variables.
- OpenAI-compatible credentials for the resume tailoring LLM path through `OPENAI_API_KEY`.
- Selenium and webdriver tooling for scraping workflows.

## Operational Notes

The repository currently includes default configuration values in `api/app/config.py`. For real deployments, provide these values through environment variables or a deployment secret store instead of relying on checked-in defaults.
