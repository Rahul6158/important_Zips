# Deployment View

## API Container

`api/Dockerfile` builds a Python 3.11 slim image, installs Chromium and
ChromeDriver for scraping, installs Python dependencies from `requirements.txt`,
exposes port `8000`, and runs:

```bash
uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}
```

The image defines a health check against `/health/live`.

## UI Container

`ui/Dockerfile` expects a prebuilt React `build/` directory and serves it from
Nginx on port `8081`. `ui/nginx.conf` uses `try_files` fallback to support SPA
routes.

## CI/CD

`api/Jenkinsfile` and `ui/Jenkinsfile` define Jenkins pipelines that:

- check out source,
- run shared-library build steps,
- build Docker images,
- publish images only on the configured release branch,
- update release or Helm values through shared-library helpers.

Sensitive notification endpoints and CI credentials are present in pipeline
files and are intentionally not copied into documentation.

## Deployment Gaps

- Helm chart path for JobPortal is not yet documented in this repository.
- Runtime namespace, ingress, TLS, and production DNS are not yet documented in
  this repository.
- Rollback owner and release approval process are not yet documented in this
  repository.
