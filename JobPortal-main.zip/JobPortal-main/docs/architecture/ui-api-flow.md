# UI/API Flow

The frontend centralizes most backend calls in `ui/src/services/api.js`.
Authentication headers are attached by an Axios request interceptor in
`ui/src/auth/AuthProvider.js`.

```mermaid
sequenceDiagram
  participant User
  participant UI as React UI
  participant OIDC as OIDC Provider
  participant API as FastAPI
  participant DB as PostgreSQL

  User->>UI: Open protected route
  UI->>OIDC: Redirect for sign-in if needed
  OIDC-->>UI: Return access token
  UI->>API: POST /api/auth/validate-token
  API->>DB: Create/update user by email
  API-->>UI: User profile
  UI->>API: GET application data with bearer token
  API->>DB: Query models/services
  API-->>UI: JSON response or .docx download
```

## Route Families

| UI Workflow | Backend Routes |
| --- | --- |
| Jobs | `/api/jobs/all`, `/api/jobs/{job_id}` |
| Vendors | `/api/vendors/all`, `/api/vendors/{vendor_id}`, `/api/vendors/internal/{internal_id}` |
| Recruiters | `/api/recruiters/all`, `/api/recruiters/{recruiter_id}`, `/api/recruiters/internal/{internal_id}` |
| Analytics | `/api/analytics/skills`, `/api/analytics/locations`, `/api/analytics/skills/all`, `/api/analytics/locations/all` |
| Auth/Profile | `/api/auth/validate-token`, `/api/auth/profile`, `/api/profile/*` |
| Resume Tailoring | `/api/tailor/tailor-resume` |
| Scraper | `/api/scrape-jobs/*`, `/api/run-daily-collection` |

## Known Mismatch

`ui/src/services/api.js` defines `getJobByInternalId()` using
`/api/jobs/internal/{internalId}`, but `api/app/api/routes/jobs.py` does not
define that route. Numeric IDs are attempted by the generic
`/api/jobs/{job_id}` handler instead.
