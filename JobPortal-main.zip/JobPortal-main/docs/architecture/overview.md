# Architecture Overview

JobPortal is a two-application repository:

- `ui/` is a React single-page application served locally by Create React App
  and in containers by Nginx.
- `api/` is a FastAPI service served by Uvicorn. It owns persistence, route
  handlers, auth checks, scraping, resume storage, and resume tailoring.

```mermaid
flowchart LR
  Browser[Browser] --> UI[React UI]
  UI -->|Axios + bearer token| API[FastAPI API]
  API --> DB[(PostgreSQL)]
  API --> S3[S3-compatible resume storage]
  API --> Dice[Dice job source]
  API --> LLM[OpenAI-compatible LLM]
  UI --> OIDC[OIDC provider]
  API --> OIDC
```

## Backend Layers

| Layer | Files | Responsibility |
| --- | --- | --- |
| App factory | `api/app/main.py` | FastAPI app setup, CORS, auth middleware, router mounting, health checks, scheduler lifecycle. |
| Routes | `api/app/api/routes/` | HTTP endpoints for jobs, recruiters, vendors, analytics, scraper, auth, profile, and tailoring. |
| Services | `api/app/services/` | Data access and domain behavior. |
| Models | `api/app/models/` | SQLAlchemy tables for jobs, vendors, recruiters, skills, job skills, and users. |
| Schemas | `api/app/schemas/` | Pydantic request/response models. |
| Scrapers | `api/app/scrapers/` | Dice scraping, parsing, storage, scheduler, and browser helpers. |
| Tailor | `api/app/tailor/` | `.docx` parsing, prompt formatting, LLM call, and output document creation. |

## Frontend Layers

| Layer | Files | Responsibility |
| --- | --- | --- |
| Router | `ui/src/App.js` | Public and protected route definitions. |
| Auth | `ui/src/auth/` | OIDC provider wrapper, role checks, auth headers. |
| API client | `ui/src/services/api.js` | Axios calls for jobs, vendors, recruiters, analytics, profile, auth, upload, and tailoring. |
| Components | `ui/src/components/` | Job, vendor, recruiter, analytics, navbar, and home views. |
| Pages | `ui/src/pages/` | Callback, profile, unauthorized, and resume-tailoring pages. |

## Runtime Notes

- API defaults to port `8000` and exposes `/health/live`,
  `/health/ready`, and legacy `/api/health`.
- UI development server defaults to port `3000`.
- The UI build container serves static files on port `8081`.
- Scheduled scraping is disabled unless `SCRAPER_ENABLED=true`.
