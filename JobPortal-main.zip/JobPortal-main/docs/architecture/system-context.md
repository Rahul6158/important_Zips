# System Context

## Runtime Boundaries

| Boundary | Repository Evidence | Notes |
| --- | --- | --- |
| Browser UI | `ui/src/`, `ui/package.json`, `ui/nginx.conf` | React SPA; local dev through `npm start`; container runtime through Nginx. |
| API service | `api/app/main.py`, `api/Dockerfile`, `api/Makefile` | FastAPI app served by Uvicorn. |
| Database | `api/app/database.py`, `api/app/models/` | SQLAlchemy engine backed by `DATABASE_URL` or composed `DB_*` values. |
| Identity provider | `ui/src/auth/authConfig.js`, `api/app/middleware/auth.py` | OIDC settings are environment driven. |
| Resume storage | `api/app/services/s3_service.py` | S3 client configured from AWS and bucket variables. |
| Job source | `api/app/scrapers/dice/` | Dice scraping implementation. |
| Resume-tailoring LLM | `api/app/tailor/resume_tailor.py` | Uses `OPENAI_API_KEY` and `gpt-4o` in the current source. |
| CI/CD | `api/Jenkinsfile`, `ui/Jenkinsfile` | Build and image publication pipelines are defined. Sensitive webhook details are not repeated here. |

## External Systems

- PostgreSQL-compatible database.
- OIDC provider compatible with the configured authority and JWKS path.
- S3-compatible object storage for resumes.
- Dice website and scraping dependencies.
- OpenAI-compatible API for resume tailoring.
- Jenkins/shared-library CI environment.
- Harbor or equivalent registry referenced by CI helpers.

## Not Yet Documented In Repository

- Production database hostname and ownership.
- Production OIDC realm lifecycle and role assignment process.
- Production object-storage retention policy.
- Production alert routing.
- Exact GitOps or Helm values repository used for JobPortal releases.
