# Data Flow

## Job Data

```mermaid
flowchart LR
  Dice[Dice source] --> Scraper[Dice scraper]
  Scraper --> Services[Job services]
  Services --> DB[(jobs, recruiters, vendors, job_skills)]
  DB --> API[FastAPI routes]
  API --> UI[React views]
```

The scraper implementation lives under `api/app/scrapers/dice/`. Manual routes
can trigger scraping, and the scheduler can run daily collection when enabled.

## User And Auth Data

OIDC tokens are decoded by the backend auth paths. The backend creates or
updates user records by email and stores role, profile, resume, and SMTP
metadata in the `users` table.

## Resume Upload Data

1. UI posts a resume file to `/api/profile/upload-resume`.
2. Backend checks bearer auth and candidate role.
3. Backend uploads the file using `S3Service`.
4. Backend stores the returned resume URL/path on the user record.

## Resume Tailoring Data

1. UI posts a `.docx` resume and job description to `/api/tailor/tailor-resume`.
2. Backend writes the upload to a temporary file.
3. Backend reads text from the `.docx`.
4. Backend formats the tailoring prompt.
5. Backend calls the configured LLM workflow.
6. Backend writes and returns a generated `.docx`.

## Data Model Summary

| Table | Model | Main Relationships |
| --- | --- | --- |
| `jobs` | `api/app/models/job.py` | Belongs to recruiter and vendor; has many job skills. |
| `vendors` | `api/app/models/vendor.py` | Has many recruiters and jobs. |
| `recruiters` | `api/app/models/recruiter.py` | Belongs to vendor; has many jobs. |
| `job_skills` | `api/app/models/job_skill.py` | Belongs to job. |
| `skills` | `api/app/models/skill.py` | Used by profile and analytics workflows. |
| `users` | `api/app/models/user.py` | Stores auth/profile/resume metadata. |
