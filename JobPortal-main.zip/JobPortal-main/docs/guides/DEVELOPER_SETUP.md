# JobPortal Developer Setup

This guide sets up the FastAPI backend and React frontend for local development.

## Prerequisites

- Python 3.10 or newer
- Node.js and npm
- PostgreSQL access for the API database
- Optional: AWS credentials and bucket access for resume upload flows
- Optional: `OPENAI_API_KEY` for resume tailoring

## Backend Setup

From the repository root:

```bash
cd api
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Create an API environment file if local values differ from the defaults in `api/app/config.py`:

```bash
cat > .env <<'EOF'
DB_USER=jobportalappuser
DB_PASSWORD=change-me
DB_HOST=localhost
DB_PORT=5432
DB_NAME=jobportal
OPENAI_API_KEY=
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_REGION=us-east-1
S3_BUCKET_NAME=
OIDC_CLIENT_ID=JobPortal
OIDC_ISSUER=https://keycloak.tabner.com/realms/JobPortal
OIDC_JWKS_URI=https://keycloak.tabner.com/realms/JobPortal/protocol/openid-connect/certs
EOF
```

Initialize tables when using a fresh database:

```bash
python scripts/create_tables.py
```

Run the API:

```bash
python -m app.main
```

The API listens on `http://localhost:8000`. Health checks are available at:

```bash
curl http://localhost:8000/api/health
```

## Frontend Setup

In a second terminal:

```bash
cd ui
npm install
```

Create a UI environment file if needed:

```bash
cat > .env <<'EOF'
REACT_APP_API_URL=http://localhost:8000/api
EOF
```

Run the UI:

```bash
npm start
```

The UI starts on `http://localhost:3000`.

## Validation

The frontend exposes the standard Create React App commands:

```bash
cd ui
npm test -- --watchAll=false
npm run build
```

For the backend, at minimum verify the application imports and exposes the health endpoint after dependencies and database configuration are in place:

```bash
cd api
python -m app.main
curl http://localhost:8000/api/health
```

## Common Issues

- Database connection failures usually mean the `DB_*` variables are still pointing at the default host from `api/app/config.py`.
- Resume upload requires S3 settings to be valid.
- Resume tailoring requires `OPENAI_API_KEY` and a `.docx` upload.
- Browser-based scraping requires Selenium and a compatible local browser or driver setup.
- CORS is configured in `api/app/config.py`; add local frontend origins there or through configuration if the browser blocks requests.
