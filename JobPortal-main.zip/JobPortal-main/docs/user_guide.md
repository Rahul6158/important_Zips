# JobPortal User Guide

JobPortal helps authenticated users browse job listings, review recruiters and vendors, track job market analytics, manage profile information, upload resumes, and generate tailored resume drafts for specific job descriptions.

## Sign In

Most application areas are protected. After sign-in, the app validates the token with the backend and allows access to jobs, vendors, recruiters, analytics, resume tailoring, and profile routes.

## Browse Jobs

Use the Jobs area to search available job records. The UI loads jobs from `/api/jobs/all` and opens a detail view for individual records through `/api/jobs/{job_id}`.

Job records may include company, vendor, recruiter, skill, location, and job description data depending on what was collected by the backend scraper or imported into the database.

## Review Vendors and Recruiters

The Vendors and Recruiters areas list organizations and contacts stored in the backend. Detail pages show the selected vendor or recruiter record and related information available in the database.

## View Analytics

The Analytics area summarizes job data by skill and location. These views use the backend analytics routes to help identify common skills and hiring locations in the current dataset.

## Manage Profile and Resume

The Profile area supports resume upload, skill updates, skill extraction from uploaded resumes, and resume status checks. Uploaded resume files are handled by the backend and may be stored through the configured S3 service.

## Tailor a Resume

The Resume Tailor workflow accepts a `.docx` resume and a target job description. The backend reads the resume, sends the resume text and job description through the configured tailoring prompt and LLM workflow, and returns a tailored `.docx` file for download.

Review any generated resume before using it. The tool is meant to produce a draft, not to verify facts or guarantee application outcomes.

## Troubleshooting

- If protected pages redirect unexpectedly, sign out and sign in again so the token can be refreshed.
- If job, vendor, recruiter, or analytics pages are empty, the backend database may not have current records.
- If resume upload fails, check file type and backend storage configuration.
- If resume tailoring fails, confirm the uploaded file is a `.docx` and that the backend has a valid LLM API key.
