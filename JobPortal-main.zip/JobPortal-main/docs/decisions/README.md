# Decisions

No formal ADR files are currently present in this repository.

## Repository-Visible Decisions

| Decision | Evidence |
| --- | --- |
| React frontend and FastAPI backend live in one repository. | `ui/`, `api/` |
| API uses FastAPI app factory pattern. | `api/app/main.py:create_app` |
| API config is environment-driven through Pydantic settings. | `api/app/config.py` |
| Scheduled scraping is disabled by default. | `api/app/config.py`, `api/app/scrapers/scheduler.py` |
| API image includes Chromium and ChromeDriver for scraping. | `api/Dockerfile` |
| UI image serves CRA build through Nginx. | `ui/Dockerfile`, `ui/nginx.conf` |

Future architectural decisions should be added as separate ADR files in this
directory and linked from this index.
