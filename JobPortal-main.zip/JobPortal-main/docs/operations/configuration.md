# Configuration

## API Environment Variables

Defined in `api/app/config.py` and `api/.env.example`.

| Name | Required | Purpose |
| --- | --- | --- |
| `APP_NAME` | no | FastAPI app title. |
| `APP_VERSION` | no | App version returned by health endpoints. |
| `APP_DESCRIPTION` | no | FastAPI app description. |
| `APP_ENV` | no | Runtime environment label. |
| `PORT` | no | API listen port, defaults to `8000`. |
| `DATABASE_URL` | yes in deployed environments | Full PostgreSQL connection string. |
| `DB_USER` | fallback | Used only when `DATABASE_URL` is unset. |
| `DB_PASSWORD` | fallback | Used only when `DATABASE_URL` is unset. |
| `DB_HOST` | fallback | Used only when `DATABASE_URL` is unset. |
| `DB_PORT` | fallback | Used only when `DATABASE_URL` is unset. |
| `DB_NAME` | fallback | Used only when `DATABASE_URL` is unset. |
| `CORS_ORIGINS` | yes | Comma-separated browser origins. |
| `SCRAPER_ENABLED` | yes | Enables/disables scheduled scraper startup. |
| `SCHEDULER_JOB_HOUR` | if scraper enabled | Daily collection hour. |
| `SCHEDULER_JOB_MINUTE` | if scraper enabled | Daily collection minute. |
| `DEFAULT_POSTED_DATE` | scraper | Default Dice query setting. |
| `DEFAULT_WORKPLACE_TYPES` | scraper | Default Dice workplace types. |
| `DEFAULT_EMPLOYMENT_TYPE` | scraper | Default Dice employment types. |
| `DEFAULT_LIMIT` | scraper | Default Dice result limit. |
| `AWS_ACCESS_KEY_ID` | if resume upload enabled | S3 access key from secret store. |
| `AWS_SECRET_ACCESS_KEY` | if resume upload enabled | S3 secret key from secret store. |
| `AWS_REGION` | if resume upload enabled | S3 region. |
| `S3_BUCKET_NAME` | if resume upload enabled | Resume bucket name. |
| `OIDC_CLIENT_ID` | yes | OIDC client ID used by backend role lookup. |
| `OIDC_ISSUER` | yes | OIDC issuer. |
| `OIDC_JWKS_URI` | yes | JWKS endpoint for production token verification. |
| `OPENAI_API_KEY` | if tailoring enabled | LLM credential used by resume tailoring. |

## UI Environment Variables

Defined by references in `ui/src/auth/authConfig.js` and
`ui/src/services/api.js`.

| Name | Required | Purpose |
| --- | --- | --- |
| `REACT_APP_API_URL` | yes | Backend API base URL, expected to include `/api`. |
| `REACT_APP_OIDC_AUTHORITY` | yes for auth flows | OIDC authority. |
| `REACT_APP_OIDC_CLIENT_ID` | yes for auth flows | OIDC client ID. |
| `REACT_APP_OIDC_CLIENT_SECRET` | repository-visible, risk to review | Client secret passed into browser OIDC config. |

## Secret Handling

Do not commit real secrets. Use `.env.example` only for names and safe example
values. Runtime secrets should be supplied by the deployment platform.
