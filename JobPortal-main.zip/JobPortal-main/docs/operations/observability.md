# Observability

## Health Endpoints

| Endpoint | Purpose |
| --- | --- |
| `GET /health/live` | Public liveness endpoint. |
| `GET /health/ready` | Readiness endpoint that checks database connectivity. |
| `GET /api/health` | Legacy health endpoint retained for compatibility. |

`/health/ready` returns HTTP 503 with a database check when the database is
unavailable.

## Logging

The API configures Python logging in `api/app/main.py` with a stream handler and
an `api.log` file handler. Scraper and auth modules also log through named
loggers.

## CI Signals

Jenkinsfiles define success and failure notifications. Sensitive notification
URLs are not repeated in documentation.

## Gaps

- Metrics backend is not yet documented in repository.
- Trace collection is not yet documented in repository.
- Alert severity, ownership, and escalation policy are not yet documented in
  repository.
