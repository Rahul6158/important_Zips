# Release Process

## Repository-Visible Process

The repository includes separate Jenkins pipelines for `api/` and `ui/`.

Visible stages include:

- checkout and author identification,
- build,
- Docker image build,
- image publication on the configured release branch,
- release or Helm values update on the configured release branch,
- success/failure notifications.

## Recommended Release Checklist

1. Confirm backend tests pass: `cd api && make test`.
2. Confirm backend lint/type checks pass: `make lint`, `make format-check`,
   `make type-check`.
3. Confirm frontend build passes: `cd ui && npm run build`.
4. Build API and UI images.
5. Verify runtime configuration values are supplied by secret/config stores.
6. Deploy API and verify `/health/live` and `/health/ready`.
7. Deploy UI and verify OIDC login plus a protected route.
8. Keep `SCRAPER_ENABLED=false` unless the target environment intentionally
   runs scheduled scraping.

## Not Yet Documented In Repository

- Release branch naming standard.
- Image registry paths.
- Helm values repository path.
- Deployment approval owner.
- Rollback service-level objective.
