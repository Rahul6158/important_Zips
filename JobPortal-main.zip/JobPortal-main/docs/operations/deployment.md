# Deployment

## API

Build from `api/`:

```bash
docker build -t jobportal-api:local .
```

Run command from the image:

```bash
uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}
```

Required deployment inputs:

- PostgreSQL connection through `DATABASE_URL`.
- Browser origins through `CORS_ORIGINS`.
- OIDC variables.
- S3 variables if resume upload is enabled.
- `OPENAI_API_KEY` if resume tailoring is enabled.
- Explicit `SCRAPER_ENABLED` value.

## UI

Build the React app before building the container:

```bash
cd ui
npm install
npm run build
docker build -t jobportal-ui:local .
```

The UI image serves the static build through Nginx on port `8081`.

## CI/CD

`api/Jenkinsfile` and `ui/Jenkinsfile` define build, image publication, and
release-value update stages. The production release branch and shared-library
implementation are external to this repository.

## Rollback

Standard image rollback:

1. Restore the previous API and UI image tags.
2. Keep database and OIDC secrets unchanged unless the incident is caused by
   configuration.
3. Set `SCRAPER_ENABLED=false` if scraper behavior is suspected.
4. Verify `/health/live`, `/health/ready`, and the UI root route.

## Not Yet Documented In Repository

- Kubernetes namespace and manifests.
- Ingress/TLS/DNS ownership.
- Production database migration process.
- Release approval and change-management process.
