# Security

## Authentication And Authorization

- The UI uses OIDC through `react-oidc-context`.
- The UI attaches bearer tokens to Axios requests after authentication.
- The API auth middleware requires bearer tokens for non-public routes.
- Admin scraper routes require an `admin` role.
- Resume upload requires a `candidate` role.

## Sensitive Data

Do not commit:

- database passwords,
- OIDC client secrets,
- AWS access keys,
- S3 credentials,
- OpenAI API keys,
- webhook URLs,
- real `.env` files,
- user resumes or generated resume outputs.

## Current Risk Notes

- Backend JWT decoding currently disables signature verification. Production
  should validate tokens against `OIDC_JWKS_URI`.
- `REACT_APP_OIDC_CLIENT_SECRET` is referenced by frontend code. Browser-shipped
  client secrets should be reviewed before production use.
- The `users` model includes SMTP credential fields. Any feature using them
  should store secrets through an approved secret-management path.

## Access Control Gaps

- Full role model is not yet documented in repository.
- Admin route ownership is not yet documented in repository.
- Resume retention and deletion policy is not yet documented in repository.
