# JobPortal Documentation

This is the source-backed documentation hub for JobPortal. The repository
contains a FastAPI backend under `api/` and a React frontend under `ui/`.

## Start Here

| Area | Description | Link |
| --- | --- | --- |
| Product Overview | Product purpose, users, boundaries, and visible capabilities. | [product/overview.md](./product/overview.md) |
| Features | User-facing and operational feature inventory. | [product/features.md](./product/features.md) |
| User Journeys | Main workflows from sign-in through resume tailoring. | [product/user-journeys.md](./product/user-journeys.md) |
| Glossary | Repository terms and domain language. | [product/glossary.md](./product/glossary.md) |
| Architecture | System-level component view. | [architecture/overview.md](./architecture/overview.md) |
| System Context | External systems and runtime boundaries. | [architecture/system-context.md](./architecture/system-context.md) |
| UI/API Flow | Browser-to-API request paths. | [architecture/ui-api-flow.md](./architecture/ui-api-flow.md) |
| Data Flow | Jobs, recruiters, vendors, users, resumes, and tailored document flows. | [architecture/data-flow.md](./architecture/data-flow.md) |
| Authentication Flow | OIDC, bearer-token propagation, and route protection. | [architecture/auth-flow.md](./architecture/auth-flow.md) |
| Deployment View | Container and CI/CD shape visible in the repository. | [architecture/deployment-view.md](./architecture/deployment-view.md) |
| API Documentation | Backend-specific docs. | [../api/docs/README.md](../api/docs/README.md) |
| UI Documentation | Frontend-specific docs. | [../ui/docs/README.md](../ui/docs/README.md) |
| Local Development | Local setup and run commands. | [engineering/local-development.md](./engineering/local-development.md) |
| Repository Structure | Directory map and ownership. | [engineering/repository-structure.md](./engineering/repository-structure.md) |
| Coding Standards | Source-backed code conventions and validation commands. | [engineering/coding-standards.md](./engineering/coding-standards.md) |
| Testing Strategy | Existing test coverage and expected checks. | [engineering/testing-strategy.md](./engineering/testing-strategy.md) |
| Troubleshooting | Known local and runtime issues. | [engineering/troubleshooting.md](./engineering/troubleshooting.md) |
| Configuration | Environment variables and safe examples. | [operations/configuration.md](./operations/configuration.md) |
| Deployment | Runtime deployment notes. | [operations/deployment.md](./operations/deployment.md) |
| Observability | Health endpoints and logging signals. | [operations/observability.md](./operations/observability.md) |
| Security | Auth, secret handling, and sensitive data notes. | [operations/security.md](./operations/security.md) |
| Release Process | CI/CD and release gaps visible in source. | [operations/release-process.md](./operations/release-process.md) |
| Decisions | ADR index and current documented decisions. | [decisions/README.md](./decisions/README.md) |

## Legacy Pages

These pages predate the standard documentation layout and are kept because they
still contain useful reference material:

- [Legacy system architecture](./architecture/SYSTEM_ARCHITECTURE.md)
- [Legacy developer setup](./guides/DEVELOPER_SETUP.md)
- [Legacy API reference](./reference/API_REFERENCE.md)
- [Legacy user guide](./user_guide.md)

When editing documentation, prefer the standard pages above and preserve useful
legacy content by linking or migrating it.
