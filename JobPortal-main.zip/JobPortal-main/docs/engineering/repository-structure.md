# Repository Structure

```text
.
├── api/
│   ├── app/
│   │   ├── api/routes/       # FastAPI routers
│   │   ├── middleware/       # Auth middleware
│   │   ├── models/           # SQLAlchemy models
│   │   ├── schemas/          # Pydantic schemas
│   │   ├── scrapers/         # Dice scraper and scheduler
│   │   ├── services/         # Data access and domain services
│   │   └── tailor/           # Resume tailoring flow
│   ├── docs/                 # API-specific docs
│   ├── scripts/              # Database maintenance scripts
│   └── tests/                # Unit and integration tests
├── docs/                     # Product, architecture, engineering, operations docs
├── graphify-out/             # Generated graph artifacts
└── ui/
    ├── docs/                 # UI-specific docs
    ├── public/               # CRA public assets when present
    └── src/                  # React source
```

## Ownership Boundaries

| Area | Owner Context |
| --- | --- |
| `api/app/api/routes/` | HTTP behavior and request/response contracts. |
| `api/app/services/` | Domain logic and database access. |
| `api/app/models/` | Persistent schema model definitions. |
| `api/app/scrapers/` | Dice scraping behavior and scheduler integration. |
| `api/app/tailor/` | Resume tailoring prompt and document generation. |
| `ui/src/auth/` | Browser auth state, role checks, and token propagation. |
| `ui/src/services/api.js` | UI-to-API client contract. |
| `ui/src/components/` and `ui/src/pages/` | User-facing views and workflows. |
| `docs/`, `api/docs/`, `ui/docs/` | Documentation that must remain source-backed. |
