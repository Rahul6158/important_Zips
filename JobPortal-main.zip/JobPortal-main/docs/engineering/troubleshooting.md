# Troubleshooting

## API Will Not Start

- Confirm `api/.env` exists or that environment variables are exported.
- Confirm `DATABASE_URL` or `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`, and
  `DB_NAME` point to a reachable PostgreSQL database.
- Run `cd api && make install` after dependency changes.

## `/health/ready` Returns 503

Readiness runs `SELECT 1` against the configured database. A 503 usually means
the database is unavailable or credentials are wrong.

## Browser Requests Fail With CORS

`CORS_ORIGINS` is parsed as a comma-separated list. Include the frontend origin,
for example:

```text
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```

Do not use `*` with credentials enabled.

## Protected Pages Redirect To Home

- Confirm the OIDC variables are set in `ui/.env`.
- Confirm the access token is accepted by `POST /api/auth/validate-token`.
- Check that the API base URL includes `/api`.

## Resume Upload Fails

- The backend requires a bearer token.
- The user must have a `candidate` role.
- Accepted content types are PDF, `.docx`, and legacy Word documents.
- S3 credentials and bucket configuration must be valid.

## Resume Tailoring Fails

- The endpoint accepts `.docx` only.
- `OPENAI_API_KEY` must be configured for the backend process.
- The LLM path writes temporary files; check API logs for document parsing or
  output generation errors.

## Job Internal ID Helper Fails

The UI has a helper for `/api/jobs/internal/{id}`, but the backend does not
currently expose that route. Use `/api/jobs/{job_id}` with a numeric ID until
the API and UI contract is aligned.
