# Coding Standards

## Backend

The backend declares tool configuration in `api/pyproject.toml`:

- Python target: `py311`
- Ruff line length: `100`
- Ruff selected rules: `E`, `F`, `I`, `UP`, `B`
- Mypy checks `app` and `tests`

Use the Makefile commands:

```bash
cd api
make lint
make format-check
make type-check
```

Route handlers should stay in `api/app/api/routes/`, service/database logic
should stay in `api/app/services/`, and persistent fields should be represented
in both SQLAlchemy models and Pydantic schemas when they cross the API boundary.

## Frontend

The frontend uses the Create React App ESLint configuration from
`ui/package.json`.

Use npm scripts:

```bash
cd ui
npm test -- --watchAll=false
npm run build
```

Keep backend calls in `ui/src/services/api.js` unless a component has a strong
reason to own a request directly. Protected route behavior belongs in
`ui/src/auth/`.

## Documentation

Documentation must be source-backed:

- Prefer facts from repository files over assumptions.
- Use relative Markdown links for repository navigation.
- Do not copy secrets, webhook URLs, credentials, or real `.env` values.
- Mark unknowns as `TBD` or `Not yet documented in repository`.
- Update root docs plus `api/docs/` and `ui/docs/` when changing cross-cutting
  behavior.
