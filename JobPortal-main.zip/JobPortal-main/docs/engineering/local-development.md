# Local Development

## Prerequisites

- Python 3.11 recommended by `api/Dockerfile` and `api/pyproject.toml`.
- Node.js and npm for the React UI.
- PostgreSQL-compatible database.
- Optional S3-compatible credentials for resume upload.
- Optional OIDC provider configuration for protected UI flows.
- Optional `OPENAI_API_KEY` for resume tailoring.
- Optional Chromium/ChromeDriver for local scraping.

## Backend

```bash
cd api
python3 -m venv .venv
source .venv/bin/activate
make install
cp .env.example .env
make run
```

The API listens on `http://localhost:8000` by default.

Health checks:

```bash
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
curl http://localhost:8000/api/health
```

Create tables for a fresh local database:

```bash
cd api
python scripts/create_tables.py
```

## Frontend

```bash
cd ui
npm install
npm start
```

The Create React App development server starts on `http://localhost:3000`.

Create `ui/.env` when local values are needed:

```text
REACT_APP_API_URL=http://localhost:8000/api
REACT_APP_OIDC_AUTHORITY=<oidc-authority>
REACT_APP_OIDC_CLIENT_ID=<oidc-client-id>
REACT_APP_OIDC_CLIENT_SECRET=<oidc-client-secret>
```

## Validation

Backend:

```bash
cd api
make test
make lint
make format-check
make type-check
make docker-build
```

Frontend:

```bash
cd ui
npm test -- --watchAll=false
npm run build
```

If the API readiness check fails locally, verify database environment variables
before debugging application code.
