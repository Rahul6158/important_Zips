# Testing Strategy

## Existing Backend Tests

| Test File | Coverage |
| --- | --- |
| `api/tests/unit/test_config.py` | Database URL composition and comma-separated CORS parsing. |
| `api/tests/integration/test_health.py` | Public liveness endpoint and legacy `/api/health` endpoint. |

Run:

```bash
cd api
make test
```

## Existing Frontend Tests

The UI uses Create React App testing dependencies, but no dedicated test files
are currently visible in `ui/src/`.

Run the default test command:

```bash
cd ui
npm test -- --watchAll=false
```

## Build Checks

```bash
cd api
make lint
make format-check
make type-check
make docker-build
```

```bash
cd ui
npm run build
```

## Recommended Next Tests

- API route tests for jobs, vendors, recruiters, analytics, profile, scraper,
  and resume tailoring.
- Auth middleware tests for public paths, bearer-token failure modes, admin
  paths, and candidate-only resume upload.
- Database integration tests around job search filters and aggregate counts.
- UI tests for route guards, auth callback handling, job search filters,
  profile save, upload progress, and resume-tailor submission.
- Contract tests to prevent UI helpers from referencing backend routes that do
  not exist.
