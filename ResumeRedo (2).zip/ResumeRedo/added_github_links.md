# Added and Configured Project GitHub Links

Here is a summary of all the GitHub and project links added, updated, or verified across the portfolio pages and articles.

---

## 1. LawBot — AI Legal Assistant
* **Repository Link:** [https://github.com/Rahul6158/law_bot](https://github.com/Rahul6158/law_bot)
* **Demo Popup Target:** `img/image.png`
* **Locations Configured:**
  * **Main Page:** [tusharahul/index.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/index.html) (Added a **"View GitHub"** button, a **"About LawBot"** trigger button to open the image modal, and zoom cursor on image click).

---

## 2. AI-Powered LinkedIn Content Automation
* **Repository Link:** [https://github.com/Rahul6158/N8N-Linkedin-Post-Automation](https://github.com/Rahul6158/N8N-Linkedin-Post-Automation)
* **Locations Configured:**
  * **Main Page:** [tusharahul/index.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/index.html) (Added primary link/GitHub buttons).
  * **Article Page:** [tusharahul/articles/linkedin-automation.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/articles/linkedin-automation.html) (Added **"View GitHub Repository"** button to header, appended the section to the sidebar Table of Contents, and created the **"Code & Deployment"** section at the bottom).

---

## 3. Pioneer Pharma Insights Engine
* **Repository Link:** [https://github.com/Rahul6158/Pioneer-Nexus](https://github.com/Rahul6158/Pioneer-Nexus)
* **Locations Configured:**
  * **Main Page:** [tusharahul/index.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/index.html) (Added GitHub button).
  * **Article Page:** [tusharahul/articles/pioneer-nexus-article.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/articles/pioneer-nexus-article.html) (Added **"View GitHub Repository"** button to header, appended the section to the sidebar Table of Contents, and created the **"Code & Deployment"** section at the bottom).

---

## 4. DocPortal AI: Enterprise Document Intelligence
* **Repository Link:** [https://github.com/Rahul6158/DocPortalAI](https://github.com/Rahul6158/DocPortalAI)
* **Locations Configured:**
  * **Main Page:** [tusharahul/index.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/index.html) (Added GitHub button).
  * **Article Page:** [tusharahul/articles/docportal-article.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/articles/docportal-article.html) (Verified existing header button and bottom **"Explore Source Code"** section).

---

## 5. FluentTranslate
* **Repository Link:** [https://github.com/Rahul6158/FluentTranslate](https://github.com/Rahul6158/FluentTranslate)
* **Locations Configured:**
  * **Main Page:** [tusharahul/index.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/index.html) (Added secondary GitHub button).

---

## 6. DSA Visualization (DSV)
* **View Project Link:** [https://rahul6158.github.io/DSV](https://rahul6158.github.io/DSV)
* **Repository Link:** [https://github.com/Rahul6158/DSV](https://github.com/Rahul6158/DSV)
* **Locations Configured:**
  * **Main Page:** [tusharahul/index.html](file:///e:/Learning_curve/portfolio/tusharahul/tusha-rahul-updated/tusharahul/index.html) (Added view project link, and split/moved GitHub target to a separate GitHub button).
