"""
Stats Service
===============
Aggregates statistics with aggressive caching.
"""

import time as _time
from datetime import datetime, UTC
from sqlalchemy.orm import Session
from sqlalchemy import func
from sqlalchemy.sql import text
from app.models.base import DB_SCHEMA, CANDIDATE_SCHEMA
from app.models.jobs import ActiveScrapedData, InactiveScrapedData
from app.repositories import job_repository
from app.cache.redis_client import cache
from app.config import logger

_STATS_TTL = 30  # seconds — stats rarely change faster than this


def _fast_candidate_count(db: Session) -> int:
    """Use pg_class estimate for candidate count (instant)."""
    try:
        result = db.execute(
            text("SELECT reltuples::bigint FROM pg_class WHERE relname = 'candidate_basic_info'")
        )
        row = result.fetchone()
        return max(row[0], 0) if row else 0
    except Exception:
        try:
            from app.repositories.candidate_repository import get_candidate_count
            return get_candidate_count(db)
        except Exception:
            return 0


def _fast_today_count(db: Session) -> int:
    """Count jobs scraped today — uses indexed scraped_at column."""
    try:
        today_str = datetime.now(UTC).strftime("%Y-%m-%d")
        result = db.execute(text(f"""
            SELECT
                (SELECT COUNT(*) FROM {DB_SCHEMA}.active_scraped_data WHERE scraped_at >= :today)
                +
                (SELECT COUNT(*) FROM {DB_SCHEMA}.inactive_scraped_data WHERE scraped_at >= :today)
        """), {"today": today_str})
        return result.fetchone()[0] or 0
    except Exception as e:
        logger.warning(f"Today's count query failed: {e}")
        return 0


def get_stats(db: Session, scraper_config: dict) -> dict:
    """Get application stats with caching (30s TTL)."""
    cached = cache.get("app:stats")
    if cached:
        return cached

    try:
        active = job_repository.get_fast_count(db, "active_scraped_data")
        inactive = job_repository.get_fast_count(db, "inactive_scraped_data")
        candidates = _fast_candidate_count(db)
        today = _fast_today_count(db)

        from datetime import timedelta

        def get_next_run_datetime(schedule_time_str):
            if not schedule_time_str or schedule_time_str == "Disabled" or schedule_time_str == "Unknown":
                return schedule_time_str
            try:
                h, m = map(int, schedule_time_str.split(':'))
                now_dt = datetime.now()
                target = now_dt.replace(hour=h, minute=m, second=0, microsecond=0)
                if target < now_dt:
                    target += timedelta(days=1)
                return target.strftime("%b %d, %Y %I:%M %p")
            except Exception:
                return schedule_time_str

        next_run = "Disabled"
        if scraper_config.get("schedule_enabled"):
            next_run = get_next_run_datetime(scraper_config.get("schedule_time", "Unknown"))

        # Fetch last run from ScraperLog
        last_run_ts = None
        try:
            from app.models.jobs import ScraperLog
            last_log = db.query(ScraperLog).filter(ScraperLog.status == "completed").order_by(ScraperLog.end_time.desc()).first()
            if last_log and last_log.end_time:
                last_run_ts = last_log.end_time.timestamp()
        except Exception as e:
            logger.warning(f"Failed to fetch last scraper run: {e}")

        from app.repositories import candidate_repository
        tailored = candidate_repository.get_tailored_resume_count(db)

        # Count matched candidates (candidates with at least 1 match from the new Matching Agent)
        try:
            matched_candidates_count = db.execute(
                text(f"SELECT COUNT(DISTINCT candidate_id) FROM {CANDIDATE_SCHEMA}.candidate_job_matches")
            ).fetchone()[0] or 0
        except Exception:
            matched_candidates_count = 0

        # Count average match quality score from the new Matching Agent
        try:
            avg_score = db.execute(
                text(f"SELECT COALESCE(AVG(overall_score), 0) FROM {CANDIDATE_SCHEMA}.candidate_job_matches")
            ).fetchone()[0] or 0
        except Exception:
            avg_score = 0.0

        # Count actual applications submitted (applied = true) from the new Matching Agent
        try:
            applications_submitted_count = db.execute(
                text(f"SELECT COUNT(*) FROM {CANDIDATE_SCHEMA}.candidate_job_matches WHERE applied = true")
            ).fetchone()[0] or 0
        except Exception:
            applications_submitted_count = 0

        result = {
            "jobs_scraped_today": today,
            "total_jobs": active + inactive,
            "total_active": active,
            "total_inactive": inactive,
            "matched_candidates": matched_candidates_count,
            "match_quality_score": f"{int(avg_score)}%",
            "tailored_resumes": tailored,
            "applications_submitted": applications_submitted_count,
            "discovery_active": job_repository.get_fast_count(db, "active_dice_jobs"),
            "discovery_inactive": job_repository.get_fast_count(db, "inactive_dice_jobs"),
            "scheduler_next_run": next_run,
            "scraper_last_run_at": last_run_ts,
        }
        cache.set("app:stats", result, ttl=_STATS_TTL)
        return result
    except Exception as e:
        logger.error(f"Failed to compute stats: {e}")
        return {"error": str(e), "jobs_scraped_today": 0, "total_jobs": 0, "matched_candidates": 0, "match_quality_score": "0%", "tailored_resumes": 0, "applications_submitted": 0}


def get_init_data(db: Session, scraper_config: dict, app_state) -> dict:
    """Consolidated init endpoint data."""
    now = _time.time()

    status = app_state.to_dict() if app_state else {"status": "idle"}
    stats = get_stats(db, scraper_config)

    return {
        "status": status,
        "stats": stats,
        "settings": scraper_config,
        "timestamp": now,
    }
