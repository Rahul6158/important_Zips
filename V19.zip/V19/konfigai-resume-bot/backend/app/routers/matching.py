"""
Matching Agent Router
======================
Exposes two endpoints that mirror the placeholder routes already wired
in the frontend:

  GET  /candidates/{unique_id}/matches
       Returns stored match results from the last run.

  POST /candidates/{unique_id}/matches/run
       Triggers the full 3-stage matching pipeline inline.
       Expected latency: 30–45 seconds (LLM scoring 30 jobs via Groq).
       Run this from the UI button or call it programmatically after
       resume formatting completes.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.dependencies import get_db, check_api_key
from app.config import logger
from services.matching_agent import run_matching, get_matches

router = APIRouter(tags=["Matching"])


@router.get("/candidates/{unique_id}/matches")
def get_candidate_matches(
    unique_id: str,
    limit: int = 20,
    db: Session = Depends(get_db),
    _: None = Depends(check_api_key),
):
    """
    Return the stored match results for a candidate.

    Query params:
      limit (int, default 20): Max number of job matches to return.

    Returns 200 with { status, candidate_id, jobs, matched_at, total }.
    Returns 500 on unexpected errors.
    """
    try:
        data = get_matches(db, unique_id, limit=limit)
        return {"status": "ok", "candidate_id": unique_id, **data}
    except Exception as exc:
        logger.error(f"[MatchingRouter] GET matches failed for {unique_id}: {exc}")
        raise HTTPException(status_code=500, detail="Unable to fetch match results.")


@router.post("/candidates/{unique_id}/matches/run")
async def run_candidate_matching(
    unique_id: str,
    db: Session = Depends(get_db),
    _: None = Depends(check_api_key),
):
    """
    Run the full matching pipeline for a candidate and return results.

    The candidate must have a completed formatted resume
    (formatted_resume_status = 'completed').

    Returns 200 with { status, candidate_id, jobs_filtered, jobs_scored,
                        jobs, matched_at }.
    Returns 400 if resume is not completed.
    Returns 404 if candidate not found.
    Returns 500 on pipeline failure.
    """
    try:
        result = await run_matching(candidate_id=unique_id, db=db)
        return {
            "status": "ok",
            "candidate_id": unique_id,
            "jobs_filtered": result.jobs_filtered,
            "jobs_scored": result.jobs_scored,
            "jobs": [j.model_dump() for j in result.jobs],
            "matched_at": result.matched_at,
        }
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.error(f"[MatchingRouter] Run failed for {unique_id}: {exc}")
        raise HTTPException(status_code=500, detail="Matching pipeline failed.")


@router.post("/candidates/{unique_id}/matches/{job_id}/toggle-applied")
def toggle_applied(
    unique_id: str,
    job_id: int,
    db: Session = Depends(get_db),
    _: None = Depends(check_api_key),
):
    """
    Toggle the 'applied' status of a candidate match in the candidate_job_matches table.
    """
    try:
        from sqlalchemy import text
        row = db.execute(
            text("SELECT applied FROM candidate_details.candidate_job_matches WHERE candidate_id = :cid AND job_serial_no = :jid"),
            {"cid": unique_id, "jid": job_id}
        ).fetchone()
        
        if not row:
            raise HTTPException(status_code=404, detail="Match record not found.")
        
        next_applied = not bool(row.applied)
        db.execute(
            text("UPDATE candidate_details.candidate_job_matches SET applied = :applied WHERE candidate_id = :cid AND job_serial_no = :jid"),
            {"applied": next_applied, "cid": unique_id, "jid": job_id}
        )
        db.commit()
        return {"status": "ok", "applied": next_applied}
    except HTTPException:
        raise
    except Exception as exc:
        db.rollback()
        logger.error(f"[MatchingRouter] Toggle applied failed for candidate {unique_id}, job {job_id}: {exc}")
        raise HTTPException(status_code=500, detail="Failed to toggle applied status.")
