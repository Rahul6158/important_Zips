from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
import io
import os
import docx
import tempfile
from pathlib import Path
from app.dependencies import check_api_key, get_db
from services.tailoring.service import tailor_resume, tailor_resume_json
from sqlalchemy.orm import Session
from app.repositories import candidate_repository
from app.services import azure_service
from app.config import get_settings
from services.resume_formatter.config.settings import Settings as FormatterSettings
from services.resume_formatter.generation.resume_docx_generator import ResumeDocxGenerator
from services.resume_formatter.schemas.resume_schema import ResumeContent

router = APIRouter(tags=["Tailoring"], dependencies=[Depends(check_api_key)])

class TailorRequest(BaseModel):
    resume_text: str
    job_description: str
    candidate_name: Optional[str] = None
    candidate_id: Optional[str] = None
    job_id: Optional[str] = None

class SaveTailoredRequest(BaseModel):
    tailored_text: str
    filename: Optional[str] = "tailored_resume.docx"

@router.post("/tailor")
async def tailor_resume_endpoint(
    request: TailorRequest,
    db: Session = Depends(get_db)
):
    try:
        candidate = None
        has_formatted = False
        if request.candidate_id:
            candidate = candidate_repository.get_candidate_by_id(db, request.candidate_id)
            if candidate and candidate.formatted_resume_content:
                has_formatted = True

        if has_formatted:
            # Let's perform structured JSON tailoring
            result = tailor_resume_json(
                resume_content_dict=candidate.formatted_resume_content,
                job_description=request.job_description,
                candidate_name=request.candidate_name or f"{candidate.first_name} {candidate.last_name}",
            )
            
            # Generate premium formatted DOCX using ResumeDocxGenerator
            settings = FormatterSettings()
            settings.generated_resume_dir = Path(tempfile.gettempdir()) / "konfigai-candidate-formatted-resumes"
            docx_generator = ResumeDocxGenerator(settings)
            
            resume_content = ResumeContent.model_validate(result["tailored_json"])
            
            artifact = docx_generator.generate(
                record_id=request.candidate_id,
                source_file_name="tailored_resume.docx",
                resume_content=resume_content
            )
            
            # Read generated document bytes
            with open(artifact.file_path, "rb") as f:
                file_bytes = f.read()
                
            # Upload to Azure Storage
            app_settings = get_settings()
            blob_client = azure_service.get_blob_service_client()
            container_name = app_settings.azure_container_name
            
            # 1. Job-specific tailored resume path
            filename_job = f"tailored_resume_{request.job_id}.docx" if request.job_id else "tailored_resume.docx"
            blob_name_job = f"{app_settings.azure_formatted_resume_path}{request.candidate_id}/{filename_job}"
            blob_target_job = blob_client.get_blob_client(container=container_name, blob=blob_name_job)
            
            from azure.storage.blob import ContentSettings
            content_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            
            blob_target_job.upload_blob(file_bytes, overwrite=True, content_settings=ContentSettings(content_type=content_type))
            
            # 2. General/fallback tailored resume path (so other generic accesses work)
            blob_name_generic = f"{app_settings.azure_formatted_resume_path}{request.candidate_id}/tailored_resume.docx"
            blob_target_generic = blob_client.get_blob_client(container=container_name, blob=blob_name_generic)
            blob_target_generic.upload_blob(file_bytes, overwrite=True, content_settings=ContentSettings(content_type=content_type))
            
            # Cleanup temp file
            try:
                os.remove(artifact.file_path)
            except OSError:
                pass
                
            # Invalidate cache
            from app.cache.redis_client import cache
            cache.delete_pattern(f"sas:{request.candidate_id}:*")
            
            # Add dynamic field to result to indicate that high-fidelity DOCX is generated
            result["docx_saved"] = True
            result["filename"] = filename_job
            result["blob_name"] = blob_name_job
        else:
            # Fallback to plain text tailoring
            result = tailor_resume(
                resume_text=request.resume_text,
                job_description=request.job_description,
                candidate_name=request.candidate_name,
            )
            result["docx_saved"] = False
            
        return result
    except Exception as e:
        import traceback
        traceback.print_exc()
        print("TAILOR ERROR:", str(e))
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/candidates/{unique_id}/tailored-resume")
async def save_tailored_resume(
    unique_id: str,
    request: SaveTailoredRequest,
    db: Session = Depends(get_db),
    _ = Depends(check_api_key)
):
    try:
        candidate = candidate_repository.get_candidate_by_id(db, unique_id)
        if not candidate:
            raise HTTPException(status_code=404, detail="Candidate not found.")

        # Create a DOCX from the tailored text
        doc = docx.Document()
        
        # Split text into paragraphs and add to Word document
        text = request.tailored_text.replace("\r", "")
        paragraphs = text.split("\n")
        
        for p_text in paragraphs:
            p_text_stripped = p_text.strip()
            if not p_text_stripped:
                doc.add_paragraph()
                continue
                
            # Handle headers from markdown
            if p_text_stripped.startswith("### "):
                p = doc.add_paragraph()
                run = p.add_run(p_text_stripped[4:])
                run.bold = True
                run.font.size = docx.shared.Pt(14)
            elif p_text_stripped.startswith("## "):
                p = doc.add_paragraph()
                run = p.add_run(p_text_stripped[3:])
                run.bold = True
                run.font.size = docx.shared.Pt(16)
            elif p_text_stripped.startswith("# "):
                p = doc.add_paragraph()
                run = p.add_run(p_text_stripped[2:])
                run.bold = True
                run.font.size = docx.shared.Pt(18)
            elif p_text_stripped.startswith("**") and p_text_stripped.endswith("**"):
                p = doc.add_paragraph()
                run = p.add_run(p_text_stripped.replace("**", ""))
                run.bold = True
            else:
                doc.add_paragraph(p_text)
                
        # Save DOCX to a byte stream
        file_stream = io.BytesIO()
        doc.save(file_stream)
        file_stream.seek(0)
        file_bytes = file_stream.read()
        
        # Upload to Azure Storage
        settings = get_settings()
        blob_client = azure_service.get_blob_service_client()
        
        filename = request.filename or "tailored_resume.docx"
        if not filename.endswith(".docx"):
            filename = filename.split(".")[0] + ".docx"
            
        blob_name = f"{settings.azure_formatted_resume_path}{unique_id}/{filename}"
        
        container_name = settings.azure_container_name
        blob_target = blob_client.get_blob_client(container=container_name, blob=blob_name)
        
        from azure.storage.blob import ContentSettings
        content_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        blob_target.upload_blob(file_bytes, overwrite=True, content_settings=ContentSettings(content_type=content_type))
        
        # Invalidate local caches
        from app.cache.redis_client import cache
        cache.delete_pattern("candidates_v5:*")
        cache.delete_pattern("candidates_v6:*")
        cache.delete_pattern("candidates_v7:*")
        cache.delete_pattern(f"sas:{unique_id}:*")
        
        return {
            "status": "ok",
            "message": "Tailored resume saved successfully",
            "blob_name": blob_name,
            "filename": filename
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/candidates/{unique_id}/tailored-resume/{job_id}")
def delete_tailored_resume(
    unique_id: str,
    job_id: str,
    db: Session = Depends(get_db),
    _ = Depends(check_api_key)
):
    try:
        candidate = candidate_repository.get_candidate_by_id(db, unique_id)
        if not candidate:
            raise HTTPException(status_code=404, detail="Candidate not found.")

        app_settings = get_settings()
        blob_client = azure_service.get_blob_service_client()
        container_name = app_settings.azure_container_name
        
        # 1. Delete job-specific tailored resume
        filename_job = f"tailored_resume_{job_id}.docx"
        blob_name_job = f"{app_settings.azure_formatted_resume_path}{unique_id}/{filename_job}"
        blob_target_job = blob_client.get_blob_client(container=container_name, blob=blob_name_job)
        if blob_target_job.exists():
            blob_target_job.delete_blob()
            
        # 2. Also try deleting the generic tailored_resume.docx
        blob_name_generic = f"{app_settings.azure_formatted_resume_path}{unique_id}/tailored_resume.docx"
        blob_target_generic = blob_client.get_blob_client(container=container_name, blob=blob_name_generic)
        if blob_target_generic.exists():
            try:
                blob_target_generic.delete_blob()
            except Exception:
                pass
            
        # Invalidate local caches
        from app.cache.redis_client import cache
        cache.delete_pattern("candidates_v5:*")
        cache.delete_pattern("candidates_v6:*")
        cache.delete_pattern("candidates_v7:*")
        cache.delete_pattern(f"sas:{unique_id}:*")
        
        return {
            "status": "ok",
            "message": "Tailored resume deleted successfully"
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/candidates/{unique_id}/tailored-resumes/{filename}")
def delete_specific_tailored_resume(
    unique_id: str,
    filename: str,
    db: Session = Depends(get_db),
    _ = Depends(check_api_key)
):
    try:
        candidate = candidate_repository.get_candidate_by_id(db, unique_id)
        if not candidate:
            raise HTTPException(status_code=404, detail="Candidate not found.")

        # Ensure the filename is safe and only deletes tailored resumes
        if not filename.startswith("tailored_resume") or not filename.endswith(".docx") or "/" in filename or "\\" in filename:
            raise HTTPException(status_code=400, detail="Invalid filename for tailored resume.")

        app_settings = get_settings()
        blob_client = azure_service.get_blob_service_client()
        container_name = app_settings.azure_container_name
        
        blob_name = f"{app_settings.azure_formatted_resume_path}{unique_id}/{filename}"
        blob_target = blob_client.get_blob_client(container=container_name, blob=blob_name)
        
        if blob_target.exists():
            blob_target.delete_blob()
            
        return {
            "status": "ok",
            "message": f"Deleted {filename} successfully"
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/candidates/{unique_id}/tailored-resumes")
def list_tailored_resumes(
    unique_id: str,
    db: Session = Depends(get_db),
    _ = Depends(check_api_key)
):
    try:
        candidate = candidate_repository.get_candidate_by_id(db, unique_id)
        if not candidate:
            raise HTTPException(status_code=404, detail="Candidate not found.")

        app_settings = get_settings()
        blob_client = azure_service.get_blob_service_client()
        container_client = blob_client.get_container_client(app_settings.azure_container_name)
        
        prefix = f"{app_settings.azure_formatted_resume_path}{unique_id}/"
        resumes = []
        
        # We need to filter blobs that start with 'tailored_resume'
        for blob in container_client.list_blobs(name_starts_with=prefix):
            filename = blob.name.replace(prefix, "")
            if filename.startswith("tailored_resume") and filename.endswith(".docx"):
                # Construct job_id from filename (tailored_resume_{job_id}.docx)
                # or empty string for generic tailored_resume.docx
                job_id = ""
                if filename != "tailored_resume.docx":
                    parts = filename.replace("tailored_resume_", "").replace(".docx", "")
                    job_id = parts
                    
                resumes.append({
                    "filename": filename,
                    "job_id": job_id,
                    "last_modified": blob.last_modified.isoformat() if blob.last_modified else None,
                    "size": blob.size,
                    "blob_name": blob.name
                })
                
        # Sort by last_modified descending
        resumes.sort(key=lambda x: x.get("last_modified") or "", reverse=True)
        
        return {
            "status": "ok",
            "resumes": resumes
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))