import os
import sys
import asyncio
from dotenv import load_dotenv

# Add backend directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()

from services.matching.matching_integration import run_candidate_matching

async def main():
    unique_id = '58266384320437897326'
    try:
        print(f"Running candidate matching for {unique_id}...")
        res = await run_candidate_matching(unique_id, persist=True)
        print("Matching complete!")
        print("Stored results:", res.get("stored_results"))
        print("Persistence block:", res.get("matcher_response", {}).get("persistence"))
        print("Tailoring block:", res.get("matcher_response", {}).get("tailoring"))
    except Exception as e:
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
