import sys
import os
from dotenv import load_dotenv

# Ensure we can import from backend
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()

from services.matching.matching_integration import DBManager
from sqlalchemy import text

def check_runs():
    dm = DBManager()
    
    # 1. Let's find Tusha Rahul Bellamkonda
    print("--- Candidate Tusha Rahul Bellamkonda ---")
    q_cand = text("SELECT unique_id, first_name, last_name, skill_set FROM candidate_details.candidate_basic_info WHERE first_name LIKE '%Tusha%' OR last_name LIKE '%Bellamkonda%'")
    cands = dm.session.execute(q_cand).mappings().all()
    for c in cands:
        print(f"ID: {c['unique_id']} | Name: {c['first_name']} {c['last_name']} | Skills: {c['skill_set']}")
        unique_id = c['unique_id']
        
        # 2. Get match runs for this candidate
        print("\n--- Match Runs for this candidate ---")
        q_runs = text("SELECT match_run_id, resume_id, source_resume_ref, matcher_version, top_k, created_at FROM candidate_details.candidate_match_runs WHERE source_resume_ref = :uid ORDER BY created_at DESC")
        runs = dm.session.execute(q_runs, {"uid": unique_id}).mappings().all()
        for r in runs:
            print(f"Run ID: {r['match_run_id']} | Created: {r['created_at']} | Top K: {r['top_k']}")
            
            # 3. Get results for this run
            q_res = text("SELECT job_id, rank, match_score, applied FROM candidate_details.candidate_match_results WHERE match_run_id = :rid ORDER BY rank")
            res = dm.session.execute(q_res, {"rid": r['match_run_id']}).mappings().all()
            print(f"   Results ({len(res)} total):")
            for result in res:
                print(f"      Job ID: {result['job_id']} | Rank: {result['rank']} | Score: {result['match_score']} | Applied: {result['applied']}")
                
        # 4. Run the stats query exactly as written in candidates.py to see what it returns
        print("\n--- Running Candidates Stats Query ---")
        q_stats = text("""
            with latest_runs as (
                select distinct on (source_resume_ref)
                    match_run_id,
                    source_resume_ref
                from "candidate_details"."candidate_match_runs"
                order by source_resume_ref, created_at desc, match_run_id desc
            )
            select
                lr.source_resume_ref as candidate_id,
                count(distinct res.job_id) as matched_count,
                sum(case when res.applied = true then 1 else 0 end) as applied_count
            from latest_runs lr
            join "candidate_details"."candidate_match_results" res
              on res.match_run_id = lr.match_run_id
            where lr.source_resume_ref = :uid
            group by lr.source_resume_ref
        """)
        stats = dm.session.execute(q_stats, {"uid": unique_id}).mappings().all()
        for st in stats:
            print(f"Stats Result -> matched_count: {st['matched_count']}, applied_count: {st['applied_count']}")

if __name__ == "__main__":
    check_runs()
