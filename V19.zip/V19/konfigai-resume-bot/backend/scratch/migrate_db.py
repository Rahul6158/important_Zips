import sys
import os
import traceback
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# Ensure we can import from backend
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()

def main():
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        host = os.getenv("DB_HOST")
        port = os.getenv("DB_PORT", "5432")
        name = os.getenv("DB_NAME")
        user = os.getenv("DB_USER")
        password = os.getenv("DB_PASS")
        db_url = f"postgresql://{user}:{password}@{host}:{port}/{name}"
    
    engine = create_engine(db_url)
    schema = os.getenv("CANDIDATE_SCHEMA", "candidate_details")
    
    print(f"Connecting to database: {host if 'host' in locals() else 'configured host'}")
    
    queries = [
        f'ALTER TABLE "{schema}"."candidate_match_results" ADD COLUMN IF NOT EXISTS applied boolean not null default false',
        f'ALTER TABLE "{schema}"."candidate_match_jobs" ADD COLUMN IF NOT EXISTS vendor text'
    ]
    
    with engine.connect() as conn:
        # PostgreSQL transaction block
        trans = conn.begin()
        try:
            for q in queries:
                print(f"Running query: {q}")
                conn.execute(text(q))
            trans.commit()
            print("Migration completed successfully!")
        except Exception as e:
            trans.rollback()
            print("Migration failed:")
            traceback.print_exc()

if __name__ == "__main__":
    main()
