import os
import sys
from dotenv import load_dotenv

# Add backend directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()

from database import DBManager
from sqlalchemy import text

dm = DBManager()
try:
    # 1. Check if candidate exists
    cand = dm.session.execute(text("select unique_id, first_name, last_name, email from candidate_details.candidate_basic_info where unique_id = '58266384320437897326'")).fetchone()
    print("Candidate:", cand)

    # 2. Check formatting status
    fmt = dm.session.execute(text("select unique_id, formatted_resume_status from candidate_details.formatting_resume_info where unique_id = '58266384320437897326'")).fetchone()
    print("Formatting Info:", fmt)

    # 3. Check match runs
    runs = dm.session.execute(text("select * from candidate_details.candidate_match_runs where source_resume_ref = '58266384320437897326'")).fetchall()
    print(f"Match Runs ({len(runs)}):")
    for r in runs:
        print("Run:", dict(r._mapping))

    # 4. Check match results for the latest run
    if runs:
        latest_run_id = runs[-1][0]
        results = dm.session.execute(text("select * from candidate_details.candidate_match_results where match_run_id = :run_id"), {"run_id": latest_run_id}).fetchall()
        print(f"Match Results for run {latest_run_id} ({len(results)}):")
        for res in results[:5]:
            print("Result:", dict(res._mapping))
    else:
        print("No match runs found.")
finally:
    dm.close()
