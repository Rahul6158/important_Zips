import sys
import os
import traceback
from dotenv import load_dotenv

# Ensure we can import from backend
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

load_dotenv()

from services.matching.matching_integration import DBManager, MATCH_RUNS_TABLE, MATCH_RESULTS_TABLE, MATCH_JOBS_TABLE, _quote_identifier, _clamp_positive_int
from sqlalchemy import text

def debug_no_catch(unique_id: str, limit: int = 5):
    safe_limit = _clamp_positive_int(limit, 5, maximum=50)
    dm = DBManager()
    
    # First query
    print("Executing first query...")
    q1 = text(
        f"""
        select
            match_run_id::text as match_run_id,
            resume_id::text as resume_id,
            source_resume_ref,
            matcher_version,
            top_k,
            created_at
        from {_quote_identifier(MATCH_RUNS_TABLE, 'MATCH_RUNS_TABLE')}
        where source_resume_ref = :unique_id
        order by created_at desc, match_run_id desc
        limit 1
        """
    )
    latest_run = dm.session.execute(q1, {"unique_id": unique_id}).mappings().first()
    print("latest_run:", latest_run)
    if not latest_run:
        return
    
    # Second query
    print("Executing second query...")
    q2 = text(
        f"""
        select
            results.rank,
            results.match_score,
            results.ats_score,
            results.eligible,
            results.summary,
            results.strengths_json,
            results.gaps_json,
            results.tailoring_hints_json,
            results.breakdown_json,
            results.applied,
            jobs.job_id::text as job_id,
            jobs.source_job_ref,
            jobs.source_table,
            jobs.source,
            jobs.title,
            jobs.company_name,
            jobs.location,
            jobs.url,
            jobs.description_text,
            jobs.normalized_jd_text,
            jobs.vendor
        from {_quote_identifier(MATCH_RESULTS_TABLE, 'MATCH_RESULTS_TABLE')} results
        join {_quote_identifier(MATCH_JOBS_TABLE, 'MATCH_JOBS_TABLE')} jobs
          on jobs.job_id = results.job_id
        where results.match_run_id = cast(:match_run_id as uuid)
        order by results.rank asc
        limit :limit
        """
    )
    rows = dm.session.execute(q2, {"match_run_id": latest_run["match_run_id"], "limit": safe_limit}).mappings().all()
    print(f"Retrieved {len(rows)} rows.")

def main():
    candidate_id = "32716913502880597090" # Ayush Kumar Giri
    print(f"Debugging candidate matches for candidate_id: {candidate_id}")
    try:
        debug_no_catch(candidate_id)
    except Exception as e:
        print("EXCEPTION IN RAW QUERIES:")
        traceback.print_exc()

if __name__ == "__main__":
    main()
