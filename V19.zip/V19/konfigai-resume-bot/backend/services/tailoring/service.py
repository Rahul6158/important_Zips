import os
from groq import Groq
from sentence_transformers import SentenceTransformer, util

MODEL_NAME = "llama-3.3-70b-versatile"
_encoder = None

def _get_encoder():
    global _encoder
    if _encoder is None:
        _encoder = SentenceTransformer("all-MiniLM-L6-v2")
    return _encoder

def compute_match_score(resume_text: str, job_description: str) -> float:
    encoder = _get_encoder()
    emb_resume = encoder.encode(resume_text, convert_to_tensor=True)
    emb_job = encoder.encode(job_description, convert_to_tensor=True)
    score = float(util.cos_sim(emb_resume, emb_job)[0][0]) * 100
    return round(score, 2)

def tailor_resume(resume_text: str, job_description: str, candidate_name: str = None) -> dict:
    client = Groq(
        api_key=os.environ.get("GROQ_API_KEY"),
        base_url="https://api.groq.com"
    )

    prompt = f"""You are an expert resume tailor. Rewrite the resume below to better match the job description while keeping all facts accurate.

CANDIDATE NAME: {candidate_name or "EMPLOYEE"}

ORIGINAL RESUME:
{resume_text}

JOB DESCRIPTION:
{job_description}

Instructions:
1. Highlight relevant skills and experience for this job
2. Use keywords from the job description naturally
3. Do NOT fabricate any experience
4. Keep professional tone
5. Add a "What Was Changed" section at the end listing key modifications

Return ONLY the tailored resume text."""

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=4000,
        temperature=0.3,
    )

    tailored = response.choices[0].message.content.strip()
    score_after = compute_match_score(tailored, job_description)

    return {
        "tailored_resume": tailored,
        "match_score": score_after,
        "ats_score": score_after,
        "model_used": MODEL_NAME,
    }

def tailor_resume_json(resume_content_dict: dict, job_description: str, candidate_name: str = None) -> dict:
    import json
    client = Groq(
        api_key=os.environ.get("GROQ_API_KEY"),
        base_url="https://api.groq.com"
    )

    candidate_json_str = json.dumps(resume_content_dict, indent=2)

    prompt = f"""You are an expert resume tailor. Rewrite the resume sections in the JSON below to better match the job description while keeping all facts (like companies, dates, universities, and degrees) 100% accurate.

CANDIDATE JSON:
{candidate_json_str}

JOB DESCRIPTION:
{job_description}

Instructions:
1. Rewrite the "Summary" to highlight the candidate's experience relevant to the job.
2. In "Technical_Skills", you may re-categorize or prioritize skills, but do not invent new skills that the candidate does not have.
3. In "Professional_Experience", rewrite the "project_description" and "Responsibilities" bullets to emphasize relevant accomplishments using job description keywords naturally, without making up achievements or fabricating experience. Keep "Company", "location", "title", "dates_of_employment" exactly the same.
4. In "Academic_projects", rewrite the "project_responsibilities" if needed to highlight relevant academic work.
5. Leave "Name", "Phone", "Email", "Academics", "certifications" exactly as they are.
6. The output MUST be a valid JSON object matching the input schema exactly. Return ONLY the JSON object. Do not include markdown formatting or explanations outside the JSON.

Return ONLY the JSON object matching the schema."""

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": "You are an expert resume parser and tailor. Return only valid JSON matching the requested schema. Do not include markdown or explanations outside the JSON object."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=6000,
        temperature=0.3,
    )

    raw_output = response.choices[0].message.content.strip()
    
    # Extract the JSON payload
    from services.resume_formatter.extraction.llm_resume_extractor import _extract_json_object
    try:
        tailored_json = _extract_json_object(raw_output)
    except Exception as e:
        print("FAILED TO PARSE TAILORED JSON, RETRYING PARSE FROM STRIP:", str(e))
        cleaned = raw_output
        if "```" in cleaned:
            cleaned = cleaned.split("```")[1]
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
        tailored_json = json.loads(cleaned.strip())

    # Build a plain text version for match scoring and display compatibility
    lines = []
    if tailored_json.get("Name"):
        lines.append(tailored_json["Name"])
    if tailored_json.get("Phone") or tailored_json.get("Email"):
        lines.append(f"{tailored_json.get('Phone', '')} | {tailored_json.get('Email', '')}")
    if tailored_json.get("Summary"):
        lines.append(f"\nSUMMARY:\n{tailored_json['Summary']}")
    if tailored_json.get("Academics"):
        lines.append("\nEDUCATION:")
        for ac in tailored_json["Academics"]:
            parts = [ac.get("Degree"), ac.get("Major"), ac.get("University")]
            lines.append(" - ".join(p for p in parts if p))
    if tailored_json.get("Technical_Skills"):
        lines.append("\nTECHNICAL SKILLS:")
        for cat, skills in tailored_json["Technical_Skills"].items():
            if skills:
                lines.append(f"- {cat}: {', '.join(skills)}")
    if tailored_json.get("Professional_Experience"):
        lines.append("\nPROFESSIONAL EXPERIENCE:")
        for exp in tailored_json["Professional_Experience"]:
            parts = [exp.get("Company"), exp.get("location")]
            lines.append(" — ".join(p for p in parts if p))
            lines.append(f"{exp.get('title', '')} | {exp.get('dates_of_employment', '')}")
            if exp.get("project_description"):
                lines.append(exp["project_description"])
            if exp.get("Responsibilities"):
                for r in exp["Responsibilities"]:
                    lines.append(f"- {r}")
            if exp.get("Environment"):
                lines.append(f"Environment: {', '.join(exp['Environment'])}")
    if tailored_json.get("Academic_projects"):
        lines.append("\nACADEMIC PROJECTS:")
        for proj in tailored_json["Academic_projects"]:
            lines.append(proj.get("project_name", ""))
            if proj.get("your_title"):
                lines.append(proj["your_title"])
            if proj.get("project_responsibilities"):
                for r in proj["project_responsibilities"]:
                    lines.append(f"- {r}")
            if proj.get("Technologies_used"):
                lines.append(f"Technologies: {', '.join(proj['Technologies_used'])}")
    if tailored_json.get("certifications"):
        lines.append("\nCERTIFICATIONS:")
        for cert in tailored_json["certifications"]:
            lines.append(f"- {cert}")

    tailored_text_formatted = "\n".join(lines)
    score_after = compute_match_score(tailored_text_formatted, job_description)

    return {
        "tailored_resume": tailored_text_formatted,
        "tailored_json": tailored_json,
        "match_score": score_after,
        "ats_score": score_after,
        "model_used": MODEL_NAME,
    }