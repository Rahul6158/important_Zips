from dataclasses import dataclass
from string import punctuation

import phonenumbers
from email_validator import EmailNotValidError, validate_email


DEFAULT_PHONE_REGION = "US"
INTERNATIONAL_ONLY_REGION = "ZZ"
EMAIL_STRIP_CHARS = "".join(char for char in punctuation if char not in "@._+-")


@dataclass(frozen=True)
class ContactExtractionResult:
    phone: str = ""
    email: str = ""


def extract_contact_details(text: str) -> ContactExtractionResult:
    return ContactExtractionResult(
        phone=extract_phone_number(text),
        email=extract_email_address(text),
    )


def extract_phone_number(text: str, default_region: str = DEFAULT_PHONE_REGION) -> str:
    if not text:
        return ""

    for region in (INTERNATIONAL_ONLY_REGION, default_region):
        for match in phonenumbers.PhoneNumberMatcher(
            text,
            region,
            leniency=phonenumbers.Leniency.VALID,
        ):
            number = match.number
            if not phonenumbers.is_valid_number(number):
                continue

            return phonenumbers.format_number(
                number,
                phonenumbers.PhoneNumberFormat.E164,
            )

    return ""


def extract_email_address(text: str) -> str:
    if not text:
        return ""

    for token in text.split():
        candidate = token.strip(EMAIL_STRIP_CHARS)
        if "@" not in candidate:
            continue

        normalized = normalize_email(candidate)
        if normalized:
            return normalized

    return ""


def normalize_phone_number(
    value: str,
    default_region: str = DEFAULT_PHONE_REGION,
) -> str:
    if not value:
        return ""

    for region in (INTERNATIONAL_ONLY_REGION, default_region):
        try:
            parsed = phonenumbers.parse(value, region)
        except phonenumbers.NumberParseException:
            continue

        if not phonenumbers.is_valid_number(parsed):
            continue

        return phonenumbers.format_number(
            parsed,
            phonenumbers.PhoneNumberFormat.E164,
        )

    return ""


def normalize_email(value: str) -> str:
    if not value:
        return ""

    try:
        validated = validate_email(
            value,
            check_deliverability=False,
        )
    except EmailNotValidError:
        return ""

    return validated.normalized
