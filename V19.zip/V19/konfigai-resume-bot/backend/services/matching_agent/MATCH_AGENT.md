# Matching Agent — `MATCH_AGENT.md`

> End-to-end pipeline that finds the most relevant active job postings for each
> candidate and produces a ranked list with per-job scores, strengths, and gaps.

---

## Table of Contents

1. [What It Does](#1-what-it-does)
2. [Architecture Overview](#2-architecture-overview)
3. [Pipeline — Stage by Stage](#3-pipeline--stage-by-stage)
   - [Stage 1 — Resume Normalizer](#stage-1--resume-normalizer)
   - [Stage 2A — Title Expander](#stage-2a--title-expander)
   - [Stage 2B — SQL Job Filter](#stage-2b--sql-job-filter)
   - [Stage 3A — Hybrid Scorer (BM25 + Embeddings)](#stage-3a--hybrid-scorer-bm25--embeddings)
   - [Stage 3B — LLM Deep Scorer](#stage-3b--llm-deep-scorer)
4. [Embedding Cache (pgvector)](#4-embedding-cache-pgvector)
5. [Persistence Layer](#5-persistence-layer)
6. [API Endpoints](#6-api-endpoints)
7. [File Map](#7-file-map)
8. [Algorithms & Scoring Details](#8-algorithms--scoring-details)
9. [Trade-offs & Design Decisions](#9-trade-offs--design-decisions)
10. [Running & Testing](#10-running--testing)

---

## 1. What It Does

Given a candidate with a completed formatted resume, the matching agent:

1. Parses the resume into a **recency-weighted skill profile**
2. Expands the candidate's job title into **10–12 synonymous titles** (LLM)
3. **Pre-filters** the active job pool to jobs scraped in the last 3 days whose titles match any variant
4. **Ranks** those jobs using a hybrid BM25 + semantic embedding score
5. Sends the top 30 to Groq for **structured LLM scoring** (must-have skills, nice-to-have skills, title alignment)
6. **Persists** the top 20 results with per-job strengths and gaps back to the DB
7. **Exposes results** via two REST endpoints consumed by the frontend drawer

A full run for one candidate takes **30–45 seconds** (dominated by the 20 concurrent Groq calls in Stage 3B).

---

## 2. Architecture Overview

```
Candidate resume (formatted JSON)
         │
         ▼
┌─────────────────────┐
│  Stage 1            │  normalizer.py
│  Resume Normalizer  │  → CandidateProfile
│  (recency-weighted  │    .current_title
│   skill extraction) │    .weighted_skills  (dict: skill → weight)
│                     │    .top_skills       (top 15 by weight)
│                     │    .resume_text      (flat string for embedding)
└─────────┬───────────┘
          │ CandidateProfile
          ▼
┌─────────────────────┐
│  Stage 2A           │  title_expander.py
│  Title Expander     │  → list[str]  e.g.
│  (Groq → OpenAI     │    ["Lead AI Engineer",
│   fallback, cached) │     "Senior AI Engineer",
│                     │     "AI/ML Engineer", ...]
└─────────┬───────────┘
          │ expanded_titles (12 variants)
          ▼
┌─────────────────────┐
│  Stage 2B           │  job_filter.py
│  SQL Pre-filter     │  → list[JobRecord]
│  title ILIKE ANY    │
│  scraped in last 3d │  typically 20–300 jobs
└─────────┬───────────┘
          │ filtered jobs
          ▼
┌─────────────────────┐
│  Stage 3A           │  semantic_scorer.py
│  Hybrid Scorer      │  BM25 (α=0.40) + cosine embedding (β=0.60)
│  BM25 + Embeddings  │  → top 30 JobRecords, .semantic_score set
│  (pgvector cache)   │
└─────────┬───────────┘
          │ top 30 jobs
          ▼
┌─────────────────────┐
│  Stage 3B           │  llm_scorer.py
│  LLM Deep Scorer    │  Groq llama-3.3-70b (async, 5 concurrent)
│  (Groq, structured  │  → list[JobMatchResult]
│   JSON per job)     │    .overall_score, .must_have_score
│                     │    .nice_to_have_score, .title_match
│                     │    .strengths[], .gaps[]
└─────────┬───────────┘
          │ top 20 results
          ▼
┌─────────────────────┐
│  Persistence        │  service.py → _persist()
│  DELETE + INSERT    │  candidate_details.candidate_job_matches
│  (replace on run)   │
└─────────────────────┘
```

---

## 3. Pipeline — Stage by Stage

### Stage 1 — Resume Normalizer

**File:** `normalizer.py`  
**Input:** `formatted_resume_content` (JSON stored in `formatting_resume_info`)  
**Output:** `CandidateProfile`

#### What it does

Converts the structured resume JSON into a flat, ML-ready profile. The most important output is `weighted_skills` — a dict where every skill the candidate has ever used is assigned a weight that reflects **how recently it was used**.

#### Weight Scheme

| Source | Weight |
|--------|--------|
| Most recent job — `Environment` field | **1.0** |
| 2nd most recent job — `Environment` | **0.8** |
| 3rd most recent job — `Environment` | **0.6** |
| 4th+ jobs — `Environment` | **0.4** |
| Responsibilities (keyword extraction) | exp_weight × **0.7** |
| `Technical_Skills` section | **0.7** (max with above) |
| Certifications | **0.9** |
| Academic Projects — `Technologies_used` | **0.5** |

> **Why recency weighting?** A candidate who used Python 5 years ago and hasn't touched it since should score lower for a Python job than one actively using it today. Flat skill presence/absence ignores this signal entirely.

#### resume_text (for embedding)

A flat string assembled from:
```
{Name} — {title} | {Summary} | Skills: {top_skills} | {exp snippets} | Certifications: {certs}
```
Capped at 4000 characters — the all-MiniLM-L6-v2 model has a 256-token context window; beyond ~500 words the embedding starts to average out anyway.

---

### Stage 2A — Title Expander

**File:** `title_expander.py`  
**Input:** `profile.current_title` (e.g. `"Lead AI Engineer"`)  
**Output:** list of 10–12 related titles

#### Why title expansion?

A candidate with title `"Lead AI Engineer"` is equally qualified for postings labelled `"Senior ML Engineer"`, `"AI/ML Tech Lead"`, or `"Principal Deep Learning Engineer"`. The job scraper captures whatever title the employer chose. Without expansion, a strict title match misses most relevant jobs.

#### Provider chain

```
1. Groq  llama-3.3-70b-versatile  (fast, cheap, primary)
         ↓ on failure / 429
2. OpenAI gpt-4o-mini              (fallback)
         ↓ on failure
3. [original title only]           (last resort, NOT cached)
```

**Temperature = 0** for deterministic, consistent results.

#### Cache behaviour

- **Successful** results are cached in a module-level dict keyed by normalised title (lowercased, collapsed whitespace). One LLM call per unique title per process lifetime.
- **Failures are never cached.** If Groq rate-limits and OpenAI also fails, only `[original_title]` is returned and nothing is written to the cache. The next run retries both providers fresh. This prevents a transient rate-limit event from permanently degrading search quality.

#### Prompt design

The prompt explicitly requests:
1. The original title as element 0
2. Seniority variants (Junior / Senior / Lead / Principal / Staff)
3. Acronym equivalents (ML = Machine Learning, NLP, LLM, etc.)
4. Adjacent specialist roles in the same domain
5. Max 2–6 words per title
6. No managerial or completely unrelated roles

Response parsed as bare JSON array; markdown code fences stripped before parsing.

---

### Stage 2B — SQL Job Filter

**File:** `job_filter.py`  
**Input:** expanded titles list  
**Output:** list[JobRecord] — up to 300 jobs

#### Query design

```sql
SELECT serial_no, title, company, location, url,
       description, skills, job_type, workplace_type, scraped_at
FROM   scrapped_data.active_scraped_data
WHERE  scraped_at >= NOW() - INTERVAL '3 days'
  AND  (title ILIKE :t0 OR title ILIKE :t1 OR ... OR title ILIKE :t11)
ORDER  BY scraped_at DESC
LIMIT  300
```

- **ILIKE `%term%`** — case-insensitive substring match. `%Senior AI Engineer%` catches `"Senior AI Engineer, New York"` and similar padded titles.
- **3-day window** — jobs older than 3 days are likely filled or no longer actively being recruited for. Reducing the pool also speeds up every downstream step.
- **300-row cap** — prevents a single extremely popular title variant from flooding the semantic scorer with thousands of low-quality matches.
- **Parameters are fully bound** — no string interpolation in the WHERE clause; safe from SQL injection even though the values come from an LLM.

---

### Stage 3A — Hybrid Scorer (BM25 + Embeddings)

**File:** `semantic_scorer.py`  
**Input:** CandidateProfile + list[JobRecord]  
**Output:** top 30 JobRecords with `.semantic_score` set

#### Why hybrid?

| Signal alone | Strength | Weakness |
|---|---|---|
| **Embeddings only** | Catches `"led teams"` ≈ `"people manager"` | Might score `"cloud infrastructure and backend scripting"` ABOVE a resume that says `"Python, AWS Lambda, PostgreSQL"` verbatim — semantic similarity ≠ keyword precision |
| **BM25 only** | Exact-match precision: `"AWS Lambda"` scores a job containing `"AWS Lambda"` | Misses valid synonyms; penalises resumes that use different but correct terminology |
| **Hybrid** | Gets both: keyword precision from BM25, semantic alignment from embeddings | Slightly more complex to tune |

#### BM25 signal (α = 0.40)

```
Corpus   : [tokenise(job.title + " " + job.skills)  for job in jobs]
Query    : tokenise(" ".join(profile.top_skills))    # top 15 skills by weight
Scorer   : BM25Okapi (rank_bm25 library)
Normalise: min-max → [0, 100]
```

- **Corpus is title + skills only** (not the full description). Job descriptions contain boilerplate (`"We are an equal opportunity employer..."`) that pollutes BM25's TF-IDF. Skills and title are dense signal.
- **Query is skills only** (not the full resume). The candidate's job title is already handled by Stage 2B; what differentiates candidates *within* the filtered pool is their skill match.
- `rank_bm25` is pure Python + numpy — zero extra heavy dependency since numpy is already present via sentence-transformers.

#### Embedding signal (β = 0.60)

```
Model    : all-MiniLM-L6-v2 (384-dimensional, L2-normalised)
Candidate: encoder.encode(profile.resume_text)       # pulled from pgvector cache
Jobs     : encoder.encode([title + skills + desc[:800]  for job in jobs])   # bulk, pulled from pgvector cache
Similarity: dot product (= cosine similarity on L2-normalised vectors)
Score    : dot_product × 100  →  [0, 100]
```

- **Full description included** for embedding (up to 800 chars) because semantic role fit benefits from context that the pure skills column misses.
- **Batch encoding** with `batch_size=64` — encodes all jobs in one GPU/MPS forward pass.
- **Embedding cache** prevents re-encoding on every run (see Section 4).

#### Hybrid formula

```
hybrid_score = (bm25_normalised × 0.40) + (embed_score × 0.60)
```

- **0.60 embedding weight** because within the already-title-filtered pool, semantic role fit is the primary differentiator. BM25 catches hard skill terms the embedding may compress away, but at 0.40 it doesn't override a strong semantic match.
- Top 30 sorted by `hybrid_score DESC` are forwarded to Stage 3B.

---

### Stage 3B — LLM Deep Scorer

**File:** `llm_scorer.py`  
**Input:** CandidateProfile + top 30 JobRecords  
**Output:** list[JobMatchResult] (top 20)

#### What it produces per job

```json
{
  "must_have_score":    75,
  "nice_to_have_score": 60,
  "title_match":        90,
  "overall_score":      76,
  "strengths": [
    "Active experience with PyTorch and Hugging Face from most recent role",
    "Demonstrated LLM fine-tuning experience aligns with JD requirement",
    "3 years lead engineering role matches seniority expectation"
  ],
  "gaps": [
    "No explicit MLOps / Kubernetes experience mentioned",
    "JD requires AWS Bedrock; candidate shows AWS Lambda only"
  ]
}
```

#### Scoring weights (enforced by the prompt)

```
overall_score = must_have × 0.60  +  nice_to_have × 0.25  +  title_match × 0.15
```

`must_have` carries 60% because a candidate missing core required skills is a poor match regardless of how well-rounded they are elsewhere.

#### Concurrency

All 30 scoring calls are launched simultaneously, bounded by `asyncio.Semaphore(5)`:
- **5 concurrent** Groq calls → ~3–4 batches of 5 → total latency ≈ 3 × avg_groq_latency
- Without the semaphore: all 30 fire at once → Groq rate-limit (429) on almost every call
- With semaphore(5): stays within the free-tier rate limit; latency ≈ 25–35 seconds

#### Fallback

If a Groq call fails (429, timeout, bad JSON), the job's `semantic_score` from Stage 3A is used as `overall_score` with empty strengths/gaps. The pipeline **never hard-fails** due to a single LLM call.

---

## 4. Embedding Cache (pgvector)

**File:** `embedding_cache.py`

### Why cache embeddings?

Without a cache:
- Every match run re-encodes the candidate's resume (~50 ms on CPU)
- Every match run re-encodes all 300 filtered jobs (~2–5 seconds for 300 docs)
- For 50 candidates × 300 jobs = 15,000 encode calls per daily batch

With cache:
- Candidate embedding computed **once per resume version** (re-computed only when the formatter re-processes the resume)
- Job embeddings computed **once per job** (shared across all candidate runs)
- Warm run: 0 model inference → pure DB lookup (1–5 ms)

### Two-layer architecture

```
Layer 1 — In-memory dict (process-scoped, zero-latency)
  _cand_mem: dict[candidate_id → (embedding, resume_version)]
  _job_mem:  dict[job_serial_no → embedding]

Layer 2 — pgvector table (warm, 1–5 ms, survives restarts)
  candidate_details.candidate_resume_embeddings
  candidate_details.job_embeddings
```

**Resolution order:** memory → DB → generate + store in both layers.

### Tables

```sql
-- Candidate embeddings
CREATE TABLE candidate_details.candidate_resume_embeddings (
    unique_id       CHAR(20)     PRIMARY KEY
                    REFERENCES   candidate_details.candidate_basic_info(unique_id)
                    ON DELETE CASCADE,
    embedding       vector(384)  NOT NULL,
    resume_version  TEXT         NOT NULL,   -- str(formatted_resume_processed_at)
    updated_at      TIMESTAMPTZ  DEFAULT NOW()
);

-- Job embeddings
CREATE TABLE candidate_details.job_embeddings (
    job_serial_no  INTEGER      PRIMARY KEY
                   REFERENCES   scrapped_data.active_scraped_data(serial_no)
                   ON DELETE CASCADE,
    embedding      vector(384)  NOT NULL,
    created_at     TIMESTAMPTZ  DEFAULT NOW()
);
```

### Staleness & cleanup

| Vector | Staleness key | Cleanup |
|--------|--------------|---------|
| Candidate | `resume_version = str(formatted_resume_processed_at)` — timestamp changes when formatter re-processes → triggers upsert with fresh embedding | Manual never needed; candidate row cascade-deletes if the candidate is removed |
| Job | Jobs never change after scraping; no versioning needed | **Automatic via FK CASCADE** — when a job moves from `active_scraped_data` to inactive, its embedding row is deleted automatically. No vacuum job needed. |

### Why pgvector over JSONB?

| Criterion | pgvector | JSONB |
|-----------|----------|-------|
| Automatic cleanup | ✅ FK CASCADE | ❌ Manual vacuum required |
| Type enforcement | ✅ `vector(384)` rejects wrong dims | ❌ Accepts anything |
| Storage | ~1.5 KB / vector (binary float32) | ~3 KB / vector (text) |
| Future server-side ANN search | ✅ `ORDER BY emb <=> query LIMIT 30` | ❌ Must pull all to Python |
| Extension available | ✅ Already installed | N/A |

---

## 5. Persistence Layer

**Table:** `candidate_details.candidate_job_matches`

| Column | Type | Notes |
|--------|------|-------|
| id | SERIAL PK | |
| candidate_id | CHAR(20) | FK → candidate_basic_info |
| job_serial_no | INTEGER | Original job ID |
| job_title | TEXT | Snapshot at match time |
| company, job_url, job_type, workplace_type, location, scraped_at | TEXT | Job metadata snapshot |
| rank | INTEGER | 1 = best match |
| overall_score | FLOAT | Weighted composite from LLM |
| must_have_score | FLOAT | Core required skills % |
| nice_to_have_score | FLOAT | Preferred qualifications % |
| title_match | FLOAT | Role / seniority alignment % |
| strengths | JSONB | `["...","...","..."]` |
| gaps | JSONB | `["...","...","..."]` |
| matched_at | TIMESTAMPTZ | Run timestamp |

**Replace-on-run semantics:** Each match run starts with `DELETE FROM … WHERE candidate_id = :cid`, then re-inserts the new top 20. This ensures the table always reflects the **latest 3-day window** and never accumulates stale results.

Indexes:
```sql
CREATE INDEX idx_cjm_candidate_id    ON candidate_job_matches (candidate_id);
CREATE INDEX idx_cjm_overall_score   ON candidate_job_matches (overall_score DESC);
```

---

## 6. API Endpoints

Both endpoints are in `app/routers/matching.py` and require the `X-API-Key` header.

### `GET /candidates/{unique_id}/matches`

Returns the stored match results from the last run.

**Response shape:**
```json
{
  "status": "ok",
  "candidate_id": "62900972756396522269",
  "jobs": [
    {
      "rank": 1,
      "overall_score": 76.0,
      "must_have_score": 75.0,
      "nice_to_have_score": 60.0,
      "title_match": 90.0,
      "strengths": ["...", "...", "..."],
      "gaps": ["...", "..."],
      "job": {
        "serial_no": 8172,
        "title": "Senior AI Engineer",
        "company": "Acme Corp",
        "url": "https://...",
        "job_type": "Contract W2",
        "workplace_type": "Hybrid",
        "location": "Austin, TX",
        "scraped_at": "2026-05-27 10:27:09"
      }
    }
  ],
  "matched_at": "2026-05-27T14:29:46+00:00",
  "total": 4
}
```

**Returns 200 with `jobs: []`** if no run has been done yet. Never 404 on missing results.

---

### `POST /candidates/{unique_id}/matches/run`

Triggers the full pipeline. Blocking — response arrives when all stages complete (~30–45 seconds). Suitable for the UI "Run matching now" button; for bulk runs a background task queue would be preferred.

**Prerequisites:**
- Candidate must exist in `candidate_basic_info`
- `formatted_resume_status` must be `'completed'`

**Error codes:**
- `400` — Resume not completed yet
- `404` — Candidate not found
- `500` — Pipeline error (full traceback in server log)

---

## 7. File Map

```
backend/services/matching_agent/
│
├── __init__.py           Public surface: run_matching(), get_matches()
├── models.py             Pydantic models: CandidateProfile, JobRecord,
│                         JobMatchResult, MatchRunResult
├── normalizer.py         Stage 1 — resume JSON → CandidateProfile
├── title_expander.py     Stage 2A — title → synonymous titles (Groq/OpenAI)
├── job_filter.py         Stage 2B — SQL pre-filter (ILIKE + 3-day window)
├── embedding_cache.py    pgvector two-layer embedding cache
├── semantic_scorer.py    Stage 3A — BM25 + embedding hybrid scoring
├── llm_scorer.py         Stage 3B — Groq structured LLM scoring (async)
├── service.py            Orchestrator + persistence layer
└── MATCH_AGENT.md        ← this file

backend/app/routers/
└── matching.py           FastAPI router — GET + POST /candidates/{id}/matches
```

---

## 8. Algorithms & Scoring Details

### BM25 (Okapi BM25)

BM25 is a bag-of-words retrieval function that scores documents against a query based on term frequency (TF) and inverse document frequency (IDF), with length normalisation.

```
score(D, Q) = Σ IDF(qi) × [ f(qi,D) × (k1 + 1) ] / [ f(qi,D) + k1 × (1 - b + b × |D|/avgdl) ]
```

Where:
- `f(qi, D)` = frequency of query term `qi` in document `D`
- `|D|` = length of document `D`
- `avgdl` = average document length
- `k1 = 1.5`, `b = 0.75` (BM25Okapi defaults)

**In this pipeline:**
- Document = `job.title + " " + job.skills` (tokenised on whitespace, lowercased)
- Query = top 15 candidate skills, joined and tokenised
- Raw scores min-max normalised to [0, 100] across the current job batch

### Cosine Similarity via Dot Product

When vectors are L2-normalised (unit vectors), dot product = cosine similarity:

```
cos(A, B) = (A · B) / (|A| × |B|) = A · B    when |A| = |B| = 1
```

`all-MiniLM-L6-v2` encodes with `normalize_embeddings=True`, so:

```python
scores = (job_matrix @ cand_emb)   # (n_jobs × 384) @ (384,) → (n_jobs,)
```

One matrix multiply for all jobs simultaneously — O(n × d) where d=384.

### Hybrid Combination

```
hybrid = 0.40 × bm25_normalised + 0.60 × (cosine × 100)
```

Both signals are already in [0, 100]. No further normalisation needed.

### LLM Weighted Composite

Enforced in the Groq prompt's scoring guide:

```
overall_score = must_have × 0.60 + nice_to_have × 0.25 + title_match × 0.15
```

The model is instructed to compute this itself; the API does not recompute it from the component scores. The prompt uses `temperature=0` so the same candidate+job pair produces the same scores across runs.

---

## 9. Trade-offs & Design Decisions

### Decision 1: SQL pre-filter before ML (Stage 2B before 3A)

**Chose:** Filter by title (ILIKE) and date (last 3 days) in SQL before any ML.

**Why:** Running semantic scoring on the entire jobs table (potentially 10,000+ rows) is orders of magnitude slower and less accurate. Title pre-filtering produces a semantically coherent pool — every job in the pool has a related role title. Within that pool, BM25 and embeddings distinguish *quality* of match.

**Trade-off:** A candidate whose title is unusual (e.g. `"Agentic Systems Architect"`) might get 0 jobs if the title expander doesn't produce enough breadth. Mitigated by the 10–12 variants from the LLM.

---

### Decision 2: Hybrid BM25 + embeddings (not embeddings alone)

**Chose:** BM25 (0.40) + embeddings (0.60).

**Why:**
- Embeddings miss exact-match critical terms. A resume with `"Python, AWS Lambda, PostgreSQL"` verbatim might score lower than `"cloud infrastructure and backend scripting"` because the model learned semantic proximity.
- BM25 has zero additional dependencies (`rank_bm25` uses numpy which sentence-transformers already requires).

**Trade-off:** BM25 requires a corpus large enough for IDF to be meaningful. With only 4 jobs in the pool (as seen in early tests), BM25 scores all zero because there's no term-frequency variance. Hybrid gracefully degrades to embeddings-only in this case (BM25=0 × 0.40 = 0 contribution).

---

### Decision 3: pgvector over JSONB for embedding cache

**Chose:** pgvector `vector(384)` columns.

**Why (user-driven):** JSONB was the initial proposal but rejected because pgvector's FK CASCADE means job embeddings are deleted automatically when jobs go inactive — no separate cleanup cron needed.

Additional benefits: type enforcement (can't accidentally store 256-dim in a 384-dim column), binary storage (1.5 KB vs 3 KB), and future-proof for server-side ANN search.

**Trade-off:** Requires the `vector` PostgreSQL extension. Already installed on the target instance; confirmed by `CREATE EXTENSION IF NOT EXISTS vector` succeeding at first run.

---

### Decision 4: Two-layer embedding cache (memory + DB)

**Chose:** Module-level in-memory dict as Layer 1, pgvector as Layer 2.

**Why:** A DB round-trip for every job in every match run adds up. For 300 jobs × 50 candidates = 15,000 DB calls per batch. The memory cache eliminates all of those for a warm process (jobs are shared across candidates, so after the first candidate run, all 300 job embeddings are in memory).

**Trade-off:** Memory cache is process-scoped. A fresh deploy or horizontal scale-out (multiple uvicorn workers) clears Layer 1 for each new process. Layer 2 (pgvector) is the durable source; Layer 1 rehydrates from it on next access. `evict_memory_cache()` utility provided for post-batch forced eviction.

---

### Decision 5: Failure not cached in title expander

**Chose:** Never write a failed/fallback result to the in-memory cache.

**Why:** If Groq is rate-limited at 13:21 and only the original title is searched, caching `["Lead AI Engineer"]` as the permanent result means every future run for that candidate also searches only 1 title. The next run should retry both providers.

**Trade-off:** If both providers are permanently down, every match run for every candidate makes 2 failed LLM calls before falling back. Acceptable cost given the rarity of that scenario.

---

### Decision 6: Async with Semaphore(5) for LLM scoring

**Chose:** `asyncio.gather` over all 30 jobs, bounded by `Semaphore(5)`.

**Why:** Sequential calls would take 30 × avg_groq_latency ≈ 5 min. Unbounded concurrent calls hit the Groq free-tier rate limit immediately (429 on nearly every call). 5 concurrent calls stay safely within rate limits while reducing total latency to ~30 seconds.

**Trade-off:** If the candidate match pool grows beyond 30 (e.g. top_n increased to 50), the semaphore keeps throughput flat while latency increases proportionally. The right response at that scale is to reduce `top_k` or upgrade the Groq plan.

---

### Decision 7: Replace-on-run for persistence

**Chose:** `DELETE WHERE candidate_id = :cid` + fresh INSERT on every run.

**Why:** The 3-day window means results from Monday are meaningless on Thursday. Keeping stale results alongside fresh ones would confuse both the frontend and recruiters. Replace semantics mean the table always reflects the current job market.

**Trade-off:** No match history is preserved. If tracking "how candidate match scores improve over time" becomes a requirement, an append model with a `run_id` or `matched_at` index would be needed.

---

### Decision 8: Groq base_url explicitly set in code

**Chose:** `AsyncGroq(api_key=key, base_url="https://api.groq.com")` rather than reading from the environment.

**Why:** `GROQ_BASE_URL=https://api.groq.com/openai/v1` was already set in the .env (for the old matching service). The Groq SDK reads this env var and uses it as the base, then appends `/openai/v1/chat/completions` → doubled path → 404. Hardcoding the root URL in the matching agent overrides the env var without touching the .env.

---

## 10. Running & Testing

### Trigger via API

```bash
# Run matching for a specific candidate
curl -X POST http://localhost:8000/candidates/{unique_id}/matches/run \
     -H "X-API-Key: <your_api_key>"

# Retrieve stored results
curl http://localhost:8000/candidates/{unique_id}/matches \
     -H "X-API-Key: <your_api_key>"
```

### What to watch in logs

```
[MatchingAgent] S1 done | title='Lead AI Engineer' skills=183 exp=5.0y
[TitleExpander] Groq OK — 'Lead AI Engineer' → 12 variants: [...]
[MatchingAgent] S2A done | 12 title variants: "Lead AI Engineer", "Senior AI Engineer", ...
[JobFilter] 47 jobs found | window: last 3d (since 2026-05-24 18:29 UTC) | 12 title variants searched.
[HybridScorer] Top job: 'Senior AI Engineer' @ hybrid=78.4 (BM25=62.1×0.4 + embed=89.2×0.6) | Forwarding 30 of 47 to LLM scorer.
[HybridScorer] Shortlist (30 jobs → LLM scorer):
     # 1  score= 78.4  Senior AI Engineer          Stripe          New York, NY
     # 2  score= 75.1  ...
[LLMScorer] 30 jobs scored → 20 returned. #1: 'Senior AI Engineer' @ 84.0%
```

### Common failure modes

| Symptom | Cause | Fix |
|---------|-------|-----|
| `1 title variants` in log | Groq rate-limit (429) hit the expander | Transient — next run retries. Check GROQ rate limit quota. |
| `0 jobs from SQL` | No jobs scraped in last 3 days matching any title variant | Run the scraper or widen `lookback_days` in `job_filter.py` |
| `Embedding scoring failed` | pgvector extension not installed | `CREATE EXTENSION vector;` in the DB as superuser |
| `SyntaxError … :param::type` | SQLAlchemy `text()` confusion with `::` cast after `:param` | Use `CAST(:param AS type)` instead |
| `Groq 404 /openai/v1/openai/v1/…` | `GROQ_BASE_URL` env var set to the full path | Already fixed — `base_url` is hardcoded in `AsyncGroq()` calls |
| `InFailedSqlTransaction` on persist | A prior SQL in the same session failed without rollback | Already fixed — `db.rollback()` called after any cache SQL failure |

### Environment variables required

```
GROQ_API_KEY=...          # Primary LLM provider for both title expansion and scoring
OPENAI_API_KEY=...        # Fallback for title expansion only
DATABASE_URL=...           # PostgreSQL connection string (SSL required)
API_KEY=...                # Header key for all endpoints
```