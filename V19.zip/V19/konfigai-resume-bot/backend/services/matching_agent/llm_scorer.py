"""
Stage 3B — LLM Deep Scorer
============================
Sends each candidate-job pair to Groq (llama-3.3-70b-versatile) and receives
a structured JSON score covering:

  - must_have_score    — % of core required skills / experience met
  - nice_to_have_score — % of preferred / bonus qualifications met
  - title_match        — alignment between candidate title and job title
  - overall_score      — weighted composite (60 / 25 / 15)
  - strengths          — up to 3 concrete reasons the candidate fits
  - gaps               — up to 3 specific things the candidate is missing

Concurrency:
  Up to CONCURRENCY (5) parallel async Groq calls — all 30 jobs
  complete in roughly 25–35 seconds depending on response latency.

Fallback:
  If GROQ_API_KEY is missing or a call fails, the semantic_score from
  Stage 3A is used as the overall_score so the pipeline never breaks.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re

from groq import AsyncGroq

from services.matching_agent.models import CandidateProfile, JobRecord, JobMatchResult

logger = logging.getLogger("KonfigAI")

_MODEL = "llama-3.3-70b-versatile"
CONCURRENCY = 5         # Max parallel async Groq calls
MAX_DESC_CHARS = 800    # Truncate job description in prompt (control token count)
TOP_K = 20              # Final results returned to caller

_PROMPT_TEMPLATE = """\
You are a senior technical recruiter. Evaluate how well this candidate fits \
the job. Be precise and objective. Return ONLY valid JSON — no explanation, \
no markdown, no code fences.

CANDIDATE:
Current Title: {title}
Total Experience: {years} years
Top Skills (weight = how recently used, 1.0 = most recent):
{skills_block}
Professional Summary: {summary}

JOB: {job_title} at {company}
Required Skills / Keywords: {job_skills}
Job Description (excerpt): {job_desc}

Scoring guide:
- must_have_score   : What % of the job's core required skills and experience \
does this candidate meet?  (100 = perfect match on all must-haves)
- nice_to_have_score: What % of the preferred / bonus qualifications does the \
candidate meet?
- title_match       : How well does the candidate's current role align with this \
job title? (100 = exact same domain & seniority, 0 = unrelated field)
- overall_score     : Weighted composite — must_have 60% + nice_to_have 25% + \
title_match 15%
- strengths         : Up to 3 specific, concrete reasons this candidate is a \
strong fit (reference actual skills or experience)
- gaps              : Up to 3 specific things the candidate is missing for this \
role

Return exactly this JSON:
{{
  "must_have_score": <integer 0-100>,
  "nice_to_have_score": <integer 0-100>,
  "title_match": <integer 0-100>,
  "overall_score": <integer 0-100>,
  "strengths": ["<string>", "<string>", "<string>"],
  "gaps": ["<string>", "<string>", "<string>"]
}}"""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _skills_block(profile: CandidateProfile) -> str:
    """Format top 15 weighted skills as a readable list for the prompt."""
    lines = []
    for skill, weight in list(profile.weighted_skills.items())[:15]:
        lines.append(f"  • {skill} (weight: {weight:.1f})")
    return "\n".join(lines) if lines else "  • Not specified"


def _build_prompt(profile: CandidateProfile, job: JobRecord) -> str:
    desc = (job.description or "")[:MAX_DESC_CHARS].replace("\n", " ").strip()
    return _PROMPT_TEMPLATE.format(
        title=profile.current_title,
        years=profile.years_experience,
        skills_block=_skills_block(profile),
        summary=(profile.summary or "")[:300],
        job_title=job.title,
        company=job.company or "Unknown Company",
        job_skills=job.skills or "See description",
        job_desc=desc or "Not provided",
    )


def _parse_response(raw: str, job: JobRecord) -> dict:
    """
    Parse LLM JSON response.  Strips markdown fences if present.
    Falls back to semantic_score on any parse failure.
    """
    raw = raw.strip()
    raw = re.sub(r'^```[a-z]*\n?', '', raw, flags=re.M)
    raw = re.sub(r'\n?```$', '', raw, flags=re.M)

    try:
        data = json.loads(raw)
        return {
            "must_have_score": float(data.get("must_have_score", 0)),
            "nice_to_have_score": float(data.get("nice_to_have_score", 0)),
            "title_match": float(data.get("title_match", 0)),
            "overall_score": float(data.get("overall_score", 0)),
            "strengths": [s for s in data.get("strengths", []) if isinstance(s, str)][:3],
            "gaps": [g for g in data.get("gaps", []) if isinstance(g, str)][:3],
        }
    except (json.JSONDecodeError, ValueError, TypeError) as exc:
        logger.warning(
            f"[LLMScorer] JSON parse failed for '{job.title}': {exc}. "
            f"Raw (first 120 chars): '{raw[:120]}'"
        )
        return {
            "must_have_score": 0.0,
            "nice_to_have_score": 0.0,
            "title_match": 0.0,
            "overall_score": job.semantic_score,  # Fall back to semantic score
            "strengths": [],
            "gaps": ["LLM response could not be parsed — showing semantic score only"],
        }


def _job_dict(job: JobRecord) -> dict:
    return {
        "serial_no": job.serial_no,
        "title": job.title,
        "company": job.company,
        "location": job.location,
        "url": job.url,
        "job_type": job.job_type,
        "workplace_type": job.workplace_type,
        "scraped_at": job.scraped_at,
    }


async def _score_one(
    client: AsyncGroq,
    semaphore: asyncio.Semaphore,
    profile: CandidateProfile,
    job: JobRecord,
) -> dict:
    """Score a single job. Uses semaphore to cap concurrency."""
    async with semaphore:
        try:
            prompt = _build_prompt(profile, job)
            response = await client.chat.completions.create(
                model=_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=400,
                temperature=0,
            )
            scores = _parse_response(response.choices[0].message.content, job)
        except Exception as exc:
            logger.warning(f"[LLMScorer] Groq call failed for '{job.title}': {exc}")
            scores = {
                "must_have_score": 0.0,
                "nice_to_have_score": 0.0,
                "title_match": 0.0,
                "overall_score": job.semantic_score,
                "strengths": [],
                "gaps": [f"Groq call failed: {str(exc)[:80]}"],
            }

        scores["_job"] = job
        return scores


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def score_jobs(
    profile: CandidateProfile,
    jobs: list[JobRecord],
    top_k: int = TOP_K,
) -> list[JobMatchResult]:
    """
    Score all jobs against the candidate profile using Groq (async, concurrent).
    Returns the top_k results sorted by overall_score DESC.

    Args:
        profile: CandidateProfile produced by Stage 1.
        jobs:    Top-N jobs from Stage 3A (semantic scorer).
        top_k:   Number of final results to return (default 20).

    Returns:
        List of JobMatchResult sorted by overall_score DESC.
    """
    if not jobs:
        return []

    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        logger.error("[LLMScorer] GROQ_API_KEY not set — returning semantic-only scores.")
        results = []
        for i, job in enumerate(jobs[:top_k]):
            results.append(JobMatchResult(
                rank=i + 1,
                job=_job_dict(job),
                overall_score=round(job.semantic_score, 1),
                must_have_score=0.0,
                nice_to_have_score=0.0,
                title_match=0.0,
                strengths=[],
                gaps=["GROQ_API_KEY not configured — showing semantic score only"],
            ))
        return results

    # Explicitly set base_url to avoid GROQ_BASE_URL env var doubling the path.
    # If GROQ_BASE_URL=https://api.groq.com/openai/v1 is set in the environment,
    # the SDK appends /openai/v1/chat/completions again → 404.
    # Hardcoding the correct root URL overrides the env var.
    client = AsyncGroq(api_key=api_key, base_url="https://api.groq.com")
    semaphore = asyncio.Semaphore(CONCURRENCY)

    # Fire all scoring tasks concurrently (bounded by semaphore)
    raw_results = await asyncio.gather(
        *[_score_one(client, semaphore, profile, job) for job in jobs]
    )

    # Sort by overall_score DESC, then assign rank
    raw_results.sort(key=lambda r: r["overall_score"], reverse=True)

    final: list[JobMatchResult] = []
    for rank, r in enumerate(raw_results[:top_k], start=1):
        job = r.pop("_job")
        final.append(JobMatchResult(
            rank=rank,
            job=_job_dict(job),
            overall_score=round(r["overall_score"], 1),
            must_have_score=round(r["must_have_score"], 1),
            nice_to_have_score=round(r["nice_to_have_score"], 1),
            title_match=round(r["title_match"], 1),
            strengths=r["strengths"],
            gaps=r["gaps"],
        ))

    if final:
        logger.info(
            f"[LLMScorer] {len(jobs)} jobs scored → {len(final)} returned. "
            f"#1: '{final[0].job.get('title')}' @ {final[0].overall_score}%"
        )

    return final
