"""
Matching Agent — Main Orchestrator
====================================
Wires together all four stages into a single async function: run_matching().
Also owns the persistence layer (candidate_job_matches table) and the
get_matches() query used by the GET endpoint.

Table: candidate_details.candidate_job_matches
  Auto-created on first run via _ensure_table().
  Previous results for a candidate are replaced on every new run — the
  table always reflects the latest 3-day window.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone

from sqlalchemy.orm import Session
from sqlalchemy import text

from services.matching_agent.normalizer import normalize_resume
from services.matching_agent.title_expander import expand_title
from services.matching_agent.job_filter import filter_jobs
from services.matching_agent.semantic_scorer import rank_by_semantic
from services.matching_agent.llm_scorer import score_jobs
from services.matching_agent.models import JobMatchResult, MatchRunResult

logger = logging.getLogger("KonfigAI")

_SCHEMA = "candidate_details"
_TABLE = f"{_SCHEMA}.candidate_job_matches"

# ---------------------------------------------------------------------------
# DDL — auto-create results table
# ---------------------------------------------------------------------------

_DDL = f"""
CREATE TABLE IF NOT EXISTS {_TABLE} (
    id                  SERIAL PRIMARY KEY,
    candidate_id        CHAR(20)    NOT NULL,
    job_serial_no       INTEGER     NOT NULL,
    job_title           TEXT,
    company             TEXT,
    job_url             TEXT,
    job_type            TEXT,
    workplace_type      TEXT,
    location            TEXT,
    scraped_at          TEXT,
    rank                INTEGER,
    overall_score       FLOAT,
    must_have_score     FLOAT,
    nice_to_have_score  FLOAT,
    title_match         FLOAT,
    strengths           JSONB       DEFAULT '[]'::jsonb,
    gaps                JSONB       DEFAULT '[]'::jsonb,
    applied             BOOLEAN     DEFAULT FALSE,
    matched_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cjm_candidate_id
    ON {_TABLE} (candidate_id);

CREATE INDEX IF NOT EXISTS idx_cjm_overall_score
    ON {_TABLE} (overall_score DESC);
"""

_table_ready = False


def _ensure_table(db: Session) -> None:
    """Create the results table and indexes if they don't already exist."""
    global _table_ready
    if _table_ready:
        return
    try:
        db.execute(text(_DDL))
        db.execute(text(f"ALTER TABLE {_TABLE} ADD COLUMN IF NOT EXISTS applied BOOLEAN DEFAULT FALSE"))
        db.commit()
        _table_ready = True
        logger.info(f"[MatchingAgent] Table {_TABLE} is ready (applied column checked).")
    except Exception as exc:
        db.rollback()
        logger.warning(f"[MatchingAgent] Table setup warning (may already exist): {exc}")
        _table_ready = True  # Avoid retrying on every call


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def _persist(db: Session, candidate_id: str, results: list[JobMatchResult]) -> None:
    """
    Replace all previous match results for this candidate with the new run.
    Uses a DELETE + INSERT approach inside one transaction for atomicity.
    """
    # Remove stale results
    db.execute(
        text(f"DELETE FROM {_TABLE} WHERE candidate_id = :cid"),
        {"cid": candidate_id},
    )

    insert_sql = text(f"""
        INSERT INTO {_TABLE} (
            candidate_id, job_serial_no, job_title, company, job_url,
            job_type, workplace_type, location, scraped_at,
            rank, overall_score, must_have_score, nice_to_have_score,
            title_match, strengths, gaps
        ) VALUES (
            :cid, :serial_no, :title, :company, :url,
            :job_type, :workplace_type, :location, :scraped_at,
            :rank, :overall_score, :must_have_score, :nice_to_have_score,
            :title_match, CAST(:strengths AS jsonb), CAST(:gaps AS jsonb)
        )
    """)

    for r in results:
        j = r.job
        db.execute(insert_sql, {
            "cid":              candidate_id,
            "serial_no":        j.get("serial_no"),
            "title":            j.get("title"),
            "company":          j.get("company"),
            "url":              j.get("url"),
            "job_type":         j.get("job_type"),
            "workplace_type":   j.get("workplace_type"),
            "location":         j.get("location"),
            "scraped_at":       j.get("scraped_at"),
            "rank":             r.rank,
            "overall_score":    r.overall_score,
            "must_have_score":  r.must_have_score,
            "nice_to_have_score": r.nice_to_have_score,
            "title_match":      r.title_match,
            "strengths":        json.dumps(r.strengths),
            "gaps":             json.dumps(r.gaps),
        })

    db.commit()
    logger.info(f"[MatchingAgent] Persisted {len(results)} matches for {candidate_id}.")


# ---------------------------------------------------------------------------
# Public: query stored results
# ---------------------------------------------------------------------------

def get_matches(db: Session, candidate_id: str, limit: int = 20) -> dict:
    """
    Return stored match results for a candidate.
    Called by GET /candidates/{id}/matches.

    Returns a dict shaped for the API response:
      {
        "jobs": [...],
        "matched_at": "<iso timestamp>",
        "total": <int>
      }
    """
    _ensure_table(db)

    rows = db.execute(
        text(f"""
            SELECT
                cjm.rank,
                cjm.overall_score, cjm.must_have_score, cjm.nice_to_have_score, cjm.title_match,
                cjm.strengths, cjm.gaps,
                cjm.job_serial_no, cjm.job_title, cjm.company, cjm.job_url,
                cjm.job_type, cjm.workplace_type, cjm.location, cjm.scraped_at,
                cjm.matched_at,
                cjm.applied,
                COALESCE(ia.vendor_name, ii.vendor_name, cjm.company) as vendor
            FROM {_TABLE} cjm
            LEFT JOIN scrapped_data.active_scraped_data s ON cjm.job_serial_no = s.serial_no
            LEFT JOIN scrapped_data.input_active ia ON s.keyword = ia.dice_search_link
            LEFT JOIN scrapped_data.inactive_scraped_data si ON cjm.job_serial_no = si.serial_no
            LEFT JOIN scrapped_data.input_inactive ii ON si.keyword = ii.dice_job_link
            WHERE cjm.candidate_id = :cid
            ORDER BY cjm.rank ASC
            LIMIT :lim
        """),
        {"cid": candidate_id, "lim": limit},
    ).fetchall()

    if not rows:
        return {"jobs": [], "matched_at": None, "total": 0}

    jobs = [
        {
            "rank":             row.rank,
            "overall_score":    row.overall_score,
            "match_score":      row.overall_score,  # Map match_score for frontend drawer/modal!
            "must_have_score":  row.must_have_score,
            "nice_to_have_score": row.nice_to_have_score,
            "title_match":      row.title_match,
            "strengths":        row.strengths or [],
            "gaps":             row.gaps or [],
            "applied":          bool(row.applied),
            "job": {
                "serial_no":      row.job_serial_no,
                "job_id":         row.job_serial_no, # Map job_id for frontend action handlers!
                "title":          row.job_title,
                "company":        row.company,
                "company_name":   row.company,       # Map company_name for frontend!
                "url":            row.job_url,
                "job_type":       row.job_type,
                "workplace_type": row.workplace_type,
                "location":       row.location,
                "scraped_at":     str(row.scraped_at) if row.scraped_at else None,
                "vendor":         row.vendor or row.company,
            },
        }
        for row in rows
    ]

    return {
        "jobs": jobs,
        "matched_at": str(rows[0].matched_at) if rows else None,
        "total": len(jobs),
    }


# ---------------------------------------------------------------------------
# Public: run full pipeline
# ---------------------------------------------------------------------------

async def run_matching(candidate_id: str, db: Session) -> MatchRunResult:
    """
    Execute the full 3-stage matching pipeline for one candidate.

    Stages:
      1  Resume Normalizer   — weighted skill profile
      2A Title Expander      — related titles (Groq, cached)
      2B SQL Pre-filter      — title + date filter on active_scraped_data
      3A Semantic Scorer     — cosine similarity ranking
      3B LLM Deep Scorer     — Groq structured scoring (async, concurrent)
      →  Persist + return

    Args:
        candidate_id: The candidate's unique_id.
        db:           SQLAlchemy session (caller-owned, not closed here).

    Returns:
        MatchRunResult with ranked jobs and run metadata.

    Raises:
        LookupError:  Candidate not found in the database.
        ValueError:   Resume not completed or content is empty.
    """
    _ensure_table(db)
    run_start = datetime.now(timezone.utc)

    # ── Fetch resume content ──────────────────────────────────────────────────
    row = db.execute(
        text("""
            SELECT
                fri.formatted_resume_content,
                fri.formatted_resume_status,
                fri.formatted_resume_processed_at
            FROM candidate_details.candidate_basic_info cbi
            JOIN candidate_details.formatting_resume_info fri
              ON cbi.unique_id = fri.unique_id
            WHERE cbi.unique_id = :cid
        """),
        {"cid": candidate_id},
    ).fetchone()

    if not row:
        raise LookupError(f"Candidate '{candidate_id}' not found.")

    if row.formatted_resume_status != "completed":
        raise ValueError(
            f"Resume for candidate '{candidate_id}' is not yet completed "
            f"(status: '{row.formatted_resume_status}'). "
            "Run the formatter first before matching."
        )

    if not row.formatted_resume_content:
        raise ValueError(
            f"Candidate '{candidate_id}' has no resume content stored."
        )

    logger.info(f"[MatchingAgent] ── Starting run for {candidate_id} ──")

    # ── Stage 1: Normalise resume ─────────────────────────────────────────────
    profile = normalize_resume(candidate_id, row.formatted_resume_content)
    logger.info(
        f"[MatchingAgent] S1 done | title='{profile.current_title}' "
        f"skills={len(profile.weighted_skills)} exp={profile.years_experience}y"
    )

    # ── Stage 2A: Expand title ────────────────────────────────────────────────
    expanded = await expand_title(profile.current_title)
    logger.info(
        f"[MatchingAgent] S2A done | {len(expanded)} title variants: "
        + ", ".join(f'"{t}"' for t in expanded)
    )

    # ── Stage 2B: SQL pre-filter ──────────────────────────────────────────────
    filtered = filter_jobs(db, expanded)
    logger.info(f"[MatchingAgent] S2B done | {len(filtered)} jobs from SQL")

    if not filtered:
        logger.info(
            f"[MatchingAgent] No jobs found in last 3 days for "
            f"'{profile.current_title}' — run complete with 0 matches."
        )
        return MatchRunResult(
            candidate_id=candidate_id,
            jobs_filtered=0,
            jobs_scored=0,
            jobs=[],
            matched_at=run_start.isoformat(),
        )

    # ── Stage 3A: Semantic ranking ────────────────────────────────────────────
    # resume_version keys the embedding cache — when the formatter re-processes
    # the resume the timestamp changes, forcing a fresh embedding + DB upsert.
    resume_version = (
        str(row.formatted_resume_processed_at)
        if row.formatted_resume_processed_at
        else "v0"
    )
    top_jobs = rank_by_semantic(
        profile,
        filtered,
        db=db,
        resume_version=resume_version,
        top_n=30,
    )
    logger.info(f"[MatchingAgent] S3A done | {len(top_jobs)} jobs after semantic filter")

    # ── Stage 3B: LLM deep scoring ────────────────────────────────────────────
    final = await score_jobs(profile, top_jobs, top_k=20)
    logger.info(f"[MatchingAgent] S3B done | {len(final)} scored results")

    # ── Persist ───────────────────────────────────────────────────────────────
    if final:
        _persist(db, candidate_id, final)

    elapsed = (datetime.now(timezone.utc) - run_start).total_seconds()
    if final:
        logger.info(
            f"[MatchingAgent] ── Run complete in {elapsed:.1f}s | "
            f"#{1}: '{final[0].job.get('title')}' @ {final[0].overall_score}% ──"
        )
    else:
        logger.info(f"[MatchingAgent] ── Run complete in {elapsed:.1f}s | 0 matches ──")

    return MatchRunResult(
        candidate_id=candidate_id,
        jobs_filtered=len(filtered),
        jobs_scored=len(final),
        jobs=final,
        matched_at=run_start.isoformat(),
    )
