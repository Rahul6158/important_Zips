"""
Pydantic models shared across all matching agent stages.
"""

from __future__ import annotations
from typing import List, Optional
from pydantic import BaseModel, Field


class CandidateProfile(BaseModel):
    """
    Normalised snapshot of a candidate's resume — produced by Stage 1 (normalizer)
    and consumed by all subsequent stages.
    """
    candidate_id: str
    current_title: str                        # Most recent job title
    years_experience: float                   # Total calculated from date ranges
    weighted_skills: dict[str, float]         # skill -> weight (0.4 – 1.0)
    top_skills: List[str]                     # Top 15 skills sorted by weight
    resume_text: str                          # Flat text used for embedding
    summary: str                              # Professional summary from resume


class JobRecord(BaseModel):
    """
    A single row from scrapped_data.active_scraped_data, plus a running
    semantic_score field added by Stage 3A.
    """
    serial_no: int
    title: str
    company: str
    location: Optional[str] = None
    url: Optional[str] = None
    description: Optional[str] = None
    skills: Optional[str] = None
    job_type: Optional[str] = None
    workplace_type: Optional[str] = None
    scraped_at: Optional[str] = None

    # Populated by semantic_scorer (Stage 3A)
    semantic_score: float = 0.0


class JobMatchResult(BaseModel):
    """
    Final scored result for a single candidate-job pair.
    Produced by Stage 3B (LLM scorer) and persisted to candidate_job_matches.
    """
    rank: int
    job: dict                                  # Serialised JobRecord fields
    overall_score: float = Field(ge=0, le=100)
    must_have_score: float = Field(ge=0, le=100)
    nice_to_have_score: float = Field(ge=0, le=100)
    title_match: float = Field(ge=0, le=100)
    strengths: List[str] = Field(default_factory=list)
    gaps: List[str] = Field(default_factory=list)


class MatchRunResult(BaseModel):
    """
    Complete output of one matching run returned to the API router.
    """
    candidate_id: str
    jobs_filtered: int                         # Jobs surviving SQL pre-filter
    jobs_scored: int                           # Jobs that went through LLM scorer
    jobs: List[JobMatchResult]
    matched_at: str                            # ISO timestamp of run start