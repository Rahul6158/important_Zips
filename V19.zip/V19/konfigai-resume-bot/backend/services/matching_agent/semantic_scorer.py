"""
Stage 3A — Hybrid Scorer  (BM25 + Semantic Embeddings + pgvector cache)
========================================================================
Ranks the SQL-filtered job pool using TWO complementary signals, then
combines them into a single hybrid score before forwarding the top N
jobs to the LLM deep-scorer.

WHY HYBRID?
-----------
Embeddings alone        → excellent at role-level fit ("led teams" ≈
                          "people manager"), but compress text into dense
                          vectors that can score "cloud infrastructure and
                          backend scripting" ABOVE a resume that says
                          "Python, AWS Lambda, PostgreSQL" verbatim — because
                          cosine similarity optimises for semantic proximity,
                          not keyword precision.

BM25 alone              → excellent at exact-term matching ("AWS Lambda"
                          scores a job that says "AWS Lambda", period), but
                          misses semantic equivalences and penalises resumes
                          that use different but valid terminology.

Hybrid (BM25 + embed)   → gets the best of both.  Exact-match critical
                          terms (skills, tools, frameworks) are captured by
                          BM25; role-level alignment and soft-skill language
                          are captured by the embedding.

SIGNAL DETAILS
--------------
BM25 signal  (weight α = 0.40):
  Corpus  → each job's (title + skills column) tokenised on whitespace.
  Query   → candidate's top 15 skills (recency-weighted) tokenised.
  Library → rank_bm25 (pure Python + numpy; numpy already present via
            sentence-transformers — zero extra heavy dependency).
  Score   → BM25Okapi.get_scores(), min-max normalised to [0, 100].

Embedding signal  (weight β = 0.60):
  Model   → all-MiniLM-L6-v2 (lazy-loaded, shared across pipeline).
  Cache   → pgvector-backed two-layer cache (embedding_cache.py):
              Layer 1 — in-memory dict  (zero-latency, process-scoped)
              Layer 2 — pgvector table  (survives deploys, ~1-5 ms)
  Inputs  → candidate resume_text vs job (title + skills + desc[:800]).
  Score   → dot-product on L2-normalised vectors × 100.

Hybrid formula:
  hybrid = (bm25_norm × 0.40) + (embed_score × 0.60)

EMBEDDING CACHE STALENESS
--------------------------
Candidate:  keyed by (candidate_id, resume_version) where
            resume_version = str(formatted_resume_processed_at).
            A re-processed resume triggers a fresh embedding + DB upsert.

Jobs:       keyed by job_serial_no; auto-cleaned by FK CASCADE when the
            job transitions from active_scraped_data → inactive.
            No manual vacuum needed.

OUTPUT
------
Returns the top TOP_N jobs sorted by hybrid_score DESC.
Each JobRecord has .semantic_score set to the final hybrid score so the
rest of the pipeline (LLM scorer, persistence) is completely unaffected.
"""

from __future__ import annotations

import logging
from sqlalchemy.orm import Session
from services.matching_agent.models import CandidateProfile, JobRecord

logger = logging.getLogger("KonfigAI")

TOP_N = 30             # Jobs forwarded to Stage 3B (LLM scorer)
MAX_DESC_CHARS = 800   # Truncate description for embedding (controls token count)
ALPHA = 0.40           # BM25 weight   — skill precision
BETA  = 0.60           # Embed weight  — semantic role fit

# Lazy-loaded to share the encoder across the matching pipeline
_encoder = None


# ---------------------------------------------------------------------------
# Lazy model loader
# ---------------------------------------------------------------------------

def _get_encoder():
    global _encoder
    if _encoder is None:
        try:
            from sentence_transformers import SentenceTransformer
            _encoder = SentenceTransformer("all-MiniLM-L6-v2")
            logger.info("[HybridScorer] SentenceTransformer ready.")
        except Exception as exc:
            logger.error(f"[HybridScorer] Failed to load SentenceTransformer: {exc}")
    return _encoder


# ---------------------------------------------------------------------------
# BM25 helpers
# ---------------------------------------------------------------------------

def _tokenise(text: str) -> list[str]:
    """
    Whitespace tokeniser, lowercased.
    Multi-word skills like "AWS Lambda" become ["aws", "lambda"] — BM25
    still rewards jobs that contain both tokens, which is the correct
    behaviour for skill matching.
    """
    return text.lower().split() if text else []


def _bm25_corpus_text(job: JobRecord) -> str:
    """
    Text used to build the BM25 corpus entry for a job.
    Intentionally limited to title + skills column — the fields that
    contain the most signal-dense, exact-match keywords.
    We deliberately exclude the full description to avoid TF noise from
    boilerplate job-posting language.
    """
    parts = [job.title, job.skills or ""]
    return " ".join(p for p in parts if p)


def _bm25_query_text(profile: CandidateProfile) -> str:
    """
    Query for BM25: the candidate's top 15 skills joined as a string.
    We do NOT include the full resume_text here — only skills matter for
    the exact-match signal.
    """
    return " ".join(profile.top_skills)


def _compute_bm25_scores(profile: CandidateProfile, jobs: list[JobRecord]) -> list[float]:
    """
    Build a BM25Okapi index over the job corpus and return one score per job,
    min-max normalised to [0, 100].

    Falls back to a flat score list of zeros on import / scoring errors so
    the hybrid formula degrades gracefully to embeddings-only.
    """
    try:
        from rank_bm25 import BM25Okapi

        corpus = [_tokenise(_bm25_corpus_text(j)) for j in jobs]
        query  = _tokenise(_bm25_query_text(profile))

        if not query:
            logger.warning("[HybridScorer] BM25 query is empty — no skills extracted.")
            return [0.0] * len(jobs)

        bm25 = BM25Okapi(corpus)
        raw_scores = bm25.get_scores(query)  # returns np.ndarray

        # Min-max normalise to [0, 100]
        max_score = float(max(raw_scores)) if len(raw_scores) > 0 else 0.0
        if max_score <= 0:
            return [0.0] * len(jobs)

        return [round(float(s) / max_score * 100, 2) for s in raw_scores]

    except ImportError:
        logger.warning("[HybridScorer] rank_bm25 not installed — run: pip install rank-bm25")
        return [0.0] * len(jobs)
    except Exception as exc:
        logger.warning(f"[HybridScorer] BM25 scoring failed: {exc}")
        return [0.0] * len(jobs)


# ---------------------------------------------------------------------------
# Embedding helpers — pgvector-cached
# ---------------------------------------------------------------------------

def _embedding_text(job: JobRecord) -> str:
    """Full text used for the embedding signal (title + skills + description)."""
    desc = (job.description or "")[:MAX_DESC_CHARS].replace("\n", " ")
    return " ".join(p for p in [job.title, job.skills or "", desc] if p)


def _compute_embedding_scores(
    profile: CandidateProfile,
    jobs: list[JobRecord],
    db: Session,
    resume_version: str,
) -> list[float]:
    """
    Compute cosine similarity between the candidate resume and each job,
    using the pgvector-backed two-layer embedding cache.

    Resolution order for each vector:
      memory cache (instant) → pgvector table (1-5 ms) → generate + store

    Falls back to zeros if the encoder is unavailable.

    Args:
        profile:        CandidateProfile (needs .candidate_id and .resume_text).
        jobs:           Job list — serial_nos drive cache lookups.
        db:             SQLAlchemy session passed to the cache functions.
        resume_version: Staleness key = str(formatted_resume_processed_at).
    """
    encoder = _get_encoder()
    if encoder is None:
        return [0.0] * len(jobs)

    try:
        import numpy as np
        from services.matching_agent.embedding_cache import (
            get_candidate_embedding,
            get_job_embeddings,
        )

        # ── Candidate embedding ───────────────────────────────────────────────
        # memory → pgvector DB → generate + upsert (only when version changed)
        cand_emb = get_candidate_embedding(
            candidate_id=profile.candidate_id,
            resume_text=profile.resume_text,
            resume_version=resume_version,
            db=db,
            encoder=encoder,
        )  # shape: (384,), float32, L2-normalised

        # ── Job embeddings — bulk ─────────────────────────────────────────────
        # memory → pgvector DB bulk-fetch → batch generate + insert missing
        serial_nos = [j.serial_no for j in jobs]
        job_texts  = [_embedding_text(j) for j in jobs]
        emb_map    = get_job_embeddings(
            serial_nos=serial_nos,
            job_texts=job_texts,
            db=db,
            encoder=encoder,
        )  # dict: serial_no → (384,) float32

        # Build (n_jobs × 384) matrix; fill zeros for any cache miss
        job_matrix = np.array(
            [emb_map.get(sno, np.zeros(384, dtype=np.float32)) for sno in serial_nos],
            dtype=np.float32,
        )

        # Dot-product on L2-normalised vectors = cosine similarity → [0, 100]
        # Shape: (n_jobs, 384) @ (384,) → (n_jobs,)
        scores = (job_matrix @ cand_emb).tolist()
        return [round(float(s) * 100, 2) for s in scores]

    except Exception as exc:
        logger.error(f"[HybridScorer] Embedding scoring failed: {exc}")
        return [0.0] * len(jobs)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def rank_by_semantic(
    profile: CandidateProfile,
    jobs: list[JobRecord],
    db: Session,
    resume_version: str,
    top_n: int = TOP_N,
) -> list[JobRecord]:
    """
    Score every job using the hybrid BM25 + embedding formula and return
    the top `top_n` sorted by hybrid score descending.

    Embeddings are served from the pgvector-backed cache so:
      - A candidate's embedding is computed once per resume version, then
        reused across all subsequent match runs until the resume changes.
      - A job's embedding is computed once, then reused for every candidate.
        When the job goes inactive the FK CASCADE deletes its embedding
        automatically — no manual cleanup needed.

    The result is stored in job.semantic_score so Stage 3B (LLM scorer)
    and persistence layers require zero changes.

    Args:
        profile:        CandidateProfile with .candidate_id, .top_skills,
                        and .resume_text.
        jobs:           Pre-filtered list from Stage 2B (SQL filter).
        db:             SQLAlchemy session (passed to embedding cache).
        resume_version: Staleness key — str(formatted_resume_processed_at).
        top_n:          Number of jobs to forward to Stage 3B (default 30).

    Returns:
        Up to `top_n` JobRecord objects sorted by hybrid score DESC.
    """
    if not jobs:
        return []

    n = len(jobs)
    logger.info(f"[HybridScorer] Scoring {n} jobs for '{profile.current_title}'…")

    # ── Signal A: BM25 (exact-term skill matching) ────────────────────────────
    bm25_scores = _compute_bm25_scores(profile, jobs)

    # ── Signal B: Embeddings via pgvector cache (semantic role fit) ───────────
    embed_scores = _compute_embedding_scores(profile, jobs, db, resume_version)

    # ── Hybrid combination ────────────────────────────────────────────────────
    for job, bm25, embed in zip(jobs, bm25_scores, embed_scores):
        job.semantic_score = round(ALPHA * bm25 + BETA * embed, 2)

    # Capture diagnostic info BEFORE sort (indices still align with score arrays)
    best_idx   = max(range(len(jobs)), key=lambda i: jobs[i].semantic_score)
    best_job   = jobs[best_idx]
    best_bm25  = bm25_scores[best_idx]
    best_embed = embed_scores[best_idx]

    jobs.sort(key=lambda j: j.semantic_score, reverse=True)
    top = jobs[:top_n]

    if top:
        logger.info(
            f"[HybridScorer] Top job: '{best_job.title}' @ "
            f"hybrid={best_job.semantic_score:.1f} "
            f"(BM25={best_bm25:.1f}×{ALPHA} + embed={best_embed:.1f}×{BETA}) | "
            f"Forwarding {len(top)} of {n} to LLM scorer."
        )

        # Full shortlist — one line per job so it's easy to scan in logs
        shortlist_lines = "\n".join(
            f"    #{i+1:>2}  score={j.semantic_score:>5.1f}  "
            f"{j.title or '(no title)':<45}  {j.company or '':<30}  {j.location or ''}"
            for i, j in enumerate(top)
        )
        logger.info(
            f"[HybridScorer] Shortlist ({len(top)} jobs → LLM scorer):\n"
            + shortlist_lines
        )

    return top