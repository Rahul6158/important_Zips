"""
Stage 1 — Resume Normalizer
============================
Converts formatted_resume_content JSON into a CandidateProfile with
recency-weighted skills, a flat resume text for embedding, and derived
metadata (current title, years of experience).

Weight scheme (no external dependencies — pure Python):
  Professional_Experience[0]  (most recent job) → Environment skills: 1.0
  Professional_Experience[1]                    → Environment skills: 0.8
  Professional_Experience[2]                    → Environment skills: 0.6
  Professional_Experience[3+]                   → Environment skills: 0.4
  Responsibility keywords (all jobs)            → weight × 0.7
  Technical_Skills section                      → 0.7  (take max if already seen)
  certifications                                → 0.9
"""

from __future__ import annotations

import re
import logging
from datetime import datetime
from typing import Optional

from services.matching_agent.models import CandidateProfile

logger = logging.getLogger("KonfigAI")

# Weight by experience recency (index = position in Professional_Experience list)
_EXP_WEIGHTS: list[float] = [1.0, 0.8, 0.6, 0.4]
_TECH_SKILLS_WEIGHT = 0.7
_CERT_WEIGHT = 0.9
_RESP_MULTIPLIER = 0.7      # Multiplied against the experience weight
_MAX_RESUME_CHARS = 4000    # Cap for embedding model context


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _parse_years(dates_str: Optional[str]) -> float:
    """
    Extract approximate year count from a free-text employment date range.
    Examples:
      "2019 - 2023"    → 4.0
      "Jan 2021–Present" → 4.0  (if current year is 2025)
      "2022"           → 0.0  (single year, assume still current or unknown end)
    """
    if not dates_str:
        return 0.0

    now_year = datetime.now().year
    normalised = re.sub(
        r'\b(present|current|now|today)\b',
        str(now_year),
        dates_str,
        flags=re.I,
    )
    years = re.findall(r'\b(19|20)\d{2}\b', normalised)
    if len(years) >= 2:
        try:
            return float(abs(int(years[-1]) - int(years[0])))
        except ValueError:
            pass
    return 0.0


def _tokenise_skills(text: str) -> list[str]:
    """
    Split a skill string by common delimiters and return clean tokens.
    Rejects tokens that are too short (<2 chars) or too long (>60 chars,
    likely a full sentence, not a skill name).
    """
    if not text:
        return []
    tokens = re.split(r'[,;|/\n•·\-–]', text)
    result = []
    for t in tokens:
        t = t.strip()
        if 2 <= len(t) <= 60:
            result.append(t)
    return result


def _flatten_technical_skills(tech: object) -> list[str]:
    """
    Flatten the Technical_Skills dict (category → list | str) into a flat list.
    Handles both list values and raw comma-separated strings.
    """
    skills: list[str] = []
    if not isinstance(tech, dict):
        return skills
    for v in tech.values():
        if isinstance(v, list):
            skills.extend(s.strip() for s in v if isinstance(s, str) and s.strip())
        elif isinstance(v, str):
            skills.extend(_tokenise_skills(v))
    return skills


def _looks_like_tech_token(token: str) -> bool:
    """
    Heuristic: reject tokens that look like natural-language phrases rather
    than technology keywords (≤4 words assumed to be a skill name).
    """
    return len(token.split()) <= 4


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def normalize_resume(candidate_id: str, resume_content: dict) -> CandidateProfile:
    """
    Build a CandidateProfile from the formatted_resume_content JSON stored in DB.

    Args:
        candidate_id:   The candidate's unique_id (for logging / model identity).
        resume_content: The JSON dict from formatting_resume_info.formatted_resume_content.

    Returns:
        CandidateProfile ready for downstream stages.

    Raises:
        ValueError: If resume_content is None or empty.
    """
    if not resume_content:
        raise ValueError(f"Candidate {candidate_id} has no formatted resume content.")

    weighted_skills: dict[str, float] = {}

    # ── Professional Experience ───────────────────────────────────────────────
    experiences = resume_content.get("Professional_Experience") or []
    current_title = ""
    total_years = 0.0
    exp_text_parts: list[str] = []

    for idx, exp in enumerate(experiences):
        if not isinstance(exp, dict):
            continue

        exp_weight = _EXP_WEIGHTS[min(idx, len(_EXP_WEIGHTS) - 1)]

        # Capture candidate's most recent title
        if idx == 0:
            current_title = (exp.get("title") or "").strip()

        # Accumulate years of experience
        total_years += _parse_years(exp.get("dates_of_employment"))

        # Skills from the Environment field (direct tech stack)
        for skill in exp.get("Environment") or []:
            if isinstance(skill, str) and skill.strip():
                key = skill.strip()
                weighted_skills[key] = max(weighted_skills.get(key, 0.0), exp_weight)

        # Keyword extraction from Responsibilities
        for resp in exp.get("Responsibilities") or []:
            if not isinstance(resp, str):
                continue
            for token in _tokenise_skills(resp):
                if _looks_like_tech_token(token):
                    w = exp_weight * _RESP_MULTIPLIER
                    weighted_skills[token] = max(weighted_skills.get(token, 0.0), w)

        # Build experience text snippet (for embedding)
        if idx < 4:  # Only top 4 jobs for text length control
            snippet_parts = [
                exp.get("title", ""),
                exp.get("Company", ""),
                exp.get("project_description", ""),
                " ".join((exp.get("Responsibilities") or [])[:3]),
                " ".join((exp.get("Environment") or [])[:10]),
            ]
            exp_text_parts.append(" ".join(p for p in snippet_parts if p))

    # ── Technical_Skills section ──────────────────────────────────────────────
    for skill in _flatten_technical_skills(resume_content.get("Technical_Skills") or {}):
        # Take the max — don't downgrade a skill already seen in experience
        weighted_skills[skill] = max(
            weighted_skills.get(skill, 0.0), _TECH_SKILLS_WEIGHT
        )

    # ── Certifications ────────────────────────────────────────────────────────
    for cert in resume_content.get("certifications") or []:
        if isinstance(cert, str) and cert.strip():
            key = cert.strip()
            weighted_skills[key] = max(
                weighted_skills.get(key, 0.0), _CERT_WEIGHT
            )

    # ── Academic Projects — extract Technologies_used ─────────────────────────
    for proj in resume_content.get("Academic_projects") or []:
        if not isinstance(proj, dict):
            continue
        for tech in proj.get("Technologies_used") or []:
            if isinstance(tech, str) and tech.strip():
                # Lower weight — academic is less relevant than industry exp
                weighted_skills[tech.strip()] = max(
                    weighted_skills.get(tech.strip(), 0.0), 0.5
                )

    # ── Sort & derive top skills ──────────────────────────────────────────────
    sorted_skills = sorted(weighted_skills.items(), key=lambda x: x[1], reverse=True)
    top_skills = [s for s, _ in sorted_skills[:15]]

    # ── Build flat resume text for embedding ──────────────────────────────────
    name = resume_content.get("Name", "")
    summary = (resume_content.get("Summary") or "").strip()
    skills_line = ", ".join(top_skills)
    certs_line = ", ".join(
        c for c in (resume_content.get("certifications") or [])
        if isinstance(c, str)
    )

    resume_text = " | ".join(filter(None, [
        f"{name} — {current_title}" if (name or current_title) else "",
        summary,
        f"Skills: {skills_line}" if skills_line else "",
        *exp_text_parts,
        f"Certifications: {certs_line}" if certs_line else "",
    ]))

    logger.debug(
        f"[Normalizer] Candidate {candidate_id}: title='{current_title}', "
        f"skills={len(weighted_skills)}, exp={total_years:.1f}y"
    )

    return CandidateProfile(
        candidate_id=candidate_id,
        current_title=current_title or "Professional",
        years_experience=round(total_years, 1),
        weighted_skills=dict(sorted_skills),
        top_skills=top_skills,
        resume_text=resume_text[:_MAX_RESUME_CHARS],
        summary=summary,
    )
