"""
Embedding Cache — pgvector-backed, two-layer
=============================================

WHY PGVECTOR OVER JSONB
-----------------------
We store embeddings in PostgreSQL using the pgvector `vector(384)` type,
not as JSONB float arrays.  Reasons:

  1. Automatic cleanup via FK CASCADE
       job_embeddings.job_serial_no → active_scraped_data.serial_no ON DELETE CASCADE
       When the daily cleaner moves a job from active → inactive, its embedding
       row is deleted automatically — no separate vacuum job needed.

  2. Type safety
       `vector(384)` enforces 384 dimensions at the DB level.
       JSONB accepts any value; silent corruption is possible.

  3. Storage efficiency
       pgvector stores float32 in binary (1.5 KB / vector).
       JSONB stores text encoding (~3 KB / vector).

  4. Future-proof
       Today we pull embeddings into Python and compute cosine similarity
       with numpy (fine for 200 jobs).  When the job pool grows we can
       switch to a server-side query:
           ORDER BY embedding <=> :query_vec LIMIT 30
       — zero code changes needed in the scoring logic.

  5. The extension is already installed on the target PostgreSQL instance.

TWO-LAYER CACHE
---------------
Layer 1 — In-memory dict  (hot, zero-latency)
  Survives the process lifetime.  A fresh deploy clears it; everything is
  rehydrated from the DB on next access.  This avoids a DB round-trip for
  every job in every match run.

Layer 2 — pgvector table  (warm, 1–5 ms)
  Survives deploys, restarts, and horizontal scaling.
  Source of truth for stale-detection on candidate embeddings.

STALENESS
---------
Candidate embeddings
  Keyed by (unique_id, resume_version) where resume_version is
  str(formatted_resume_processed_at).  When the formatter re-processes a
  resume the timestamp changes → old embedding is overwritten.

Job embeddings
  Jobs never change after scraping, so there is no staleness concern.
  Cleanup is handled automatically by the FK CASCADE when the job
  transitions to inactive.

TABLES  (auto-created, extension enabled if missing)
------------------------------------------------------
  candidate_details.candidate_resume_embeddings
    unique_id      CHAR(20)   PK, FK → candidate_basic_info  CASCADE DELETE
    embedding      vector(384)
    resume_version TEXT
    updated_at     TIMESTAMPTZ

  candidate_details.job_embeddings
    job_serial_no  INTEGER    PK, FK → active_scraped_data    CASCADE DELETE
    embedding      vector(384)
    created_at     TIMESTAMPTZ
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import numpy as np
from sqlalchemy.orm import Session
from sqlalchemy import text

if TYPE_CHECKING:
    from sentence_transformers import SentenceTransformer

logger = logging.getLogger("KonfigAI")

# ---------------------------------------------------------------------------
# Schema / table constants
# ---------------------------------------------------------------------------

_SCHEMA      = "candidate_details"
_CAND_TABLE  = f"{_SCHEMA}.candidate_resume_embeddings"
_JOB_TABLE   = f"{_SCHEMA}.job_embeddings"
_DIMS        = 384   # all-MiniLM-L6-v2 output dimensions

# ---------------------------------------------------------------------------
# In-memory hot caches  (process-scoped)
# ---------------------------------------------------------------------------

# unique_id → (embedding: np.ndarray, resume_version: str)
_cand_mem: dict[str, tuple[np.ndarray, str]] = {}

# job_serial_no → embedding: np.ndarray
_job_mem:  dict[int, np.ndarray] = {}

# DDL idempotency guard
_tables_ready = False

# ---------------------------------------------------------------------------
# DDL — enable pgvector, create tables
# ---------------------------------------------------------------------------

_DDL = f"""
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS {_CAND_TABLE} (
    unique_id      CHAR(20)       PRIMARY KEY
                                  REFERENCES {_SCHEMA}.candidate_basic_info(unique_id)
                                  ON DELETE CASCADE,
    embedding      vector({_DIMS}) NOT NULL,
    resume_version TEXT           NOT NULL,
    updated_at     TIMESTAMPTZ    DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS {_JOB_TABLE} (
    job_serial_no  INTEGER        PRIMARY KEY
                                  REFERENCES scrapped_data.active_scraped_data(serial_no)
                                  ON DELETE CASCADE,
    embedding      vector({_DIMS}) NOT NULL,
    created_at     TIMESTAMPTZ    DEFAULT NOW()
);
"""


def _ensure_tables(db: Session) -> None:
    global _tables_ready
    if _tables_ready:
        return
    try:
        db.execute(text(_DDL))
        db.commit()
        _tables_ready = True
        logger.info(f"[EmbedCache] pgvector tables ready ({_CAND_TABLE}, {_JOB_TABLE}).")
    except Exception as exc:
        db.rollback()
        logger.warning(f"[EmbedCache] Table setup warning (may already exist): {exc}")
        _tables_ready = True  # Don't block the pipeline on DDL failures


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------

def _to_pgvec(emb: np.ndarray) -> str:
    """
    Serialize a numpy float32 array to pgvector literal string format.
    pgvector expects '[x,y,z,...]' (square brackets, comma-separated).
    """
    return "[" + ",".join(str(round(float(v), 8)) for v in emb) + "]"


def _from_pgvec(value) -> np.ndarray:
    """
    Deserialize a pgvector column value back to a float32 numpy array.
    SQLAlchemy returns it as a string '[x,y,z,...]' or as a list,
    depending on the driver version.
    """
    if isinstance(value, np.ndarray):
        return value.astype(np.float32)
    if isinstance(value, list):
        return np.array(value, dtype=np.float32)
    # String form: '[0.1,0.2,...]'
    return np.fromstring(str(value).strip("[]"), sep=",", dtype=np.float32)


# ---------------------------------------------------------------------------
# Candidate embedding — get or generate
# ---------------------------------------------------------------------------

def get_candidate_embedding(
    candidate_id: str,
    resume_text: str,
    resume_version: str,
    db: Session,
    encoder: "SentenceTransformer",
) -> np.ndarray:
    """
    Return a cached L2-normalised resume embedding for the candidate.

    Resolution order:
      1. In-memory dict  — instant, valid if resume_version matches.
      2. pgvector table  — 1-5 ms, valid if resume_version matches.
      3. Generate fresh  — ~50 ms on CPU, stored in both layers.

    resume_version = str(formatted_resume_processed_at)
    When the formatter re-processes a resume the timestamp changes and
    a fresh embedding is generated and the DB row is overwritten.

    Args:
        candidate_id:   Candidate's unique_id.
        resume_text:    Flat resume text (produced by normalizer.py).
        resume_version: Staleness key (ISO timestamp string).
        db:             SQLAlchemy session.
        encoder:        SentenceTransformer instance (already loaded).

    Returns:
        float32 np.ndarray of shape (384,), L2-normalised.
    """
    _ensure_tables(db)

    # ── Layer 1: memory ───────────────────────────────────────────────────────
    hit = _cand_mem.get(candidate_id)
    if hit is not None:
        emb, version = hit
        if version == resume_version:
            logger.debug(f"[EmbedCache] Candidate {candidate_id}: memory hit.")
            return emb
        logger.debug(f"[EmbedCache] Candidate {candidate_id}: memory stale, checking DB.")

    # ── Layer 2: DB ───────────────────────────────────────────────────────────
    row = db.execute(
        text(f"""
            SELECT embedding::text, resume_version
            FROM   {_CAND_TABLE}
            WHERE  unique_id = :uid
        """),
        {"uid": candidate_id},
    ).fetchone()

    if row and row.resume_version == resume_version:
        emb = _from_pgvec(row.embedding)
        _cand_mem[candidate_id] = (emb, resume_version)
        logger.debug(f"[EmbedCache] Candidate {candidate_id}: DB hit.")
        return emb

    # ── Layer 3: generate ─────────────────────────────────────────────────────
    logger.info(f"[EmbedCache] Candidate {candidate_id}: generating new embedding.")
    emb = encoder.encode(
        resume_text,
        convert_to_tensor=False,
        normalize_embeddings=True,
        show_progress_bar=False,
    ).astype(np.float32)

    # Upsert into pgvector table
    # Note: use CAST(:emb AS vector) — not :emb::vector.
    # The :: cast operator immediately after a :param confuses SQLAlchemy's
    # text() parameter parser, causing the param to be left un-substituted.
    try:
        db.execute(
            text(f"""
                INSERT INTO {_CAND_TABLE} (unique_id, embedding, resume_version, updated_at)
                VALUES (:uid, CAST(:emb AS vector), :ver, NOW())
                ON CONFLICT (unique_id) DO UPDATE
                    SET embedding      = EXCLUDED.embedding,
                        resume_version = EXCLUDED.resume_version,
                        updated_at     = NOW()
            """),
            {"uid": candidate_id, "emb": _to_pgvec(emb), "ver": resume_version},
        )
        db.commit()
        logger.debug(f"[EmbedCache] Candidate {candidate_id}: embedding persisted to pgvector.")
    except Exception as exc:
        db.rollback()  # Reset the session so the rest of the pipeline can continue
        logger.warning(
            f"[EmbedCache] Could not persist candidate {candidate_id} embedding "
            f"(in-memory cache still populated): {exc}"
        )

    _cand_mem[candidate_id] = (emb, resume_version)
    return emb


# ---------------------------------------------------------------------------
# Job embeddings — bulk get or generate
# ---------------------------------------------------------------------------

def get_job_embeddings(
    serial_nos: list[int],
    job_texts: list[str],
    db: Session,
    encoder: "SentenceTransformer",
) -> dict[int, np.ndarray]:
    """
    Return L2-normalised embeddings for a batch of jobs.

    Resolution:
      memory → DB (bulk SELECT) → generate only the true misses.
    New embeddings are written to both the pgvector table and memory cache.

    The FK `job_serial_no → active_scraped_data.serial_no ON DELETE CASCADE`
    means embeddings for jobs that go inactive are automatically removed — no
    manual cleanup required.

    Args:
        serial_nos: Job serial numbers, aligned 1:1 with job_texts.
        job_texts:  Text representation of each job (title+skills+desc excerpt).
        db:         SQLAlchemy session.
        encoder:    SentenceTransformer instance.

    Returns:
        Dict mapping serial_no → float32 np.ndarray(384,).
    """
    _ensure_tables(db)

    result: dict[int, np.ndarray] = {}
    need_db:  list[int] = []
    need_text: dict[int, str] = {}

    # ── Layer 1: memory ───────────────────────────────────────────────────────
    for sno, txt in zip(serial_nos, job_texts):
        if sno in _job_mem:
            result[sno] = _job_mem[sno]
        else:
            need_db.append(sno)
            need_text[sno] = txt

    mem_hits = len(result)

    if not need_db:
        logger.debug(f"[EmbedCache] All {len(serial_nos)} job embeddings served from memory.")
        return result

    # ── Layer 2: DB — bulk fetch ──────────────────────────────────────────────
    db_rows = db.execute(
        text(f"""
            SELECT job_serial_no, embedding::text
            FROM   {_JOB_TABLE}
            WHERE  job_serial_no = ANY(:sns)
        """),
        {"sns": need_db},
    ).fetchall()

    db_found: set[int] = set()
    for row in db_rows:
        emb = _from_pgvec(row.embedding)
        _job_mem[row.job_serial_no] = emb
        result[row.job_serial_no]   = emb
        db_found.add(row.job_serial_no)

    # ── Layer 3: generate only true misses ────────────────────────────────────
    truly_missing = [sno for sno in need_db if sno not in db_found]

    if truly_missing:
        texts_to_encode = [need_text[sno] for sno in truly_missing]

        logger.info(
            f"[EmbedCache] Job embeddings: {mem_hits} memory | "
            f"{len(db_found)} DB | {len(truly_missing)} to generate."
        )

        new_embs: np.ndarray = encoder.encode(
            texts_to_encode,
            convert_to_tensor=False,
            normalize_embeddings=True,
            batch_size=64,
            show_progress_bar=False,
        ).astype(np.float32)

        # Bulk upsert — ON CONFLICT DO NOTHING is safe because jobs don't change
        for sno, emb in zip(truly_missing, new_embs):
            try:
                db.execute(
                    text(f"""
                        INSERT INTO {_JOB_TABLE} (job_serial_no, embedding)
                        VALUES (:sno, CAST(:emb AS vector))
                        ON CONFLICT (job_serial_no) DO NOTHING
                    """),
                    {"sno": sno, "emb": _to_pgvec(emb)},
                )
            except Exception as exc:
                db.rollback()  # Reset session before continuing the loop
                logger.warning(f"[EmbedCache] Could not persist job {sno} embedding: {exc}")

        db.commit()

        for sno, emb in zip(truly_missing, new_embs):
            _job_mem[sno]  = emb
            result[sno]    = emb
    else:
        logger.debug(
            f"[EmbedCache] Job embeddings: {mem_hits} memory | "
            f"{len(db_found)} DB | 0 generated."
        )

    return result


# ---------------------------------------------------------------------------
# Monitoring helpers
# ---------------------------------------------------------------------------

def cache_stats() -> dict:
    """Return a snapshot of current in-memory cache sizes (for health checks / logs)."""
    return {
        "candidates_cached_in_memory": len(_cand_mem),
        "jobs_cached_in_memory":       len(_job_mem),
    }


def evict_memory_cache() -> None:
    """
    Clear the in-memory cache.  Embeddings remain in the pgvector tables and
    will be reloaded on next access.  Useful after a bulk re-processing event.
    """
    _cand_mem.clear()
    _job_mem.clear()
    logger.info("[EmbedCache] In-memory embedding cache evicted.")