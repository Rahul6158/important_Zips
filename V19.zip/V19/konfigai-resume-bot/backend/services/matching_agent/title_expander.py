"""
Stage 2A — Title Expander
==========================
Uses Groq (llama-3.3-70b-versatile) to generate synonymous and related job
titles for the candidate's current role.  Falls back to OpenAI (gpt-4o-mini)
if Groq is unavailable (e.g. rate-limited).  The expanded list is used to
build the SQL ILIKE filter in Stage 2B, catching all relevant postings
regardless of exact title wording.

Provider chain:
  1. Groq  llama-3.3-70b-versatile  (fast, cheap, primary)
  2. OpenAI gpt-4o-mini              (fallback when Groq fails / rate-limits)
  3. Original title only             (last resort — no external call)

Cache strategy:
  Successful results (from either provider) are stored in a module-level
  dict keyed by normalised title — one LLM call per unique title per process.

  IMPORTANT: Failures are NOT cached.  If both providers fail, the original
  title is returned but nothing is written to the cache so the next match
  run retries rather than permanently falling back to a 1-title search.

Async:
  expand_title() is a coroutine — service.py calls it with `await`.
"""

from __future__ import annotations

import os
import json
import logging
import re

logger = logging.getLogger("KonfigAI")

# Module-level cache: normalised_title → list[str]
# Only populated on SUCCESSFUL responses (from any provider).
_cache: dict[str, list[str]] = {}

_GROQ_MODEL   = "llama-3.3-70b-versatile"
_OPENAI_MODEL = "gpt-4o-mini"

_PROMPT = """\
Given the job title "{title}", return a JSON array of 10-12 job titles that \
technical recruiters commonly use for the same or closely related roles.

Rules:
1. Include the original title as the first element.
2. Include common seniority variants (Junior, Senior, Lead, Principal, Staff).
3. Include acronym / abbreviation equivalents (ML = Machine Learning, etc.).
4. Include adjacent specialist roles within the same technology domain.
5. Keep every title concise (2-6 words maximum).
6. Do NOT include managerial or completely unrelated roles.

Return ONLY a valid JSON array of strings — no explanation, no markdown, no \
code fences.

Example for "AI Engineer":
["AI Engineer","ML Engineer","Machine Learning Engineer","NLP Engineer",\
"LLM Engineer","Deep Learning Engineer","AI/ML Engineer",\
"Applied ML Engineer","Research Engineer","GenAI Engineer",\
"Agentic AI Engineer","Applied Scientist"]"""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _key(title: str) -> str:
    """Normalise a title to a stable cache key."""
    return re.sub(r'\s+', ' ', title.lower().strip())


def _parse_titles(raw: str, original: str) -> list[str]:
    """
    Extract a list of title strings from the LLM response.
    Strips markdown code fences if present, then JSON-parses.
    Returns None on any parse error so the caller can try the next provider.
    """
    raw = raw.strip()
    raw = re.sub(r'^```[a-z]*\n?', '', raw, flags=re.M)
    raw = re.sub(r'\n?```$', '', raw, flags=re.M)

    try:
        parsed = json.loads(raw)
        if not isinstance(parsed, list):
            raise ValueError("Expected a JSON array")
        titles = [t.strip() for t in parsed if isinstance(t, str) and t.strip()]
        if not titles:
            raise ValueError("Empty title list in response")
        # Ensure original is always present
        if not any(_key(t) == _key(original) for t in titles):
            titles.insert(0, original)
        return titles
    except (json.JSONDecodeError, ValueError) as exc:
        logger.warning(f"[TitleExpander] JSON parse error: {exc} — raw='{raw[:120]}'")
        return None


async def _try_groq(title: str) -> list[str] | None:
    """Call Groq. Returns parsed title list on success, None on any failure."""
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        logger.debug("[TitleExpander] GROQ_API_KEY not set — skipping Groq.")
        return None

    try:
        from groq import AsyncGroq
        client = AsyncGroq(api_key=api_key, base_url="https://api.groq.com")
        response = await client.chat.completions.create(
            model=_GROQ_MODEL,
            messages=[{"role": "user", "content": _PROMPT.format(title=title)}],
            max_tokens=300,
            temperature=0,
        )
        raw = response.choices[0].message.content
        titles = _parse_titles(raw, title)
        if titles:
            logger.info(f"[TitleExpander] Groq OK — '{title}' → {len(titles)} variants: {titles}")
        return titles
    except Exception as exc:
        logger.warning(
            f"[TitleExpander] Groq FAILED for '{title}': {exc} — "
            "will try OpenAI fallback."
        )
        return None


async def _try_openai(title: str) -> list[str] | None:
    """Call OpenAI gpt-4o-mini. Returns parsed title list on success, None on failure."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        logger.debug("[TitleExpander] OPENAI_API_KEY not set — skipping OpenAI fallback.")
        return None

    try:
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=api_key)
        response = await client.chat.completions.create(
            model=_OPENAI_MODEL,
            messages=[{"role": "user", "content": _PROMPT.format(title=title)}],
            max_tokens=300,
            temperature=0,
        )
        raw = response.choices[0].message.content
        titles = _parse_titles(raw, title)
        if titles:
            logger.info(f"[TitleExpander] OpenAI fallback OK — '{title}' → {len(titles)} variants: {titles}")
        return titles
    except Exception as exc:
        logger.warning(
            f"[TitleExpander] OpenAI fallback ALSO FAILED for '{title}': {exc} — "
            "falling back to original title only."
        )
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def expand_title(title: str) -> list[str]:
    """
    Return a list of related job titles for the given candidate title.
    Always contains at least the original title.

    Provider chain: Groq → OpenAI → original title only.
    Successful results are cached; failures are NOT cached (retried next run).

    Args:
        title: Candidate's current job title extracted from their resume.

    Returns:
        List of 1–12 related job title strings.
    """
    cache_key = _key(title)

    if cache_key in _cache:
        cached = _cache[cache_key]
        logger.info(
            f"[TitleExpander] Cache hit: '{title}' → "
            f"{len(cached)} variants: {cached}"
        )
        return cached

    # ── 1. Try Groq ───────────────────────────────────────────────────────────
    titles = await _try_groq(title)

    # ── 2. Fallback: OpenAI ───────────────────────────────────────────────────
    if titles is None:
        titles = await _try_openai(title)

    # ── 3. Last resort: original title only ──────────────────────────────────
    if titles is None:
        logger.warning(
            f"[TitleExpander] Both providers failed for '{title}'. "
            "Searching with original title only — result NOT cached."
        )
        return [title]  # Not cached — next run will retry both providers

    # Cache only on success
    _cache[cache_key] = titles
    return titles


def clear_cache() -> None:
    """Clear the in-memory title cache (useful for testing)."""
    _cache.clear()