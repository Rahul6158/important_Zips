"""
Stage 2B — SQL Job Filter
==========================
Queries scrapped_data.active_scraped_data for jobs whose titles match any
of the expanded title variants AND that were scraped within the last
LOOKBACK_DAYS days.

Uses parameterised ILIKE clauses — one per expanded title — so the query
stays safe and Postgres can use the existing `ix_active_keyword` index.

Expected output: 20–300 jobs, later narrowed by semantic scoring.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session
from sqlalchemy import text

from services.matching_agent.models import JobRecord

logger = logging.getLogger("KonfigAI")

LOOKBACK_DAYS = 3     # Jobs older than this are ignored (likely stale / filled)
MAX_ROWS = 300        # Hard cap before semantic scoring narrows the pool further


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def filter_jobs(
    db: Session,
    expanded_titles: list[str],
    lookback_days: int = LOOKBACK_DAYS,
    max_rows: int = MAX_ROWS,
) -> list[JobRecord]:
    """
    Return active scraped jobs that match any of the expanded title variants
    and were scraped within the last `lookback_days` days.

    Args:
        db:              SQLAlchemy session (request-scoped).
        expanded_titles: List produced by title_expander.expand_title().
        lookback_days:   How many days back to search (default 3).
        max_rows:        Safety cap on rows returned (default 300).

    Returns:
        List of JobRecord objects, ordered by scraped_at DESC.
        Returns [] on empty expanded_titles or DB error.
    """
    if not expanded_titles:
        logger.warning("[JobFilter] No expanded titles provided — skipping SQL filter.")
        return []

    # Build parameterised ILIKE conditions
    # e.g. title ILIKE :t0 OR title ILIKE :t1 OR ...
    conditions = " OR ".join(f"title ILIKE :t{i}" for i in range(len(expanded_titles)))
    params: dict = {f"t{i}": f"%{t}%" for i, t in enumerate(expanded_titles)}
    params["cutoff"] = datetime.now(timezone.utc) - timedelta(days=lookback_days)

    sql = text(f"""
        SELECT
            serial_no,
            title,
            company,
            location,
            url,
            description,
            skills,
            job_type,
            workplace_type,
            scraped_at
        FROM scrapped_data.active_scraped_data
        WHERE scraped_at >= :cutoff
          AND ({conditions})
        ORDER BY scraped_at DESC
        LIMIT {int(max_rows)}
    """)

    try:
        rows = db.execute(sql, params).fetchall()

        jobs: list[JobRecord] = []
        for row in rows:
            jobs.append(JobRecord(
                serial_no=row.serial_no,
                title=row.title or "",
                company=row.company or "",
                location=row.location,
                url=row.url,
                description=row.description,
                skills=row.skills,
                job_type=row.job_type,
                workplace_type=row.workplace_type,
                scraped_at=str(row.scraped_at) if row.scraped_at else None,
            ))

        cutoff_str = params["cutoff"].strftime("%Y-%m-%d %H:%M UTC")
        logger.info(
            f"[JobFilter] {len(jobs)} jobs found | window: last {lookback_days}d "
            f"(since {cutoff_str}) | {len(expanded_titles)} title variants searched."
        )
        return jobs

    except Exception as exc:
        logger.error(f"[JobFilter] SQL query failed: {exc}")
        return []
