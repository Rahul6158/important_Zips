"""
Matching Agent Service
======================
Finds relevant jobs for a candidate from the last 3 days by running a
3-stage pipeline:
  Stage 1  — Resume Normalizer   (pure Python, recency-weighted skills)
  Stage 2A — Title Expander      (Groq LLM, cached per title)
  Stage 2B — SQL Pre-filter      (PostgreSQL ILIKE + date range)
  Stage 3A — Semantic Scorer     (sentence-transformers cosine similarity)
  Stage 3B — LLM Deep Scorer     (Groq structured scoring, 5 concurrent)

Public API:
  run_matching(candidate_id, db)        -> MatchRunResult
  get_matches(db, candidate_id, limit)  -> dict
"""

from services.matching_agent.service import run_matching, get_matches

__all__ = ["run_matching", "get_matches"]
