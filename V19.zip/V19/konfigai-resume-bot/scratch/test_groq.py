import os
from dotenv import load_dotenv

# Load env from backend/.env
dotenv_path = os.path.join(os.path.dirname(__file__), "..", "backend", ".env")
load_dotenv(dotenv_path)

import httpx

def mock_send(request, *args, **kwargs):
    print("MOCKED REQUEST URL:", request.url)
    raise httpx.RequestError("Mocked request interception", request=request)

# 1. Test Groq client with explicit base_url="https://api.groq.com"
from groq import Groq
client_groq = Groq(api_key="gsk_dummy", base_url="https://api.groq.com")
client_groq._client.send = mock_send

try:
    client_groq.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": "Hello"}],
    )
except Exception:
    pass

# 2. Test OpenAI client with settings.groq_base_url (https://api.groq.com/openai/v1)
from openai import OpenAI
client_openai = OpenAI(api_key="gsk_dummy", base_url=os.environ.get("GROQ_BASE_URL"))
client_openai._client.send = mock_send

try:
    client_openai.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": "Hello"}],
    )
except Exception:
    pass
